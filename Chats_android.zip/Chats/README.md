# Chats — SMS e MMS para Android

Kotlin (SMS, MMS, notificações, contactos, permissões) + HTML5/CSS3/JavaScript puro numa Android WebView. Sem backend, sem frameworks JS.

## Gerar o APK no GitHub
1. Crie um repositório novo e envie todo o conteúdo desta pasta (`git init && git add . && git commit -m "Chats" && git push`).
2. Abra o separador **Actions**: o workflow **Build APK** corre sozinho a cada push (ou use *Run workflow*).
3. Quando terminar, abra a execução e descarregue o artefacto **Chats-APK** (`Chats.apk` e `Chats-debug.apk`).
4. Para criar uma Release com o APK: `git tag v1.0.0 && git push --tags`.

O APK `Chats.apk` é assinado com a chave de debug (instalável de imediato). Para a Play Store configure a sua chave em `app/build.gradle.kts`.

## Instalar e usar
1. Instale o APK (permita “instalar de fontes desconhecidas”).
2. Abra o Chats → **Conceder permissões** → **Definir como predefinida**.
   (Manualmente: Definições do Android → Aplicações → Aplicações predefinidas → Aplicação de SMS → Chats.)
   O estado é lido do RoleManager (a mesma fonte das Definições), de `Telephony.Sms.getDefaultSmsPackage()` e da definição `sms_default_application`; basta uma confirmar. É relido ao regressar à app (tentativas durante ~15 s) e sempre que o sistema avisa da mudança.
   Diagnóstico: `adb logcat -s ChatsDefaultSms` (cada linha mostra as 3 fontes: `role{...}`, `getDefaultSmsPackage=` e `secure=`).

## Permissões
| Permissão | Para quê |
|---|---|
| READ/SEND/RECEIVE_SMS, RECEIVE_MMS, RECEIVE_WAP_PUSH | Ler, enviar e receber SMS/MMS |
| INTERNET, ACCESS/CHANGE_NETWORK_STATE | Transferência de MMS pelo sistema (dados móveis) |
| READ_CONTACTS | Nomes, fotografias e escolha de destinatários |
| READ_PHONE_STATE | Listar SIMs e escolher o SIM de envio |
| POST_NOTIFICATIONS | Notificações de mensagens e de entrega |
| SYSTEM_ALERT_WINDOW | Balão flutuante de novas mensagens por cima de outras aplicações (opcional) |
| ACCESS_FINE/COARSE_LOCATION | Partilhar localização (só quando escolhido) |
| RECORD_AUDIO | Gravador de voz (só quando escolhido) |
| READ_CALENDAR | Partilhar eventos da agenda (só quando escolhido) |
| SCHEDULE_EXACT_ALARM, RECEIVE_BOOT_COMPLETED | Mensagens programadas |

## Balão flutuante
- Quando chega uma mensagem aparece um **balão** com a foto/inicial do contacto (sem aros coloridos), **ponto vermelho** (com o número se forem várias) e uma pré-visualização ao lado durante uns segundos. Mensagens de serviço usam o ícone escuro de pessoa.
- Os balões ficam **juntos numa pilha**: o da mensagem mais recente à frente e os outros a espreitar por trás.
- **Arraste** a pilha para qualquer ponto do ecrã; ao largar, encosta ao lado mais próximo. A pilha **só desaparece** quando a arrasta para o **✕** que surge em baixo; abrir a mensagem só apaga o ponto vermelho.
- **Toque** na pilha para abrir a janela de resposta: os balões sobem **todos para o topo**, lado a lado, como separadores. Toque num balão para passar para essa conversa; **puxe um balão para cima** para o remover. Ao fechar a janela voltam juntos à pilha.
- Ativar em Definições → Notificações → **Balão flutuante**; o Android pede a permissão “Mostrar sobre outras aplicações” (uma só vez).
- Não aparece em conversas silenciadas, números bloqueados ou com as notificações desligadas. Com a pré-visualização “Oculta” mostra o logótipo do Chats.
- Se o Android encerrar a app em segundo plano, os balões desaparecem até chegar nova mensagem.

## Conversas
- Ao rolar para cima aparece uma **seta**; some quando pára de rolar e, se tocar nela, vai até à última mensagem (na app e na janela de resposta).

## Notificações de entrega e falha
- Há **uma só notificação por conversa** que se atualiza a cada mensagem entregue (não faz lista) e não mostra o texto enviado. “Não enviada” usa o mesmo desenho.

## Limitações (dependem do Android e da operadora)
- Só a app SMS predefinida pode escrever no armazenamento de mensagens, bloquear números e receber SMS/MMS.
- MMS exige dados móveis e APN MMS da operadora; o limite de tamanho é o da operadora (imagens são reduzidas automaticamente).
- “Entregue” só aparece com relatório real da rede; nem todas as operadoras o enviam.
- Mensagens programadas: apenas SMS de texto. Sem alarmes exatos o Android pode atrasar o envio.
- Vários destinatários: SMS são enviados individualmente; com anexo/assunto é enviado um MMS de grupo.

## Lixo
- Tudo o que é eliminado (mensagem, conversa ou limpeza de antigas) vai para o **Lixo** (menu ⋮ → Lixo) e fica **30 dias**; depois é apagado para sempre.
- No lixo pode restaurar (requer ser a app SMS predefinida) ou eliminar para sempre.
- **Proteção opcional** (⋮ do Lixo → Proteção do lixo): PIN, senha ou padrão. Guardada apenas como hash (PBKDF2 com sal), com atraso após 5 tentativas erradas. Se a esquecer não há recuperação.
