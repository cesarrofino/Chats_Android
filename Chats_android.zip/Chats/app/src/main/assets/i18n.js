/* Idiomas: pt-PT (original), pt-BR, en, fr, es, zh, ko.
   A interface é escrita em português de Portugal; este módulo traduz o texto visível (e aria-label/placeholder)
   a partir de um dicionário. Texto de mensagens, nomes e resumos nunca é traduzido. */
(function () {
  // [pt-PT, en, fr, es, zh, ko]
  const ROWS = [
    ['Conversas', 'Conversations', 'Conversations', 'Conversaciones', '对话', '대화'],
    ['Todas as conversas', 'All conversations', 'Toutes les conversations', 'Todas las conversaciones', '所有对话', '모든 대화'],
    ['Não lidas', 'Unread', 'Non lues', 'No leídas', '未读', '읽지 않음'],
    ['Só não lidas', 'Unread only', 'Non lues uniquement', 'Solo no leídas', '仅未读', '읽지 않음만'],
    ['Só fixadas', 'Pinned only', 'Épinglées uniquement', 'Solo fijadas', '仅置顶', '고정만'],
    ['Fixadas', 'Pinned', 'Épinglées', 'Fijadas', '置顶', '고정됨'],
    ['Arquivadas', 'Archived', 'Archivées', 'Archivadas', '已归档', '보관됨'],
    ['Conversas arquivadas', 'Archived conversations', 'Conversations archivées', 'Conversaciones archivadas', '已归档的对话', '보관된 대화'],
    ['Contactos', 'Contacts', 'Contacts', 'Contactos', '联系人', '연락처'],
    ['Mensagens', 'Messages', 'Messages', 'Mensajes', '消息', '메시지'],
    ['Mensagem', 'Message', 'Message', 'Mensaje', '消息', '메시지'],
    ['Definições', 'Settings', 'Paramètres', 'Ajustes', '设置', '설정'],
    ['Pesquisar aqui…', 'Search here…', 'Rechercher ici…', 'Buscar aquí…', '在此搜索…', '여기서 검색…'],
    ['Nome ou número', 'Name or number', 'Nom ou numéro', 'Nombre o número', '姓名或号码', '이름 또는 번호'],
    ['Nova conversa', 'New conversation', 'Nouvelle conversation', 'Nueva conversación', '新对话', '새 대화'],
    ['Para', 'To', 'À', 'Para', '收件人', '받는 사람'],
    ['Escreva algo…', 'Type something…', 'Écrivez quelque chose…', 'Escribe algo…', '输入内容…', '입력하세요…'],
    ['Ainda sem conversas', 'No conversations yet', 'Pas encore de conversations', 'Aún no hay conversaciones', '还没有对话', '아직 대화가 없습니다'],
    ['Toque em “Nova” para escrever a primeira mensagem.', 'Tap “New” to write your first message.', 'Touchez « Nouvelle » pour écrire votre premier message.', 'Toca “Nueva” para escribir tu primer mensaje.', '点按“新建”撰写第一条消息。', '“새로 만들기”를 눌러 첫 메시지를 작성하세요.'],
    ['Escreva abaixo para começar a conversa.', 'Type below to start the conversation.', 'Écrivez ci-dessous pour démarrer la conversation.', 'Escribe abajo para empezar la conversación.', '在下方输入以开始对话。', '아래에 입력하여 대화를 시작하세요.'],
    ['Sem resultados', 'No results', 'Aucun résultat', 'Sin resultados', '无结果', '결과 없음'],
    ['Experimente outro nome, número ou palavra.', 'Try another name, number or word.', 'Essayez un autre nom, numéro ou mot.', 'Prueba otro nombre, número o palabra.', '试试其他姓名、号码或词语。', '다른 이름, 번호 또는 단어를 입력해 보세요.'],
    ['Hoje', 'Today', 'Aujourd’hui', 'Hoy', '今天', '오늘'],
    ['Ontem', 'Yesterday', 'Hier', 'Ayer', '昨天', '어제'],
    ['Voltar', 'Back', 'Retour', 'Atrás', '返回', '뒤로'],
    ['Mais', 'More', 'Plus', 'Más', '更多', '더보기'],
    ['Fechar', 'Close', 'Fermer', 'Cerrar', '关闭', '닫기'],
    ['Cancelar', 'Cancel', 'Annuler', 'Cancelar', '取消', '취소'],
    ['Continuar', 'Continue', 'Continuer', 'Continuar', '继续', '계속'],
    ['Guardar', 'Save', 'Enregistrer', 'Guardar', '保存', '저장'],
    ['Editar', 'Edit', 'Modifier', 'Editar', '编辑', '편집'],
    ['Eliminar', 'Delete', 'Supprimer', 'Eliminar', '删除', '삭제'],
    ['Apagar', 'Erase', 'Effacer', 'Borrar', '清除', '지우기'],
    ['Remover', 'Remove', 'Retirer', 'Quitar', '移除', '제거'],
    ['Adicionar', 'Add', 'Ajouter', 'Añadir', '添加', '추가'],
    ['Copiar', 'Copy', 'Copier', 'Copiar', '复制', '복사'],
    ['Responder', 'Reply', 'Répondre', 'Responder', '回复', '답장'],
    ['Reencaminhar', 'Forward', 'Transférer', 'Reenviar', '转发', '전달'],
    ['Partilhar', 'Share', 'Partager', 'Compartir', '分享', '공유'],
    ['Selecionar', 'Select', 'Sélectionner', 'Seleccionar', '选择', '선택'],
    ['Fixar', 'Pin', 'Épingler', 'Fijar', '置顶', '고정'],
    ['Desafixar', 'Unpin', 'Désépingler', 'Desfijar', '取消置顶', '고정 해제'],
    ['Silenciar', 'Mute', 'Mettre en sourdine', 'Silenciar', '静音', '음소거'],
    ['Arquivar', 'Archive', 'Archiver', 'Archivar', '归档', '보관'],
    ['Bloquear', 'Block', 'Bloquer', 'Bloquear', '屏蔽', '차단'],
    ['Desbloquear', 'Unblock', 'Débloquer', 'Desbloquear', '取消屏蔽', '차단 해제'],
    ['Ligar', 'Call', 'Appeler', 'Llamar', '拨打电话', '전화'],
    ['Enviar', 'Send', 'Envoyer', 'Enviar', '发送', '보내기'],
    ['Restaurar', 'Restore', 'Restaurer', 'Restaurar', '恢复', '복원'],
    ['Repor', 'Reset', 'Réinitialiser', 'Restablecer', '重置', '초기화'],
    ['Permitir', 'Allow', 'Autoriser', 'Permitir', '允许', '허용'],
    ['Agora não', 'Not now', 'Pas maintenant', 'Ahora no', '暂不', '나중에'],
    ['Tentar novamente', 'Try again', 'Réessayer', 'Reintentar', '重试', '다시 시도'],
    ['Definir', 'Set', 'Définir', 'Establecer', '设置', '설정'],
    ['Aparência', 'Appearance', 'Apparence', 'Apariencia', '外观', '모양'],
    ['Tema', 'Theme', 'Thème', 'Tema', '主题', '테마'],
    ['Auto', 'Auto', 'Auto', 'Auto', '自动', '자동'],
    ['Claro', 'Light', 'Clair', 'Claro', '浅色', '라이트'],
    ['Escuro', 'Dark', 'Sombre', 'Oscuro', '深色', '다크'],
    ['Fundo das conversas', 'Chat background', 'Arrière-plan des conversations', 'Fondo de las conversaciones', '对话背景', '대화 배경'],
    ['Balões e texto', 'Bubbles and text', 'Bulles et texte', 'Burbujas y texto', '气泡和文字', '말풍선 및 글자'],
    ['Balões', 'Bubbles', 'Bulles', 'Burbujas', '气泡', '말풍선'],
    ['Tipo de balão', 'Bubble type', 'Type de bulle', 'Tipo de burbuja', '气泡类型', '말풍선 유형'],
    ['Personalizado', 'Custom', 'Personnalisé', 'Personalizado', '自定义', '사용자 지정'],
    ['Notificações', 'Notifications', 'Notifications', 'Notificaciones', '通知', '알림'],
    ['Balão flutuante', 'Floating bubble', 'Bulle flottante', 'Burbuja flotante', '悬浮气泡', '플로팅 말풍선'],
    ['Mostrar sobre outras apps', 'Show over other apps', 'Afficher par-dessus d’autres applis', 'Mostrar sobre otras apps', '显示在其他应用上层', '다른 앱 위에 표시'],
    ['Em falta', 'Missing', 'Manquant', 'Falta', '缺失', '누락'],
    ['Pré-visualização', 'Preview', 'Aperçu', 'Vista previa', '预览', '미리보기'],
    ['Total', 'Full', 'Complet', 'Completa', '完整', '전체'],
    ['Nome', 'Name', 'Nom', 'Nombre', '姓名', '이름'],
    ['Oculta', 'Hidden', 'Masquée', 'Oculta', '隐藏', '숨김'],
    ['Som', 'Sound', 'Son', 'Sonido', '声音', '소리'],
    ['Do sistema', 'System', 'Système', 'Del sistema', '系统', '시스템'],
    ['Entrega confirmada', 'Delivery confirmed', 'Livraison confirmée', 'Entrega confirmada', '送达确认', '전달 확인'],
    ['Acender o ecrã ao receber', 'Wake screen on receive', 'Allumer l’écran à la réception', 'Encender la pantalla al recibir', '收到时点亮屏幕', '수신 시 화면 켜기'],
    ['Códigos de verificação', 'Verification codes', 'Codes de vérification', 'Códigos de verificación', '验证码', '인증 코드'],
    ['Notificações do sistema', 'System notifications', 'Notifications système', 'Notificaciones del sistema', '系统通知', '시스템 알림'],
    ['Relatórios de entrega', 'Delivery reports', 'Accusés de livraison', 'Informes de entrega', '送达报告', '전달 보고서'],
    ['Transferir MMS automaticamente', 'Download MMS automatically', 'Télécharger les MMS automatiquement', 'Descargar MMS automáticamente', '自动下载彩信', 'MMS 자동 다운로드'],
    ['SIM para envio', 'SIM for sending', 'SIM pour l’envoi', 'SIM para enviar', '发送用 SIM 卡', '발송용 SIM'],
    ['Respostas rápidas', 'Quick replies', 'Réponses rapides', 'Respuestas rápidas', '快捷回复', '빠른 답장'],
    ['Favoritas', 'Favorites', 'Favoris', 'Favoritas', '收藏', '즐겨찾기'],
    ['Programadas', 'Scheduled', 'Programmés', 'Programados', '定时消息', '예약됨'],
    ['Dados', 'Data', 'Données', 'Datos', '数据', '데이터'],
    ['Números bloqueados', 'Blocked numbers', 'Numéros bloqués', 'Números bloqueados', '已屏蔽号码', '차단된 번호'],
    ['Armazenamento', 'Storage', 'Stockage', 'Almacenamiento', '存储', '저장 공간'],
    ['Sobre', 'About', 'À propos', 'Acerca de', '关于', '정보'],
    ['Versão', 'Version', 'Version', 'Versión', '版本', '버전'],
    ['Geral', 'General', 'Général', 'General', '通用', '일반'],
    ['SMS predefinida', 'Default SMS app', 'Appli SMS par défaut', 'App SMS predeterminada', '默认短信应用', '기본 SMS 앱'],
    ['Ativa', 'Active', 'Active', 'Activa', '已启用', '사용 중'],
    ['Inativa', 'Inactive', 'Inactive', 'Inactiva', '未启用', '사용 안 함'],
    ['Permissões', 'Permissions', 'Autorisations', 'Permisos', '权限', '권한'],
    ['Concedidas', 'Granted', 'Accordées', 'Concedidos', '已授予', '허용됨'],
    ['Conceder permissões', 'Grant permissions', 'Accorder les autorisations', 'Conceder permisos', '授予权限', '권한 허용'],
    ['Permissões necessárias', 'Permissions needed', 'Autorisations requises', 'Permisos necesarios', '需要权限', '필요한 권한'],
    ['Vamos configurar o Chats', 'Let’s set up Chats', 'Configurons Chats', 'Vamos a configurar Chats', '开始设置 Chats', 'Chats 설정하기'],
    ['Definir como predefinida', 'Set as default', 'Définir par défaut', 'Establecer como predeterminada', '设为默认', '기본 앱으로 설정'],
    ['Predefinido', 'Default', 'Par défaut', 'Predeterminado', '默认', '기본값'],
    ['Lixo', 'Trash', 'Corbeille', 'Papelera', '回收站', '휴지통'],
    ['Esvaziar lixo', 'Empty trash', 'Vider la corbeille', 'Vaciar papelera', '清空回收站', '휴지통 비우기'],
    ['Conversas eliminadas', 'Deleted conversations', 'Conversations supprimées', 'Conversaciones eliminadas', '已删除的对话', '삭제된 대화'],
    ['Conversa eliminada', 'Conversation deleted', 'Conversation supprimée', 'Conversación eliminada', '对话已删除', '대화가 삭제되었습니다'],
    ['Conversa fixada', 'Conversation pinned', 'Conversation épinglée', 'Conversación fijada', '对话已置顶', '대화가 고정되었습니다'],
    ['Conversa desafixada', 'Conversation unpinned', 'Conversation désépinglée', 'Conversación desfijada', '已取消置顶', '고정이 해제되었습니다'],
    ['Conversa silenciada', 'Conversation muted', 'Conversation mise en sourdine', 'Conversación silenciada', '对话已静音', '대화가 음소거되었습니다'],
    ['Notificações reativadas', 'Notifications turned on', 'Notifications réactivées', 'Notificaciones reactivadas', '通知已重新开启', '알림이 다시 켜졌습니다'],
    ['Silenciar conversa', 'Mute conversation', 'Mettre la conversation en sourdine', 'Silenciar conversación', '静音对话', '대화 음소거'],
    ['Reativar notificações', 'Turn notifications back on', 'Réactiver les notifications', 'Reactivar notificaciones', '重新开启通知', '알림 다시 켜기'],
    ['Fixar no topo', 'Pin to top', 'Épingler en haut', 'Fijar arriba', '置顶', '맨 위에 고정'],
    ['Eliminar conversa', 'Delete conversation', 'Supprimer la conversation', 'Eliminar conversación', '删除对话', '대화 삭제'],
    ['Eliminar conversa?', 'Delete conversation?', 'Supprimer la conversation ?', '¿Eliminar conversación?', '删除对话？', '대화를 삭제할까요?'],
    ['Todas as mensagens desta conversa serão eliminadas.', 'All messages in this conversation will be deleted.', 'Tous les messages de cette conversation seront supprimés.', 'Se eliminarán todos los mensajes de esta conversación.', '此对话中的所有消息都将被删除。', '이 대화의 모든 메시지가 삭제됩니다.'],
    ['Eliminar mensagem', 'Delete message', 'Supprimer le message', 'Eliminar mensaje', '删除消息', '메시지 삭제'],
    ['Eliminar tudo', 'Delete all', 'Tout supprimer', 'Eliminar todo', '全部删除', '모두 삭제'],
    ['Eliminar para sempre', 'Delete forever', 'Supprimer définitivement', 'Eliminar para siempre', '永久删除', '영구 삭제'],
    ['Copiar texto', 'Copy text', 'Copier le texte', 'Copiar texto', '复制文本', '텍스트 복사'],
    ['Copiado', 'Copied', 'Copié', 'Copiado', '已复制', '복사됨'],
    ['Número copiado', 'Number copied', 'Numéro copié', 'Número copiado', '号码已复制', '번호가 복사되었습니다'],
    ['Adicionar aos favoritos', 'Add to favorites', 'Ajouter aux favoris', 'Añadir a favoritos', '添加到收藏', '즐겨찾기에 추가'],
    ['Remover dos favoritos', 'Remove from favorites', 'Retirer des favoris', 'Quitar de favoritos', '从收藏中移除', '즐겨찾기에서 삭제'],
    ['Detalhes da mensagem', 'Message details', 'Détails du message', 'Detalles del mensaje', '消息详情', '메시지 상세정보'],
    ['Fundo desta conversa', 'This chat’s background', 'Arrière-plan de cette conversation', 'Fondo de esta conversación', '此对话的背景', '이 대화의 배경'],
    ['Adicionar aos contactos', 'Add to contacts', 'Ajouter aux contacts', 'Añadir a contactos', '添加到联系人', '연락처에 추가'],
    ['Adicionar foto', 'Add photo', 'Ajouter une photo', 'Añadir foto', '添加照片', '사진 추가'],
    ['Alterar foto', 'Change photo', 'Changer la photo', 'Cambiar foto', '更换照片', '사진 변경'],
    ['Remover foto', 'Remove photo', 'Retirer la photo', 'Quitar foto', '移除照片', '사진 삭제'],
    ['Foto atualizada', 'Photo updated', 'Photo mise à jour', 'Foto actualizada', '照片已更新', '사진이 업데이트되었습니다'],
    ['Foto removida', 'Photo removed', 'Photo retirée', 'Foto eliminada', '照片已移除', '사진이 삭제되었습니다'],
    ['Telemóvel · toque para copiar', 'Phone · tap to copy', 'Téléphone · touchez pour copier', 'Teléfono · toca para copiar', '手机 · 点按复制', '전화 · 눌러서 복사'],
    ['Serviço / número não gravado', 'Service / unsaved number', 'Service / numéro non enregistré', 'Servicio / número no guardado', '服务 / 未保存号码', '서비스 / 저장되지 않은 번호'],
    ['Imagens', 'Images', 'Images', 'Imágenes', '图片', '이미지'],
    ['Imagem', 'Image', 'Image', 'Imagen', '图片', '이미지'],
    ['Vídeo', 'Video', 'Vidéo', 'Vídeo', '视频', '동영상'],
    ['Áudio', 'Audio', 'Audio', 'Audio', '音频', '오디오'],
    ['Localização', 'Location', 'Position', 'Ubicación', '位置', '위치'],
    ['Anexos e ações', 'Attachments and actions', 'Pièces jointes et actions', 'Adjuntos y acciones', '附件和操作', '첨부 및 작업'],
    ['Gravar mensagem de voz', 'Record voice message', 'Enregistrer un message vocal', 'Grabar mensaje de voz', '录制语音消息', '음성 메시지 녹음'],
    ['Programar mensagem', 'Schedule message', 'Programmer un message', 'Programar mensaje', '定时发送消息', '메시지 예약'],
    ['Programar', 'Schedule', 'Programmer', 'Programar', '定时', '예약'],
    ['Mensagens programadas', 'Scheduled messages', 'Messages programmés', 'Mensajes programados', '定时消息', '예약된 메시지'],
    ['Nada programado', 'Nothing scheduled', 'Rien de programmé', 'Nada programado', '没有定时消息', '예약된 항목 없음'],
    ['Emojis', 'Emojis', 'Émojis', 'Emojis', '表情符号', '이모지'],
    ['Notas', 'Notes', 'Notes', 'Notas', '笔记', '메모'],
    ['Nova nota', 'New note', 'Nouvelle note', 'Nueva nota', '新笔记', '새 메모'],
    ['Agenda', 'Calendar', 'Agenda', 'Agenda', '日程', '일정'],
    ['Entregue ✓✓', 'Delivered ✓✓', 'Livré ✓✓', 'Entregado ✓✓', '已送达 ✓✓', '전달됨 ✓✓'],
    ['Enviada', 'Sent', 'Envoyé', 'Enviado', '已发送', '전송됨'],
    ['Recebida', 'Received', 'Reçu', 'Recibido', '已接收', '수신됨'],
    ['A enviar', 'Sending', 'Envoi en cours', 'Enviando', '发送中', '전송 중'],
    ['Falha no envio', 'Sending failed', 'Échec de l’envoi', 'Error al enviar', '发送失败', '전송 실패'],
    ['Entrega falhou', 'Delivery failed', 'Échec de la livraison', 'Falló la entrega', '送达失败', '전달 실패'],
    ['Não entregue', 'Not delivered', 'Non livré', 'No entregado', '未送达', '전달되지 않음'],
    ['Não enviada', 'Not sent', 'Non envoyé', 'No enviado', '未发送', '전송되지 않음'],
    ['Falhou. Tocar para tentar novamente', 'Failed. Tap to try again', 'Échec. Touchez pour réessayer', 'Falló. Toca para reintentar', '发送失败，点按重试', '실패. 눌러서 다시 시도'],
    ['Mensagem multimédia', 'Multimedia message', 'Message multimédia', 'Mensaje multimedia', '多媒体消息', '멀티미디어 메시지'],
    ['Transferir', 'Download', 'Télécharger', 'Descargar', '下载', '다운로드'],
    ['Transferir multimédia', 'Download media', 'Télécharger le média', 'Descargar multimedia', '下载多媒体', '미디어 다운로드'],
    ['Reproduzir', 'Play', 'Lire', 'Reproducir', '播放', '재생'],
    ['Pausar', 'Pause', 'Pause', 'Pausar', '暂停', '일시정지'],
    ['Marcar tudo como lido', 'Mark all as read', 'Tout marquer comme lu', 'Marcar todo como leído', '全部标为已读', '모두 읽음으로 표시'],
    ['Tudo marcado como lido', 'All marked as read', 'Tout est marqué comme lu', 'Todo marcado como leído', '已全部标为已读', '모두 읽음으로 표시됨'],
    ['Marcar como não lida', 'Mark as unread', 'Marquer comme non lu', 'Marcar como no leída', '标为未读', '읽지 않음으로 표시'],
    ['Número bloqueado', 'Number blocked', 'Numéro bloqué', 'Número bloqueado', '号码已屏蔽', '번호가 차단되었습니다'],
    ['Sem números bloqueados', 'No blocked numbers', 'Aucun numéro bloqué', 'Sin números bloqueados', '没有已屏蔽号码', '차단된 번호 없음'],
    ['Número desconhecido', 'Unknown number', 'Numéro inconnu', 'Número desconocido', '未知号码', '알 수 없는 번호'],
    ['Desconhecido', 'Unknown', 'Inconnu', 'Desconocido', '未知', '알 수 없음'],
    ['Nada aqui', 'Nothing here', 'Rien ici', 'Nada aquí', '这里空空如也', '여기에는 아무것도 없습니다'],
    ['Nada arquivado', 'Nothing archived', 'Rien d’archivé', 'Nada archivado', '没有已归档内容', '보관된 항목 없음'],
    ['Sem favoritas', 'No favorites', 'Aucun favori', 'Sin favoritas', '没有收藏', '즐겨찾기 없음'],
    ['Mensagens favoritas', 'Favorite messages', 'Messages favoris', 'Mensajes favoritos', '收藏的消息', '즐겨찾기 메시지'],
    ['Proteção do lixo', 'Trash protection', 'Protection de la corbeille', 'Protección de la papelera', '回收站保护', '휴지통 보호'],
    ['Fundo aplicado', 'Background applied', 'Arrière-plan appliqué', 'Fondo aplicado', '背景已应用', '배경이 적용되었습니다'],
    ['Fundo original restaurado', 'Original background restored', 'Arrière-plan d’origine restauré', 'Fondo original restaurado', '已恢复原背景', '원래 배경으로 복원되었습니다'],
    ['Restaurar original', 'Restore original', 'Restaurer l’original', 'Restaurar original', '恢复原样', '원본 복원'],
    ['Desfocagem', 'Blur', 'Flou', 'Desenfoque', '模糊', '흐림 효과'],
    ['Filtro de legibilidade', 'Readability filter', 'Filtre de lisibilité', 'Filtro de legibilidad', '可读性滤镜', '가독성 필터'],
    ['Tamanho do texto', 'Text size', 'Taille du texte', 'Tamaño del texto', '文字大小', '글자 크기'],
    ['Arredondamento', 'Roundness', 'Arrondi', 'Redondeo', '圆角', '모서리 둥글기'],
    ['Balão enviado', 'Sent bubble', 'Bulle envoyée', 'Burbuja enviada', '已发送气泡', '보낸 말풍선'],
    ['Balão recebido', 'Received bubble', 'Bulle reçue', 'Burbuja recibida', '已接收气泡', '받은 말풍선'],
    ['Clássico', 'Classic', 'Classique', 'Clásico', '经典', '클래식'],
    ['Redondo', 'Round', 'Arrondi', 'Redondo', '圆润', '둥근'],
    ['Com cauda', 'With tail', 'Avec queue', 'Con cola', '带尾巴', '꼬리형'],
    ['Quadrado', 'Square', 'Carré', 'Cuadrado', '方形', '사각형'],
    ['Degradé', 'Gradient', 'Dégradé', 'Degradado', '渐变', '그라데이션'],
    ['Contorno', 'Outline', 'Contour', 'Contorno', '描边', '윤곽선'],
    ['Vidro', 'Glass', 'Verre', 'Vidrio', '玻璃', '유리'],
    ['Cristal', 'Crystal', 'Cristal', 'Cristal', '水晶', '크리스털'],
    ['Aurora', 'Aurora', 'Aurore', 'Aurora', '极光', '오로라'],
    ['Elegante', 'Elegant', 'Élégant', 'Elegante', '典雅', '우아함'],
    ['Seda', 'Silk', 'Soie', 'Seda', '丝绸', '실크'],
    ['Neon', 'Neon', 'Néon', 'Neón', '霓虹', '네온'],
    ['Tamanho da fonte do app', 'App font size', 'Taille de police de l’app', 'Tamaño de fuente de la app', '应用字体大小', '앱 글꼴 크기'],
    ['Pequena', 'Small', 'Petite', 'Pequeña', '小', '작게'],
    ['Normal', 'Normal', 'Normale', 'Normal', '标准', '보통'],
    ['Grande', 'Large', 'Grande', 'Grande', '大', '크게'],
    ['Enorme', 'Extra large', 'Très grande', 'Muy grande', '特大', '매우 크게'],
    ['Idioma', 'Language', 'Langue', 'Idioma', '语言', '언어'],
    ['Animações', 'Animations', 'Animations', 'Animaciones', '动画', '애니메이션'],
    ['Outro contacto ou número', 'Other contact or number', 'Autre contact ou numéro', 'Otro contacto o número', '其他联系人或号码', '다른 연락처 또는 번호'],
    ['Permitir contactos', 'Allow contacts', 'Autoriser les contacts', 'Permitir contactos', '允许访问联系人', '연락처 허용'],
    ['Aceder aos contactos', 'Access contacts', 'Accéder aux contacts', 'Acceder a contactos', '访问联系人', '연락처 접근'],
    ['Voltar às conversas', 'Back to conversations', 'Retour aux conversations', 'Volver a las conversaciones', '返回对话', '대화로 돌아가기'],
    ['Ir para a última mensagem', 'Go to latest message', 'Aller au dernier message', 'Ir al último mensaje', '跳到最新消息', '최근 메시지로 이동'],
    ['Reencaminhar para', 'Forward to', 'Transférer à', 'Reenviar a', '转发给', '전달 대상'],
    ['Enviar mensagem', 'Send message', 'Envoyer un message', 'Enviar mensaje', '发送消息', '메시지 보내기'],
    ['Enviar e-mail', 'Send email', 'Envoyer un e-mail', 'Enviar correo', '发送电子邮件', '이메일 보내기'],
    ['Abrir ligação', 'Open link', 'Ouvrir le lien', 'Abrir enlace', '打开链接', '링크 열기'],
    ['Partilhar texto', 'Share text', 'Partager le texte', 'Compartir texto', '分享文本', '텍스트 공유'],
    ['Partilhar anexo', 'Share attachment', 'Partager la pièce jointe', 'Compartir adjunto', '分享附件', '첨부파일 공유'],
    ['Diga olá', 'Say hello', 'Dites bonjour', 'Di hola', '打个招呼', '인사해 보세요'],
    ['Estado', 'Status', 'État', 'Estado', '状态', '상태'],
    ['Detalhes', 'Details', 'Détails', 'Detalles', '详情', '상세정보'],
    ['Tipo', 'Type', 'Type', 'Tipo', '类型', '유형'],
    ['Tamanho', 'Size', 'Taille', 'Tamaño', '大小', '크기'],
    ['Assunto', 'Subject', 'Objet', 'Asunto', '主题', '제목'],
    ['Velocidade', 'Speed', 'Vitesse', 'Velocidad', '速度', '속도'],
    ['Limpar cache', 'Clear cache', 'Vider le cache', 'Borrar caché', '清除缓存', '캐시 지우기'],
    ['Cache limpa', 'Cache cleared', 'Cache vidé', 'Caché borrada', '缓存已清除', '캐시를 지웠습니다'],
    ['SMS guardados', 'Saved SMS', 'SMS enregistrés', 'SMS guardados', '已存短信', '저장된 SMS'],
    ['MMS guardados', 'Saved MMS', 'MMS enregistrés', 'MMS guardados', '已存彩信', '저장된 MMS'],
    ['Multimédia', 'Media', 'Médias', 'Multimedia', '多媒体', '미디어'],
    ['Serviços', 'Services', 'Services', 'Servicios', '服务', '서비스'],
    ['Resposta rápida', 'Quick reply', 'Réponse rapide', 'Respuesta rápida', '快捷回复', '빠른 답장'],
    ['Nova resposta rápida', 'New quick reply', 'Nouvelle réponse rapide', 'Nueva respuesta rápida', '新建快捷回复', '새 빠른 답장'],
    ['Gerir respostas', 'Manage replies', 'Gérer les réponses', 'Gestionar respuestas', '管理回复', '답장 관리'],
    ['Resposta guardada', 'Reply saved', 'Réponse enregistrée', 'Respuesta guardada', '回复已保存', '답장이 저장되었습니다'],
    ['Mensagem restaurada', 'Message restored', 'Message restauré', 'Mensaje restaurado', '消息已恢复', '메시지가 복원되었습니다'],
    ['Eliminada', 'Deleted', 'Supprimé', 'Eliminado', '已删除', '삭제됨'],
    ['PIN', 'PIN', 'PIN', 'PIN', 'PIN 码', 'PIN'],
    ['Senha', 'Password', 'Mot de passe', 'Contraseña', '密码', '비밀번호'],
    ['Padrão', 'Pattern', 'Schéma', 'Patrón', '图案', '패턴'],
    ['Verificar atualização', 'Check for updates', 'Rechercher une mise à jour', 'Buscar actualizaciones', '检查更新', '업데이트 확인'],
    ['Procurar atualização', 'Search for update', 'Rechercher la mise à jour', 'Buscar actualización', '查找更新', '업데이트 검색'],
    ['Versão atual', 'Current version', 'Version actuelle', 'Versión actual', '当前版本', '현재 버전'],
    ['Nova versão', 'New version', 'Nouvelle version', 'Nueva versión', '新版本', '새 버전'],
    ['Nova versão disponível', 'New version available', 'Nouvelle version disponible', 'Nueva versión disponible', '有新版本可用', '새 버전이 있습니다'],
    ['A procurar…', 'Checking…', 'Recherche…', 'Buscando…', '正在检查…', '확인 중…'],
    ['A transferir…', 'Downloading…', 'Téléchargement…', 'Descargando…', '正在下载…', '다운로드 중…'],
    ['Transferência concluída', 'Download complete', 'Téléchargement terminé', 'Descarga completada', '下载完成', '다운로드 완료'],
    ['Instalar', 'Install', 'Installer', 'Instalar', '安装', '설치'],
    ['Tem a versão mais recente instalada.', 'You have the latest version installed.', 'Vous avez la dernière version installée.', 'Tienes la última versión instalada.', '您已安装最新版本。', '최신 버전이 설치되어 있습니다.'],
    ['Ainda não há versões publicadas.', 'No releases published yet.', 'Aucune version publiée pour le moment.', 'Aún no hay versiones publicadas.', '尚未发布任何版本。', '아직 게시된 버전이 없습니다.'],
    ['Sem ligação à internet.', 'No internet connection.', 'Pas de connexion internet.', 'Sin conexión a internet.', '没有网络连接。', '인터넷에 연결되어 있지 않습니다.'],
    ['Permita instalar apps desconhecidas para o Chats e toque em Instalar.', 'Allow installing unknown apps for Chats, then tap Install.', 'Autorisez Chats à installer des applis inconnues, puis touchez Installer.', 'Permite instalar apps desconocidas para Chats y toca Instalar.', '请允许 Chats 安装未知应用，然后点按“安装”。', 'Chats의 알 수 없는 앱 설치를 허용한 뒤 설치를 누르세요.'],
    ['Nova atualização disponível', 'Update available', 'Mise à jour disponible', 'Actualización disponible', '有可用更新', '업데이트 사용 가능'],
    ['Está disponível uma nova versão do Chats. Quer atualizar agora?', 'A new version of Chats is available. Do you want to update now?', 'Une nouvelle version de Chats est disponible. Voulez-vous la mettre à jour maintenant ?', 'Hay una nueva versión de Chats disponible. ¿Quieres actualizar ahora?', 'Chats 有新版本可用。要现在更新吗？', 'Chats 새 버전이 있습니다. 지금 업데이트할까요?'],
    ['Atualizar agora', 'Update now', 'Mettre à jour maintenant', 'Actualizar ahora', '立即更新', '지금 업데이트'],
    ['Mais tarde', 'Later', 'Plus tard', 'Más tarde', '稍后', '나중에'],
    ['Sem eventos nos próximos 90 dias.', 'No events in the next 90 days.', 'Aucun événement dans les 90 prochains jours.', 'Sin eventos en los próximos 90 días.', '未来 90 天内没有日程。', '앞으로 90일간 일정이 없습니다.']
  ];
  const IDX = { en: 1, fr: 2, es: 3, zh: 4, ko: 5 };
  const D = {};
  for (const l in IDX) { D[l] = Object.create(null); for (const r of ROWS) D[l][r[0]] = r[IDX[l]]; }

  // Padrões com números / dados variáveis
  const PAT = {
    en: { part: '{n} participants', rec: '{n} recipients', last: 'Last message {x}', sched: 'Scheduled for {x}' },
    fr: { part: '{n} participants', rec: '{n} destinataires', last: 'Dernier message {x}', sched: 'Programmé pour {x}' },
    es: { part: '{n} participantes', rec: '{n} destinatarios', last: 'Último mensaje {x}', sched: 'Programado para {x}' },
    zh: { part: '{n} 位参与者', rec: '{n} 位收件人', last: '最近消息 {x}', sched: '定时于 {x}' },
    ko: { part: '참가자 {n}명', rec: '수신자 {n}명', last: '마지막 메시지 {x}', sched: '예약: {x}' }
  };
  const fill = (t, o) => t.replace(/\{(\w)\}/g, (_, k) => o[k]);
  function rule(k, l) {
    const p = PAT[l]; let m;
    if ((m = /^(\d+) participantes$/.exec(k))) return fill(p.part, { n: m[1] });
    if ((m = /^(\d+) destinatários$/.exec(k))) return fill(p.rec, { n: m[1] });
    if ((m = /^Última mensagem (.+)$/.exec(k))) {
      const x = m[1].replace(/^(hoje|Hoje)/, D[l].Hoje.toLowerCase()).replace(/^(ontem|Ontem)/, D[l].Ontem.toLowerCase());
      return fill(p.last, { x });
    }
    if ((m = /^Programada para (.+)$/.exec(k))) return fill(p.sched, { x: m[1] });
    return undefined;
  }

  // pt-PT → pt-BR (palavras)
  const BR = [
    [/\bTelemóvel\b/g, 'Celular'], [/\btelemóvel\b/g, 'celular'], [/\bEliminar\b/g, 'Excluir'], [/\beliminar\b/g, 'excluir'],
    [/\bEliminada\b/g, 'Excluída'], [/\bEliminadas\b/g, 'Excluídas'], [/\beliminadas\b/g, 'excluídas'], [/\beliminada\b/g, 'excluída'], [/\beliminado\b/g, 'excluído'], [/\beliminados\b/g, 'excluídos'],
    [/\bConversas eliminadas\b/g, 'Conversas excluídas'], [/\bficheiro\b/g, 'arquivo'], [/\bFicheiro\b/g, 'Arquivo'], [/\bficheiros\b/g, 'arquivos'],
    [/\becrã/g, 'tela'], [/\bEcrã/g, 'Tela'], [/\bDefinições\b/g, 'Configurações'], [/\bdefinições\b/g, 'configurações'],
    [/\bPartilhar\b/g, 'Compartilhar'], [/\bpartilhar\b/g, 'compartilhar'], [/\bTransferir\b/g, 'Baixar'], [/\btransferir\b/g, 'baixar'], [/\bTransferência\b/g, 'Download'],
    [/\bA transferir\b/g, 'Baixando'], [/\bA enviar\b/g, 'Enviando'], [/\bA reenviar\b/g, 'Reenviando'],
    [/\bMultimédia\b/g, 'Multimídia'], [/\bmultimédia\b/g, 'multimídia'], [/\bPredefinido\b/g, 'Padrão'], [/\bpredefinido\b/g, 'padrão'],
    [/\bPredefinida\b/g, 'Padrão'], [/\bpredefinida\b/g, 'padrão'], [/\bAplicação\b/g, 'Aplicativo'], [/\baplicação\b/g, 'aplicativo'], [/\baplicações\b/g, 'aplicativos'],
    [/\bContactos\b/g, 'Contatos'], [/\bcontactos\b/g, 'contatos'], [/\bContacto\b/g, 'Contato'], [/\bcontacto\b/g, 'contato'],
    [/\bLixo\b/g, 'Lixeira'], [/\blixo\b/g, 'lixeira'], [/\bDesfocagem\b/g, 'Desfoque'], [/\bGuardar\b/g, 'Salvar'], [/\bguardar\b/g, 'salvar'],
    [/\bguardada\b/g, 'salva'], [/\bguardadas\b/g, 'salvas'], [/\bguardados\b/g, 'salvos'], [/\bGuardados\b/g, 'Salvos'], [/\bligação\b/g, 'link'], [/\bLigação\b/g, 'Link'],
    [/\bReencaminhar\b/g, 'Encaminhar'], [/\bIntroduza\b/g, 'Digite'], [/\bintroduza\b/g, 'digite'], [/\bFotografias\b/g, 'Fotos'], [/\bfotografias\b/g, 'fotos'],
    [/\bUtilizador\b/g, 'Usuário'], [/\butilizador\b/g, 'usuário'], [/\bEnviado\b/g, 'Enviado'], [/\bRecebida\b/g, 'Recebida'],
    [/\bAdicionar aos contatos\b/g, 'Adicionar aos contatos'], [/\bGravar\b/g, 'Gravar'], [/\bApp\b/g, 'App'], [/\bsítio\b/g, 'site'], [/\bequipa\b/g, 'equipe'],
    [/\bEstou a caminho\b/g, 'Estou a caminho'], [/\bA obter localização…/g, 'Obtendo localização…'], [/\bpara (\w+) em\b/g, 'para $1 em']
  ];

  const LANGS = [
    ['pt-PT', 'Português (Portugal)', 'pt-PT'],
    ['pt-BR', 'Português (Brasil)', 'pt-BR'],
    ['en', 'English', 'en'],
    ['fr', 'Français', 'fr'],
    ['es', 'Español', 'es'],
    ['zh', '中文', 'zh-CN'],
    ['ko', '한국어', 'ko']
  ];
  const valid = l => LANGS.some(x => x[0] === l);
  let lang = 'pt-PT';
  try { const s = localStorage.getItem('chats_lang'); if (s && valid(s)) lang = s; } catch (e) { }

  function tr(s) {
    if (lang === 'pt-PT') return s;
    const k = s.trim(); if (!k) return s;
    if (lang === 'pt-BR') { let r = k; for (const [a, b] of BR) r = r.replace(a, b); return r === k ? s : s.replace(k, () => r); }
    let r = D[lang][k]; if (r === undefined) r = rule(k, lang);
    return r === undefined ? s : s.replace(k, () => r);
  }

  // Texto que nunca se traduz: conteúdo das mensagens, nomes, resumos e campos de escrita
  const SKIP = '.bub, .sn, .nm, .snd, .tbub, .tatt, textarea, input, script, style, [data-nt]';
  const ATTRS = ['aria-label', 'placeholder', 'title'];
  const tmap = new WeakMap(), amap = new WeakMap();

  function doText(n) {
    const p = n.parentElement; if (!p || p.closest(SKIP)) return;
    const rec = tmap.get(n), cur = n.nodeValue;
    const o = rec && cur === rec.w ? rec.o : cur;
    const w = tr(o);
    if (w !== cur) n.nodeValue = w;
    if (w !== o || rec) tmap.set(n, { o, w });
  }
  function doAttr(el, a) {
    if (!el.getAttribute || el.closest(SKIP.replace('textarea, input, ', ''))) return;
    const cur = el.getAttribute(a); if (cur == null) return;
    let m = amap.get(el); if (!m) amap.set(el, m = {});
    const rec = m[a], o = rec && cur === rec.w ? rec.o : cur, w = tr(o);
    if (w !== cur) el.setAttribute(a, w);
    if (w !== o || rec) m[a] = { o, w };
  }
  function walk(root) {
    if (!root) return;
    if (root.nodeType === 3) { doText(root); return; }
    if (root.nodeType !== 1) return;
    const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n; while ((n = tw.nextNode())) doText(n);
    const els = root.querySelectorAll ? [root, ...root.querySelectorAll('[aria-label],[placeholder],[title]')] : [root];
    for (const el of els) for (const a of ATTRS) if (el.hasAttribute && el.hasAttribute(a)) doAttr(el, a);
  }

  const mo = new MutationObserver(ms => {
    if (lang === 'pt-PT') return;
    for (const m of ms) {
      if (m.type === 'characterData') doText(m.target);
      else if (m.type === 'attributes') doAttr(m.target, m.attributeName);
      else m.addedNodes.forEach(walk);
    }
  });
  function start() {
    mo.observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
    document.documentElement.lang = lang.split('-')[0];
    walk(document.body);
  }
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);

  window.I18N = {
    LANGS, tr,
    get lang() { return lang; },
    get loc() { return (LANGS.find(x => x[0] === lang) || LANGS[0])[2]; },
    set(l) {
      if (!valid(l)) l = 'pt-PT';
      lang = l; try { localStorage.setItem('chats_lang', l); } catch (e) { }
      document.documentElement.lang = l.split('-')[0];
      if (document.body) walk(document.body);
    }
  };
})();
