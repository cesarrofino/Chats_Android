'use strict';
/* Chats — interface em JavaScript puro. Toda a ação real passa por ChatsNative.call (Kotlin). */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const unesc = s => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&amp;/g, '&');
const wait = ms => new Promise(r => setTimeout(r, ms));
const debounce = (f, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => f(...a), ms); }; };

/* ---------- ponte nativa ---------- */
const cbs = {}; let seq = 0;
window.__cb = (id, ok, p) => { const c = cbs[id]; delete cbs[id]; if (!c) return; ok ? c.res(JSON.parse(p)) : c.rej(new Error(p)); };
const N = (m, a = {}) => new Promise((res, rej) => {
  if (!window.ChatsNative) return rej(new Error('Esta aplicação tem de ser executada no Android.'));
  const id = 'c' + (++seq); cbs[id] = { res, rej };
  try { ChatsNative.call(id, m, JSON.stringify(a)); } catch (e) { delete cbs[id]; rej(e); }
});

/* ---------- ícones ---------- */
const P = {
  back: 'M15 18l-6-6 6-6', search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
  more: '<circle cx="12" cy="5" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="12" cy="19" r="1.2"/>',
  plus: 'M12 5v14M5 12h14', send: 'M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z',
  pin: 'M12 17v5M9 3h6l-1 7 3 4H7l3-4z', archive: '<rect x="3" y="3" width="18" height="5" rx="1"/><path d="M5 8v11a2 2 0 002 2h10a2 2 0 002-2V8M10 12h4"/>',
  trash: 'M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 11v6M14 11v6',
  phone: 'M22 16.9v3a2 2 0 01-2.2 2 19.8 19.8 0 01-8.6-3.1 19.5 19.5 0 01-6-6A19.8 19.8 0 012.1 4.2 2 2 0 014.1 2h3a2 2 0 012 1.7c.1 1 .4 1.9.7 2.8a2 2 0 01-.5 2.1L8 9.9a16 16 0 006 6l1.3-1.3a2 2 0 012.1-.4c.9.3 1.8.6 2.8.7a2 2 0 011.7 2z',
  check: 'M20 6L9 17l-5-5', close: 'M18 6L6 18M6 6l12 12', bell: 'M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 01-3.4 0',
  image: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>',
  video: '<rect x="2" y="5" width="14" height="14" rx="3"/><path d="M22 8l-6 4 6 4z"/>',
  audio: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', bolt: 'M13 2L3 14h8l-1 8 10-12h-8z',
  tag: 'M20.6 13.4l-7.2 7.2a2 2 0 01-2.8 0L3 13V3h10l7.6 7.6a2 2 0 010 2.8zM7.5 7.5h.01',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/>',
  map: '<path d="M12 22s7-6.2 7-12a7 7 0 10-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="10" r="2.5"/>',
  cal: '<rect x="3" y="4" width="18" height="18" rx="3"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  note: '<path d="M14 3H6a2 2 0 00-2 2v14a2 2 0 002 2h12a2 2 0 002-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h5"/>',
  mic: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0014 0M12 18v4"/>',
  copy: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 01-1-1V4a1 1 0 011-1h10a1 1 0 011 1v1"/>',
  fwd: 'M15 14l5-5-5-5M20 9H9a6 6 0 00-6 6v4', share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/>',
  star: 'M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8-6.2-3.3-6.2 3.3L7 14.2 2 9.3l6.9-1z',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5h.01"/>', reply: 'M9 14L4 9l5-5M4 9h10a6 6 0 016 6v4',
  edit: 'M12 20h9M16.5 3.5a2.1 2.1 0 113 3L7 19l-4 1 1-4z', block: '<circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/>',
  mail: '<path d="M4 4h16a2 2 0 012 2v12a2 2 0 01-2 2H4a2 2 0 01-2-2V6a2 2 0 012-2z"/><path d="M22 6l-10 7L2 6"/>',
  sim: '<path d="M6 2h8l6 6v12a2 2 0 01-2 2H6a2 2 0 01-2-2V4a2 2 0 012-2z"/><rect x="8" y="12" width="8" height="6" rx="1"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/>',
  moon: 'M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z', clip: 'M21 11l-9 9a5 5 0 01-7-7l9-9a3.5 3.5 0 015 5l-9 9a2 2 0 01-3-3l8-8',
  dl: 'M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3', retry: 'M23 4v6h-6M1 20v-6h6M3.5 9a9 9 0 0114.9-3.4L23 10M1 14l4.6 4.4A9 9 0 0020.5 15',
  eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>', play: 'M7 4l13 8-13 8z', lock: '<rect x="5" y="11" width="14" height="10" rx="2.5"/><path d="M8 11V8a4 4 0 018 0v3"/>', pause: 'M7 4h3.5v16H7zM13.5 4H17v16h-3.5z',
  chat: 'M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z', list: 'M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01',
  disk: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.7-4 3-9 3s-9-1.3-9-3M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5"/>',
  palette: '<circle cx="12" cy="12" r="9"/><circle cx="8" cy="10" r="1"/><circle cx="12" cy="7.5" r="1"/><circle cx="16" cy="10" r="1"/>',
  unread: '<circle cx="12" cy="12" r="5"/>', del2: 'M6 6l12 12M18 6L6 18',
  compose: '<path d="M11 4H5a2 2 0 00-2 2v13a2 2 0 002 2h13a2 2 0 002-2v-6"/><path d="M18.5 2.5a2.1 2.1 0 013 3L12 15l-4 1 1-4z"/>',
  groups: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0113 0"/><circle cx="17" cy="9" r="2.8"/><path d="M17 14.2a5.5 5.5 0 014.5 5.8"/>',
  smile: '<circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 2 4 2 4-2 4-2M9 9.5h.01M15 9.5h.01"/>',
  kbd: '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/>',
  unk: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="10" r="3"/><path d="M6.2 18.2a6.5 6.5 0 0111.6 0"/>',
  svc: '<rect x="3" y="3" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="2"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="2"/>',
  camera: '<path d="M3 8a2 2 0 012-2h2.5l1.5-2h6l1.5 2H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><circle cx="12" cy="13" r="3.5"/>'
};
const VF = '<svg class="vf" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="10" fill="currentColor"/><path d="M7.5 12.5l3 3 6-6.5" stroke="#fff" fill="none" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const ic = (n, s) => `<svg class="i" viewBox="0 0 24 24"${s ? ` style="width:${s}px;height:${s}px"` : ''}>${/^[<]/.test(P[n]) ? P[n] : `<path d="${P[n]}"/>`}</svg>`;

/* ---------- estado ---------- */
const DEF = {
  theme: 'auto', chatZoom: 1, pinned: [], archived: [], muted: [], favorites: [], notes: [], wp: {},
  quick: ['Já te ligo', 'Estou a caminho', 'Obrigado!', 'Não posso falar agora'],
  bub: { sent: '', recv: '', r: 18, fs: 16 },
  preview: 'full', deliveryReports: true, deliveryNotif: true, notify: true, bubble: true, autoDownload: true, copyCodes: true, sound: '', soundTitle: 'Predefinido', sub: -1
};
const S = { settings: JSON.parse(JSON.stringify(DEF)), threads: [], photos: {}, contacts: null, sims: [], perms: {}, overlay: true, defaultSms: false, exact: true, sdk: 0, drafts: {}, wpc: {}, loaded: false };
const saveSettings = debounce(() => N('setSettings', { json: JSON.stringify(S.settings) }).catch(() => { }), 350);
const set = (k, v) => { S.settings[k] = v; saveSettings(); };
const inList = (k, id) => S.settings[k].includes(id);
const toggleIn = (k, id) => { const a = S.settings[k], i = a.indexOf(id); i >= 0 ? a.splice(i, 1) : a.push(id); saveSettings(); return i < 0; };

/* ---------- tema ---------- */
const mq = matchMedia('(prefers-color-scheme: dark)');
function lum(hex) { const n = parseInt(hex.slice(1), 16); return (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255; }
function applyTheme() {
  const dark = S.settings.theme === 'dark' || (S.settings.theme === 'auto' && mq.matches);
  const r = document.documentElement; r.dataset.t = dark ? 'dark' : 'light';
  const b = S.settings.bub;
  for (const [k, v] of [['sent', b.sent], ['recv', b.recv]]) {
    if (v) { r.style.setProperty('--' + k, v); r.style.setProperty('--' + k + '-ink', lum(v) > .55 ? '#1d2523' : '#f2f7f5'); }
    else { r.style.removeProperty('--' + k); r.style.removeProperty('--' + k + '-ink'); }
  }
  r.style.setProperty('--bub-r', b.r + 'px'); r.style.setProperty('--fs', b.fs + 'px');
  const col = dark ? '#000000' : '#FFFFFF';
  N('setBars', { dark, color: col }).catch(() => { });
}
mq.addEventListener('change', () => S.settings.theme === 'auto' && applyTheme());

/* ---------- utilitários de UI ---------- */
const toastEl = $('#toast'); let tt;
function toast(m, err) { toastEl.textContent = m; toastEl.className = 'on' + (err ? ' err' : ''); clearTimeout(tt); tt = setTimeout(() => toastEl.className = '', err ? 4200 : 2200); }
const fail = e => toast(e && e.message ? e.message : String(e), true);
const scrim = $('#scrim'), sheetEl = $('#sheet'), dlg = $('#dialog'), viewer = $('#viewer');
function openSheet(html, mount) { sheetEl.innerHTML = html; sheetEl.scrollTop = 0; requestAnimationFrame(() => { sheetEl.classList.add('on'); scrim.classList.add('on'); }); mount && mount(sheetEl); }
function closeSheet() { sheetEl.classList.remove('on'); scrim.classList.remove('on'); sheetEl.onclose && sheetEl.onclose(); sheetEl.onclose = null; }
scrim.addEventListener('click', closeSheet);
function menu(items, title) {
  return new Promise(res => {
    let picked = false;
    openSheet((title ? `<h3>${esc(title)}</h3>` : '') + items.filter(Boolean).map((it, i) => `<button class="mi ${it.danger ? 'danger' : ''}" data-i="${i}">${it.icon ? ic(it.icon) : ''}<span class="grow">${esc(it.label)}${it.sub ? `<small>${esc(it.sub)}</small>` : ''}</span></button>`).join(''), el => {
      const list = items.filter(Boolean);
      $$('.mi', el).forEach(b => b.onclick = () => { picked = true; closeSheet(); const it = list[+b.dataset.i]; setTimeout(() => { it.run && it.run(); res(it); }, 160); });
      el.onclose = () => { if (!picked) res(null); };
    });
  });
}
/* ---------- menu de contexto (ecrã desfocado + mensagem + opções) ---------- */
let ctxEl = null;
function closeCtx() { if (!ctxEl) return; const e = ctxEl; ctxEl = null; e.classList.remove('on'); setTimeout(() => e.remove(), 240); }
function ctxMenu(items, el) {
  return new Promise(res => {
    closeCtx(); items = items.filter(Boolean);
    const r = el.getBoundingClientRect(), out = el.classList.contains('out'), vw = innerWidth, vh = innerHeight;
    const ov = document.createElement('div'); ov.id = 'ctx';
    ov.innerHTML = `<div class="cbg"></div><div class="ctxmenu">${items.map((it, i) => `<button class="cmi ${it.danger ? 'danger' : ''}" data-i="${i}"><span>${esc(it.label)}</span>${it.icon ? ic(it.icon) : ''}</button>`).join('')}</div>`;
    const clone = el.cloneNode(true); clone.classList.remove('sel', 'new'); clone.classList.add('ctxmsg'); const zz = el.closest('.msgs'); if (zz) clone.style.setProperty('--cz', zz.style.getPropertyValue('--cz') || 1);
    clone.style.cssText = `left:${r.left}px;top:${r.top}px;width:${r.width}px;max-width:none`;
    ov.insertBefore(clone, ov.querySelector('.ctxmenu'));
    $('#app').appendChild(ov); ctxEl = ov;
    const menuEl = $('.ctxmenu', ov), mh = menuEl.offsetHeight, mw = menuEl.offsetWidth;
    let top = r.top, h = Math.max(r.height, clone.getBoundingClientRect().height || 0);
    const room = vh - 16 - mh - 8;
    if (top + h > room) top = Math.max(76, room - h);
    if (top + h > room) { h = Math.max(70, room - top); clone.style.maxHeight = h + 'px'; clone.style.overflow = 'hidden'; }
    clone.style.top = top + 'px';
    const mt = Math.min(top + h + 8, vh - 16 - mh);
    const ml = Math.max(12, Math.min(vw - mw - 12, out ? r.right - mw : r.left + 36));
    menuEl.style.top = mt + 'px'; menuEl.style.left = ml + 'px';
    requestAnimationFrame(() => ov.classList.add('on'));
    let done = false;
    $('.cbg', ov).onclick = () => { closeCtx(); if (!done) { done = true; res(null); } };
    $$('.cmi', ov).forEach(b => b.onclick = () => { const it = items[+b.dataset.i]; done = true; closeCtx(); setTimeout(() => { it.run && it.run(); res(it); }, 170); });
  });
}
/* ---------- emojis ---------- */
const EMO = [
  ['😀', '😀 😃 😄 😁 😆 😅 😂 🤣 🥲 🥹 ☺️ 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🥸 🤩 🥳 🫠 😏 😒 😞 😔 😟 😕 🙁 ☹️ 😣 😖 😫 😩 🥺 😢 😭 😮‍💨 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🫣 🤗 🫡 🤔 🫢 🤭 🤫 🤥 😶 😶‍🌫️ 😐 😑 😬 🫨 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 😵‍💫 🫥 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 👹 👺 🤡 💩 👻 💀 ☠️ 👽 👾 🤖 🎃 😺 😸 😹 😻 😼 😽 🙀 😿 😾'],
  ['👍', '👍 👎 👌 🤌 🤏 ✌️ 🤞 🫰 🤟 🤘 🤙 👈 👉 👆 🖕 👇 ☝️ 🫵 👋 🤚 🖐️ ✋ 🖖 🫱 🫲 🫳 🫴 👏 🙌 🫶 👐 🤲 🤝 🙏 ✍️ 💅 🤳 💪 🦾 🦵 🦶 👂 🦻 👃 🧠 🫀 🫁 🦷 🦴 👀 👁️ 👅 👄 🫦 👶 🧒 👦 👧 🧑 👱 👨 🧔 👩 🧓 👴 👵 🙍 🙎 🙅 🙆 💁 🙋 🧏 🙇 🤦 🤷 👮 🕵️ 💂 🥷 👷 🤴 👸 👳 👲 🧕 🤵 👰 🤰 🫃 🤱 👼 🎅 🤶 🦸 🦹 🧙 🧚 🧛 🧜 🧝 🧞 🧟 💆 💇 🚶 🧍 🧎 🏃 💃 🕺 👯 🧖 🧗 🏇 🏂 🏌️ 🏄 🚣 🏊 ⛹️ 🏋️ 🚴 🤸 🤼 🤽 🤾 🤹 🧘 🛀 🛌 👭 👫 👬 💏 💑 👪'],
  ['❤️', '❤️ 🧡 💛 💚 💙 🩵 💜 🖤 🩶 🤍 🤎 ❤️‍🔥 ❤️‍🩹 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ♥️ 💌 💋 💍 💎 🔥 ✨ ⭐ 🌟 💫 💥 💢 💦 💨 💤 💬 💭 🗯️ 💯 ✅ ☑️ ✔️ ❌ ❎ ❓ ❔ ❗ ❕ ‼️ ⁉️ ⚠️ 🚫 ⛔ 🔞 🆗 🆒 🆕 🆓 🔝 🔜 ➕ ➖ ➗ ✖️ ♾️ 💲 ©️ ®️ ™️ ☮️ ☯️ ✝️ ☪️ 🕉️ ✡️ 🔯 ♈ ♉ ♊ ♋ ♌ ♍ ♎ ♏ ♐ ♑ ♒ ♓ ⛎ 🔔 🔕 🎵 🎶 ➡️ ⬅️ ⬆️ ⬇️ ↗️ ↘️ ↙️ ↖️ ↔️ ↕️ 🔄 🔁 🔀 ▶️ ⏸️ ⏹️ ⏺️ ⏭️ ⏮️ 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 🟤 🔶 🔷 🔸 🔹 🔺 🔻 ⭕ ✳️ ❇️ 🔰'],
  ['🐶', '🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐻‍❄️ 🐼 🐨 🐯 🦁 🐮 🐷 🐽 🐸 🐵 🙈 🙉 🙊 🐒 🐔 🐧 🐦 🐤 🐣 🐥 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🪱 🐛 🦋 🐌 🐞 🐜 🪰 🪲 🦟 🦗 🕷️ 🦂 🐢 🐍 🦎 🦖 🦕 🐙 🦑 🦐 🦞 🦀 🐡 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐅 🐆 🦓 🦍 🐘 🦛 🦏 🐪 🐫 🦒 🦘 🐃 🐂 🐄 🐎 🐖 🐏 🐑 🦙 🐐 🦌 🐕 🐩 🐈 🐈‍⬛ 🐓 🦃 🦚 🦜 🦢 🦩 🕊️ 🐇 🦝 🦨 🦡 🦫 🦦 🦥 🐁 🐀 🐿️ 🦔 🐾 🐉 🐲 🌵 🎄 🌲 🌳 🌴 🪵 🌱 🌿 ☘️ 🍀 🎍 🍃 🍂 🍁 🍄 🐚 🌾 💐 🌷 🌹 🥀 🌺 🌸 🌼 🌻 🌞 🌝 🌛 🌜 🌚 🌕 🌖 🌗 🌘 🌑 🌒 🌓 🌔 🌙 🌎 🌍 🌏 🪐 💫 ⭐ 🌟 ✨ ⚡ ☄️ 💥 🔥 🌪️ 🌈 ☀️ 🌤️ ⛅ 🌥️ ☁️ 🌦️ 🌧️ ⛈️ 🌩️ 🌨️ ❄️ ☃️ ⛄ 🌬️ 💨 💧 💦 ☔ 🌊'],
  ['🍎', '🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🫐 🍈 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🍆 🥑 🥦 🥬 🥒 🌶️ 🫑 🌽 🥕 🫒 🧄 🧅 🥔 🍠 🥐 🥯 🍞 🥖 🥨 🧀 🥚 🍳 🧈 🥞 🧇 🥓 🥩 🍗 🍖 🦴 🌭 🍔 🍟 🍕 🫓 🥪 🥙 🧆 🌮 🌯 🫔 🥗 🥘 🫕 🥫 🍝 🍜 🍲 🍛 🍣 🍱 🥟 🦪 🍤 🍙 🍚 🍘 🍥 🥠 🥮 🍢 🍡 🍧 🍨 🍦 🥧 🧁 🍰 🎂 🍮 🍭 🍬 🍫 🍿 🍩 🍪 🌰 🥜 🍯 🥛 🍼 🫖 ☕ 🍵 🧃 🥤 🧋 🍶 🍺 🍻 🥂 🍷 🥃 🍸 🍹 🧉 🍾 🧊 🥄 🍴 🍽️ 🥣 🥡 🥢 🧂'],
  ['⚽', '⚽ 🏀 🏈 ⚾ 🥎 🎾 🏐 🏉 🥏 🎱 🪀 🏓 🏸 🏒 🏑 🥍 🏏 🥅 ⛳ 🪁 🏹 🎣 🤿 🥊 🥋 🎽 🛹 🛼 🛷 ⛸️ 🥌 🎿 ⛷️ 🏂 🏆 🥇 🥈 🥉 🏅 🎖️ 🎗️ 🎫 🎟️ 🎪 🎭 🎨 🎬 🎤 🎧 🎼 🎹 🥁 🪘 🎷 🎺 🪗 🎸 🪕 🎻 🎲 ♟️ 🎯 🎳 🎮 🕹️ 🎰 🧩 🧸 🪅 🎁 🎀 🎊 🎉 🎈 🎂 🎄 🎃 🎆 🎇 🧨 ✨'],
  ['🚗', '🚗 🚕 🚙 🚌 🚎 🏎️ 🚓 🚑 🚒 🚐 🛻 🚚 🚛 🚜 🏍️ 🛵 🚲 🛴 🚨 🚔 🚍 🚘 🚖 🚡 🚠 🚟 🚃 🚋 🚞 🚝 🚄 🚅 🚈 🚂 🚆 🚇 🚊 🚉 ✈️ 🛫 🛬 🛩️ 💺 🛰️ 🚀 🛸 🚁 🛶 ⛵ 🚤 🛥️ 🛳️ ⛴️ 🚢 ⚓ ⛽ 🚧 🚦 🚥 🗺️ 🗿 🗽 🗼 🏰 🏯 🏟️ 🎡 🎢 🎠 ⛲ ⛱️ 🏖️ 🏝️ 🏜️ 🌋 ⛰️ 🏔️ 🗻 🏕️ ⛺ 🏠 🏡 🏘️ 🏢 🏣 🏤 🏥 🏦 🏨 🏪 🏫 🏬 🏭 ⛪ 🕌 🕍 🌅 🌄 🌇 🌆 🌃 🌉 🌁 🎑'],
  ['💡', '⌚ 📱 📲 💻 ⌨️ 🖥️ 🖨️ 🖱️ 💽 💾 💿 📀 📷 📸 📹 🎥 📽️ 📺 📻 🎙️ ⏰ ⏱️ ⏲️ ⌛ ⏳ 📡 🔋 🔌 💡 🔦 🕯️ 🧯 💸 💵 💴 💶 💷 💰 💳 🧾 ⚖️ 🔧 🔨 ⚒️ 🛠️ ⛏️ 🔩 ⚙️ 🧱 🔫 💣 🧲 🔪 🗡️ ⚔️ 🛡️ 🚬 ⚰️ 🔮 📿 🧿 💈 ⚗️ 🔭 🔬 🕳️ 🩹 🩺 💊 💉 🩸 🧬 🦠 🧫 🧪 🌡️ 🧹 🧺 🧻 🚽 🚰 🚿 🛁 🧼 🪥 🧽 🛒 🚪 🛋️ 🛏️ 🧸 🖼️ 🔑 🗝️ 🔒 🔓 🔏 🔐 📞 ☎️ 📟 📠 ✉️ 📧 📨 📩 📦 📫 📮 📝 📄 📃 📑 📊 📈 📉 📋 📌 📍 📎 🖇️ 📏 📐 ✂️ 🗃️ 🗄️ 🗑️ 📅 📆 📓 📔 📒 📕 📗 📘 📙 📚 📖 🔖 🏷️ ✏️ ✒️ 🖋️ 🖊️ 🖌️ 🖍️ 🔍 🔎'],
  ['🏳️', '🏳️ 🏴 🏁 🚩 🎌 🏴‍☠️ 🏳️‍🌈 🇧🇷 🇦🇴 🇲🇿 🇨🇻 🇬🇼 🇸🇹 🇹🇱 🇵🇹 🇪🇸 🇫🇷 🇮🇹 🇩🇪 🇬🇧 🇮🇪 🇧🇪 🇳🇱 🇨🇭 🇱🇺 🇸🇪 🇳🇴 🇩🇰 🇫🇮 🇵🇱 🇺🇦 🇷🇺 🇹🇷 🇬🇷 🇺🇸 🇨🇦 🇲🇽 🇦🇷 🇨🇱 🇨🇴 🇵🇪 🇻🇪 🇺🇾 🇵🇾 🇧🇴 🇪🇨 🇨🇺 🇯🇲 🇭🇹 🇩🇴 🇯🇵 🇰🇷 🇨🇳 🇮🇳 🇦🇺 🇳🇿 🇿🇦 🇳🇬 🇪🇬 🇲🇦 🇸🇳 🇬🇭 🇰🇪 🇪🇹 🇸🇦 🇦🇪 🇮🇱 🇮🇷 🇮🇶 🇵🇰 🇹🇭 🇻🇳 🇵🇭 🇮🇩 🇲🇾 🇸🇬 🇪🇺 🇺🇳']
];
let emoCat = 0;
function closeEmo() { const p = $('#emo'); if (!p || p.hidden) return false; p.hidden = true; const b = $('#emb'); if (b) b.innerHTML = ic('smile', 24); return true; }
function initEmoji() {
  const ta = $('#ta'), btn = $('#emb'), panel = $('#emo'); if (!ta || !btn || !panel) return;
  const draw = () => {
    panel.innerHTML = `<div class="etabs">${EMO.map((c, i) => `<button class="${i === emoCat ? 'on' : ''}" data-c="${i}">${c[0]}</button>`).join('')}<button id="ebs" aria-label="Apagar">⌫</button></div><div class="egrid">${EMO[emoCat][1].split(' ').map(e => `<button data-e="${e}">${e}</button>`).join('')}</div>`;
  };
  const changed = () => ta.dispatchEvent(new Event('input'));
  panel.onclick = e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.c != null) { emoCat = +b.dataset.c; draw(); return; }
    if (b.id === 'ebs') { const s = ta.selectionStart, arr = [...ta.value.slice(0, s)]; if (!arr.length) return; arr.pop(); const nb = arr.join(''); ta.value = nb + ta.value.slice(ta.selectionEnd); ta.selectionStart = ta.selectionEnd = nb.length; changed(); return; }
    if (b.dataset.e) { const s = ta.selectionStart ?? ta.value.length, e2 = ta.selectionEnd ?? s; ta.value = ta.value.slice(0, s) + b.dataset.e + ta.value.slice(e2); ta.selectionStart = ta.selectionEnd = s + b.dataset.e.length; changed(); }
  };
  btn.onclick = () => {
    if (!panel.hidden) { closeEmo(); ta.focus(); return; }
    ta.blur(); draw(); panel.hidden = false; btn.innerHTML = ic('kbd', 24);
    setTimeout(() => { const m = $('#msgs'); if (m) m.scrollTop = m.scrollHeight; }, 60);
  };
  ta.addEventListener('focus', closeEmo);
}
function dialog({ title, text, html, ok = 'OK', cancel, danger, input, area, value = '' }) {
  return new Promise(res => {
    dlg.innerHTML = `<div class="box"><h3>${esc(title || '')}</h3>${text ? `<p>${esc(text)}</p>` : ''}${html || ''}${input ? `<input id="dgi" class="inp" placeholder="${esc(input)}" value="${esc(value)}">` : ''}${area ? `<textarea id="dgi" class="inp" rows="5" placeholder="${esc(area)}">${esc(value)}</textarea>` : ''}<div class="btns">${cancel ? `<button class="btn ghost" id="dgc">${esc(cancel)}</button>` : ''}<button class="btn ${danger ? 'danger' : ''}" id="dgo">${esc(ok)}</button></div></div>`;
    dlg.classList.add('on');
    const done = v => { dlg.classList.remove('on'); setTimeout(() => dlg.innerHTML = '', 260); dlg.onclose = null; res(v); };
    dlg.onclose = () => done(null);
    $('#dgo').onclick = () => done(input || area ? $('#dgi').value : true);
    const c = $('#dgc'); if (c) c.onclick = () => done(null);
    if (input || area) setTimeout(() => $('#dgi').focus(), 300);
  });
}
const confirmBox = (title, text, ok = 'Eliminar') => dialog({ title, text, ok, cancel: 'Cancelar', danger: true });

/* ---------- formatação ---------- */
const pad = n => String(n).padStart(2, '0');
function hhmm(ms) { const d = new Date(ms); return pad(d.getHours()) + ':' + pad(d.getMinutes()); }
function dayKey(ms) { const d = new Date(ms); return d.getFullYear() * 400 + d.getMonth() * 32 + d.getDate(); }
function dayLabel(ms) {
  const d = new Date(ms), n = new Date(), diff = Math.round((new Date(n.getFullYear(), n.getMonth(), n.getDate()) - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 864e5);
  if (diff === 0) return 'Hoje'; if (diff === 1) return 'Ontem';
  return d.toLocaleDateString('pt-PT', { weekday: diff < 7 ? 'long' : undefined, day: 'numeric', month: 'long', year: d.getFullYear() === n.getFullYear() ? undefined : 'numeric' });
}
function short(ms) {
  const d = new Date(ms), n = new Date(), diff = Math.round((new Date(n.getFullYear(), n.getMonth(), n.getDate()) - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 864e5);
  if (diff === 0) return hhmm(ms);
  if (diff > 0 && diff < 7) return d.toLocaleDateString('pt-PT', { weekday: 'short' });
  if (d.getFullYear() === n.getFullYear()) return d.toLocaleDateString('pt-PT', { day: 'numeric', month: 'short' });
  return pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + String(d.getFullYear()).slice(2);
}
const full = ms => ms ? new Date(ms).toLocaleString('pt-PT') : '—';
const kb = n => n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';
const GSM = /^[@£$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !"#¤%&'()*+,\-./0-9:;<=>?¡A-ZÄÖÑÜ§¿a-zäöñüà^{}\\\[~\]|€]*$/;
function segs(t) {
  const uni = !GSM.test(t); let len = uni ? [...t].length : [...t].reduce((a, c) => a + ('^{}\\[~]|€'.includes(c) ? 2 : 1), 0);
  const one = uni ? 70 : 160, per = uni ? 67 : 153, n = len <= one ? 1 : Math.ceil(len / per);
  return { len, n, uni, max: n === 1 ? one : per * n };
}
const hue = s => { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h % 7; };
const PAL = [['#FF885E', '#FF516A'], ['#FFCD6A', '#FFA85C'], ['#82B1FF', '#665FFF'], ['#A0DE7E', '#54CB68'], ['#53EDD6', '#28C9B7'], ['#72D5FD', '#2A9EF1'], ['#FF8FB8', '#E5579B']];
/* Remetente de serviço (nome com letras ou número curto): só recebe, não se responde. */
function svcAddr(addrs) { return addrs.length > 0 && addrs.some(a => /[A-Za-z]/.test(a) || a.replace(/\D/g, '').length <= 6); }
function avatar(addrs, name, cls = '', extra = '') {
  const a = addrs[0] || name, ph = S.photos[a], c = PAL[hue(a || '?')];
  if (!ph && svcAddr(addrs)) return `<div class="av svc ${cls}" style="background-image:linear-gradient(150deg,#6B7A99,#2E3A57)">${ic('svc', cls === 'xl' ? 48 : cls === 'xs' ? 14 : cls === 'sm' ? 20 : 24)}${extra}</div>`;
  const letters = /^[\d+\s()-]*$/.test(name || '') ? null : (name || '').split(/\s+/).filter(Boolean).slice(0, 2).map(w => [...w][0].toUpperCase()).join('');
  const bg = ph ? `background-image:url(${ph})` : `background-image:linear-gradient(150deg,${c[0]},${c[1]})`;
  return `<div class="av ${cls}" style="${bg}">${ph ? '' : (addrs.length > 1 ? ic('user', 24) : letters || ic('user', 24))}${extra}</div>`;
}
function linkify(raw) {
  return esc(raw).replace(/(\bhttps?:\/\/[^\s<]+|\bwww\.[^\s<]+)|([\w.+-]+@[\w-]+\.[\w.-]+)|((?<![\w+])\+?\d[\d ()\-]{6,}\d)/gi, (m, u, e, p) => {
    const t = u ? 'url' : e ? 'mail' : 'tel';
    return `<span class="lk" data-t="${t}" data-v="${encodeURIComponent(unesc(m))}">${m}</span>`;
  });
}
function linkSheet(t, v) {
  const items = t === 'url' ? [{ icon: 'eye', label: 'Abrir ligação', run: () => N('openUrl', { url: /^https?:/i.test(v) ? v : 'https://' + v }).catch(fail) }, { icon: 'copy', label: 'Copiar', run: () => N('copy', { text: v }).then(() => toast('Copiado')) }]
    : t === 'mail' ? [{ icon: 'mail', label: 'Enviar e-mail', run: () => N('openUrl', { url: 'mailto:' + v }).catch(fail) }, { icon: 'copy', label: 'Copiar', run: () => N('copy', { text: v }).then(() => toast('Copiado')) }]
      : [{ icon: 'phone', label: 'Ligar', sub: v, run: () => N('dial', { number: v }).catch(fail) }, { icon: 'chat', label: 'Enviar mensagem', run: () => startChat([v.replace(/[^\d+]/g, '')]) }, { icon: 'user', label: 'Adicionar aos contactos', run: () => N('addContact', { number: v }).catch(fail) }, { icon: 'copy', label: 'Copiar', run: () => N('copy', { text: v }).then(() => toast('Copiado')) }];
  menu(items);
}

/* ---------- navegação ---------- */
const stage = $('#stage'), views = [];
function push(name, render, o = {}) {
  const el = document.createElement('section'); el.className = 'view ' + (o.cls || ''); stage.appendChild(el);
  const prev = views[views.length - 1]; if (prev) prev.el.classList.add('under');
  const v = { name, el, ...o }; views.push(v); render(el, v); return v;
}
let lastPop = 0;
function pop() {
  if (views.length <= 1) return false;
  const now = Date.now(); if (now - lastPop < 280) return true; lastPop = now; // evita duplo toque a fechar duas vistas
  const v = views.pop(); v.el.classList.add('out'); v.onClose && v.onClose(); setTimeout(() => v.el.remove(), 300);
  const p = views[views.length - 1]; p.el.classList.remove('under'); p.onShow && p.onShow(); return true;
}
document.addEventListener('pointerup', e => {
  const b = e.target.closest && e.target.closest('.view .top button[aria-label="Voltar"]');
  if (b && e.isPrimary) { e.preventDefault(); pop(); }
}, true);
window.__back = () => {
  if (ctxEl) { closeCtx(); return true; }
  if (dlg.classList.contains('on')) { dlg.onclose && dlg.onclose(); return true; }
  if (viewer.classList.contains('on')) { viewer.classList.remove('on'); return true; }
  if (sheetEl.classList.contains('on')) { closeSheet(); return true; }
  const v = views[views.length - 1];
  if (v && v.onBack && v.onBack()) return true;
  return pop();
};

/* =====================================================================
   CAIXA DE ENTRADA
   ===================================================================== */
const H = { limit: 60, total: 0, cat: 'chats', tab: 'all', q: '', sel: new Set(), msgRes: [], first: true, el: null };
const isSvc = t => t._s !== undefined ? t._s : (t._s = svcAddr(t.addrs));
const catOf = t => t._c || (t._c = isSvc(t) ? 'svc' : (t.known || !t.addrs.length ? 'chats' : 'unk'));
const unrOf = t => t.unread || (t.read ? 0 : 1);

/* Cache local da lista: ao abrir a app as conversas aparecem logo e são atualizadas a seguir. */
const cacheSave = debounce(() => {
  try { localStorage.setItem('chats_threads', JSON.stringify(S.threads)); localStorage.setItem('chats_photos', JSON.stringify(S.photos)); } catch (e) { }
}, 400);
function cacheLoad() {
  try {
    const t = JSON.parse(localStorage.getItem('chats_threads') || 'null');
    if (Array.isArray(t) && t.length) { S.threads = t; S.loaded = true; }
    const p = JSON.parse(localStorage.getItem('chats_photos') || 'null');
    if (p && typeof p === 'object') for (const k in p) if (p[k]) S.photos[k] = p[k]; // sem fotos vazias: voltam a ser procuradas
  } catch (e) { }
}
async function loadThreads() {
  if (!S.perms.sms) return;
  try {
    S.threads = await N('threads'); S.loaded = true; renderThreads(); cacheSave();
    const miss = [...new Set(S.threads.map(t => t.addrs[0]).filter(a => a && S.photos[a] === undefined))].slice(0, 150);
    if (miss.length && S.perms.contacts) {
      miss.forEach(a => S.photos[a] = null);
      const ph = await N('photos', { addrs: miss }); let any = false;
      for (const a in ph) { S.photos[a] = ph[a]; any = true; }
      if (any) { renderThreads(); cacheSave(); }
    }
  } catch (e) { fail(e); }
}
function visibleThreads() {
  const q = H.q.trim().toLowerCase();
  let l;
  if (q) l = S.threads.filter(t => (t.name + ' ' + t.addrs.join(' ') + ' ' + t.snippet).toLowerCase().includes(q));
  else l = S.threads.filter(t => {
    const arch = inList('archived', t.id);
    if (H.tab === 'archived') return arch; if (arch) return false; if (catOf(t) !== H.cat) return false;
    if (H.tab === 'unread') return unrOf(t) > 0; if (H.tab === 'pinned') return inList('pinned', t.id); return true;
  });
  return l.sort((a, b) => (inList('pinned', b.id) - inList('pinned', a.id)) || b.date - a.date);
}
function onboardCard() {
  if (S.defaultSms && S.perms.sms) return '';
  return `<div class="card"><h3>Vamos configurar o Chats</h3><p>${!S.perms.sms ? 'Para ler e enviar SMS e MMS, o Chats precisa de acesso às mensagens, contactos e notificações.' : 'Falta definir o Chats como a sua aplicação SMS predefinida. Sem isso o Android não permite receber, guardar nem enviar mensagens.'}</p><div class="btns">${!S.perms.sms ? '<button class="btn" id="obPerm">Conceder permissões</button>' : '<button class="btn" id="obDef">Definir como predefinida</button>'}</div></div>`;
}
function renderThreads() {
  const tl = $('#tl'); if (!tl) return;
  const q = H.q.trim(), all = visibleThreads(), l = all.slice(0, H.limit); H.total = all.length;
  let h = onboardCard();
  h += l.map((t, i) => {
    const unr = unrOf(t), sel = H.sel.has(t.id), pin = inList('pinned', t.id), mu = inList('muted', t.id);
    const sn = q ? esc(t.snippet).replace(new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), m => `<mark>${m}</mark>`) : esc(t.snippet);
    return `<div class="row ${unr ? 'unr' : ''} ${sel ? 'sel' : ''}" data-id="${t.id}" style="--n:${Math.min(i, 14)}">${avatar(t.addrs, t.name, '', sel ? `<span class="ck">${ic('check')}</span>` : '')}<div class="mid"><div class="nm">${esc(t.name)}${t.known || !t.addrs.length || isSvc(t) ? '' : ' <span class="unk">desconhecido</span>'}${mu ? ic('bell', 14) : ''}</div><div class="sn">${t.error ? '<b style="color:var(--danger)">Falhou · </b>' : ''}${sn || '&nbsp;'}</div></div><div class="meta"><span class="tm">${short(t.date)}</span>${t.error ? `<span class="badge err">!</span>` : unr ? `<span class="badge ${mu ? 'mu' : ''}">${t.unread || ''}</span>` : pin ? ic('pin', 16) : ''}</div></div>`;
  }).join('');
  if (q && S.contacts) {
    const ql = q.toLowerCase(), inT = new Set(S.threads.flatMap(t => t.addrs.map(a => a.replace(/\D/g, ''))));
    const cm = S.contacts.filter(c => (c.name + c.number).toLowerCase().includes(ql) && !inT.has(c.number.replace(/\D/g, ''))).slice(0, 8);
    if (cm.length) h += `<div class="sec">Contactos</div>` + cm.map(c => `<div class="row" data-num="${esc(c.number)}">${avatar([c.number], c.name)}<div class="mid"><div class="nm">${esc(c.name)}</div><div class="sn">${esc(c.number)}</div></div></div>`).join('');
  }
  if (q && H.msgRes.length) h += `<div class="sec">Mensagens</div>` + H.msgRes.map(r => `<div class="row" data-th="${r.thread}" data-k="${r.k}" data-mid="${r.id}">${avatar([r.addr], r.name)}<div class="mid"><div class="nm">${esc(r.name)}</div><div class="sn">${esc(r.body)}</div></div><div class="meta"><span class="tm">${short(r.date)}</span></div></div>`).join('');
  if (!l.length && !h.includes('row')) h += `<div class="empty"><div class="big">${ic('chat')}</div><b style="color:var(--ink);font-size:18px">${q ? 'Sem resultados' : H.tab === 'archived' ? 'Nada arquivado' : H.tab === 'unread' ? 'Tudo lido' : 'Ainda sem conversas'}</b><span>${q ? 'Experimente outro nome, número ou palavra.' : 'Toque em “Nova” para escrever a primeira mensagem.'}</span></div>`;
  tl.className = 'pad' + (H.first && S.loaded ? ' stag' : ''); tl.innerHTML = h; if (S.loaded) H.first = false;
  const ob = $('#obPerm'); if (ob) ob.onclick = askAllPerms; const od = $('#obDef'); if (od) od.onclick = askDefault;
  renderTop(); renderChips(); renderNav();
}
function renderTop() {
  const top = $('#htop'); if (!top) return;
  if (H.sel.size) {
    const ids = [...H.sel], allArch = ids.every(i => inList('archived', i)), allPin = ids.every(i => inList('pinned', i));
    top.innerHTML = `<button class="ib" id="sx" aria-label="Cancelar">${ic('close')}</button><h2>${H.sel.size} selecionada${H.sel.size > 1 ? 's' : ''}</h2><button class="ib" id="sp" aria-label="Fixar">${ic('pin')}</button><button class="ib" id="sa" aria-label="Arquivar">${ic('archive')}</button><button class="ib" id="sr" aria-label="Lida/não lida">${ic('mail')}</button><button class="ib" id="sd" aria-label="Eliminar">${ic('trash')}</button>`;
    $('#sx').onclick = clearHomeSel;
    $('#sp').onclick = () => { ids.forEach(i => { if (inList('pinned', i) === allPin) toggleIn('pinned', i); }); clearHomeSel(); };
    $('#sa').onclick = () => { ids.forEach(i => { if (inList('archived', i) === allArch) toggleIn('archived', i); }); toast(allArch ? 'Conversas repostas' : 'Conversas arquivadas'); clearHomeSel(); };
    $('#sr').onclick = async () => { const anyUnr = ids.some(i => unrOf(S.threads.find(t => t.id === i) || {}) > 0); for (const i of ids) await N('markRead', { thread: i, read: anyUnr }).catch(() => { }); clearHomeSel(); loadThreads(); };
    $('#sd').onclick = async () => { if (await confirmBox('Eliminar conversas?', `${ids.length} conversa(s) e todas as suas mensagens serão eliminadas. Esta ação não pode ser desfeita.`)) { try { await N('deleteThreads', { ids }); toast('Conversas eliminadas'); } catch (e) { fail(e); } clearHomeSel(); loadThreads(); } };
  } else {
    top.innerHTML = `<h1>${{ archived: 'Arquivadas', unread: 'Não lidas', pinned: 'Fixadas' }[H.tab] || { chats: 'Chats', unk: 'Desconhecido', svc: 'Serviços' }[H.cat]}</h1><button class="ib" id="hn" aria-label="Nova conversa">${ic('compose', 22)}</button><button class="ib" id="hm" aria-label="Mais">${ic('more')}</button>`;
    $('#hn').onclick = () => newChatView(); $('#hm').onclick = homeMenu;
  }
}
function clearHomeSel() { H.sel.clear(); renderThreads(); }
function initSearch() {
  const sb = $('#hsb');
  sb.innerHTML = `<div class="sbar">${ic('search', 20)}<input id="sq" type="search" placeholder="Pesquisar aqui…" autocomplete="off"><button class="sbx" id="sc" aria-label="Limpar pesquisa">${ic('mic', 20)}</button></div>`;
  const inp = $('#sq'), sc = $('#sc');
  const run = debounce(async () => { try { H.msgRes = H.q.trim().length >= 2 ? await N('search', { q: H.q.trim() }) : []; renderThreads(); } catch (e) { } }, 320);
  inp.onfocus = () => { if (S.perms.contacts && !S.contacts) N('contacts').then(c => { S.contacts = c; renderThreads(); }).catch(() => { }); };
  inp.oninput = () => { H.limit = 60; H.q = inp.value; sc.innerHTML = H.q ? ic('close', 20) : ic('mic', 20); renderThreads(); run(); };
  sc.onclick = () => { if (H.q) closeSearch(); else inp.focus(); };
}
function openSearch() { const i = $('#sq'); i && i.focus(); }
function closeSearch() { H.limit = 60; H.q = ''; H.msgRes = []; const i = $('#sq'); if (i) i.value = ''; const sc = $('#sc'); if (sc) sc.innerHTML = ic('mic', 20); renderThreads(); }
async function homeMenu() {
  await menu([
    { icon: 'mail', label: H.tab === 'unread' ? 'Todas as conversas' : 'Só não lidas', run: () => { H.tab = H.tab === 'unread' ? 'all' : 'unread'; renderThreads(); } },
    { icon: 'pin', label: H.tab === 'pinned' ? 'Todas as conversas' : 'Só fixadas', run: () => { H.tab = H.tab === 'pinned' ? 'all' : 'pinned'; renderThreads(); } },
    { icon: 'archive', label: H.tab === 'archived' ? 'Voltar às conversas' : 'Conversas arquivadas', run: () => { H.tab = H.tab === 'archived' ? 'all' : 'archived'; renderChips(); renderThreads(); } },
    { icon: 'clock', label: 'Mensagens programadas', run: schedView },
    { icon: 'star', label: 'Mensagens favoritas', run: favView },
    { icon: 'eye', label: 'Marcar tudo como lido', run: async () => { for (const t of S.threads.filter(t => unrOf(t) > 0)) await N('markRead', { thread: t.id, read: true }).catch(() => { }); loadThreads(); toast('Tudo marcado como lido'); } },
    { icon: 'trash', label: 'Lixo', run: trashEntry },
    { icon: 'gear', label: 'Definições', run: settingsView }
  ]);
}
function renderChips() {
  const c = $('#chips'); if (!c) return;
  c.style.display = H.cat === 'chats' ? '' : 'none';
  const ck = (S.contacts ? S.contacts.length : 0) + '|' + S.threads.length + '|' + (S.threads.length ? S.threads.reduce((m, t) => t.date > m ? t.date : m, 0) : 0);
  if (H.ck !== ck) {
    const dg = x => String(x).replace(/\D/g, '').slice(-9), last = {};
    S.threads.forEach(t => t.addrs.forEach(a => { last[dg(a)] = Math.max(last[dg(a)] || 0, t.date); }));
    const list = (S.contacts || []).slice().sort((a, b) => (last[dg(b.number)] || 0) - (last[dg(a.number)] || 0) || a.name.localeCompare(b.name));
    const seen = new Set(), tp = [];
    for (const x of list) { const k = x.name + dg(x.number); if (seen.has(k)) continue; seen.add(k); tp.push(x); if (tp.length >= 12) break; }
    H.ck = ck; H.top = tp;
  }
  const top = H.top;
  c.innerHTML = `<button class="story add" id="stAdd" aria-label="Nova conversa">${ic('plus', 20)}</button>` + top.map((x, i) => `<button class="story" data-i="${i}" aria-label="${esc(x.name)}">${avatar([x.number], x.name)}</button>`).join('');
  $('#stAdd').onclick = () => newChatView();
  $$('.story[data-i]', c).forEach(b => b.onclick = () => startChat([top[+b.dataset.i].number.replace(/[^\d+]/g, '')]));
  const miss = top.map(x => x.number).filter(a => S.photos[a] === undefined);
  if (miss.length && S.perms.contacts) {
    miss.forEach(a => S.photos[a] = null);
    N('photos', { addrs: miss }).then(ph => { let any = false; for (const a in ph) { S.photos[a] = ph[a]; any = true; } if (any) { renderChips(); renderThreads(); } }).catch(() => { });
  }
}
function renderNav() {
  const nav = $('.bnav'); if (!nav) return;
  const cnt = { chats: 0, unk: 0, svc: 0 };
  S.threads.forEach(t => { if (!inList('archived', t.id) && unrOf(t) > 0) cnt[catOf(t)]++; });
  nav.innerHTML = [['chats', 'chat', 'Conversas'], ['unk', 'unk', 'Desconhecido'], ['svc', 'svc', 'Serviços'], ['set', 'gear', 'Definições']].map(([k, i, l]) => `<button class="${H.cat === k ? 'on' : ''}" data-n="${k}" aria-label="${l}"><span class="ni">${ic(i, 24)}${cnt[k] ? `<b class="nb">${cnt[k] > 99 ? '99+' : cnt[k]}</b>` : ''}</span><span class="nl">${l}</span></button>`).join('');
}
function homeView(el) {
  H.el = el;
  el.innerHTML = `<div class="top" id="htop"></div><div id="hsb"></div><div class="stories" id="chips"></div><div class="scroll"><div class="pad" id="tl"></div></div><nav class="bnav"></nav>`;
  initSearch();
  $('.bnav', el).onclick = e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.n === 'set') { const tv = views[views.length - 1]; if (tv && tv.name === 'settings') return; return settingsView(); }
    H.cat = b.dataset.n; H.tab = 'all'; H.limit = 60; closeSearch(); $('.scroll', el).scrollTop = 0;
  };
  let timer, lp = false, sx = 0, sy = 0;
  const tl = $('#tl');
  $('.scroll', el).addEventListener('scroll', e => { const sc = e.target; if (H.limit < H.total && sc.scrollHeight - sc.scrollTop - sc.clientHeight < 700) { H.limit += 60; renderThreads(); } }, { passive: true });
  tl.addEventListener('pointerdown', e => { const r = e.target.closest('.row[data-id]'); if (!r) return; lp = false; sx = e.clientX; sy = e.clientY; timer = setTimeout(() => { lp = true; navigator.vibrate && navigator.vibrate(12); toggleHomeSel(+r.dataset.id); }, 430); });
  tl.addEventListener('pointermove', e => { if (Math.abs(e.clientX - sx) + Math.abs(e.clientY - sy) > 10) clearTimeout(timer); });
  ['pointerup', 'pointercancel', 'scroll'].forEach(ev => tl.addEventListener(ev, () => clearTimeout(timer), true));
  tl.addEventListener('click', e => {
    if (lp) { lp = false; return; }
    const r = e.target.closest('.row'); if (!r) return;
    if (r.dataset.id) { const id = +r.dataset.id; if (H.sel.size) return toggleHomeSel(id); const t = S.threads.find(x => x.id === id); if (t) openChat({ thread: t.id, addrs: t.addrs, name: t.name, known: t.known }); }
    else if (r.dataset.num) startChat([r.dataset.num]);
    else if (r.dataset.th) { const t = S.threads.find(x => x.id === +r.dataset.th); openChat({ thread: +r.dataset.th, addrs: t ? t.addrs : [], name: t ? t.name : '', known: t && t.known }, { focus: { k: r.dataset.k, id: +r.dataset.mid } }); }
  });
  el.onShow = () => { loadThreads(); };
  v_home = { onBack() { if (H.sel.size) { clearHomeSel(); return true; } if (H.q) { closeSearch(); return true; } if (H.tab !== 'all') { H.tab = 'all'; renderChips(); renderThreads(); return true; } if (H.cat !== 'chats') { H.cat = 'chats'; renderThreads(); return true; } return false; } };
  renderChips(); renderThreads();
}
let v_home;
function toggleHomeSel(id) { H.sel.has(id) ? H.sel.delete(id) : H.sel.add(id); renderThreads(); }

async function askAllPerms() {
  try { S.perms = await N('requestPerms', { which: ['sms', 'contacts', 'phone', 'notif'] }); } catch (e) { return fail(e); }
  if (!S.perms.sms) { const go = await dialog({ title: 'Permissões necessárias', text: 'Sem a permissão de SMS o Chats não consegue funcionar. Pode concedê-la nas definições da aplicação.', ok: 'Abrir definições', cancel: 'Agora não' }); if (go) N('appSettings'); return; }
  await refreshState(); if (!S.defaultSms) askDefault();
}
async function askOverlay() {
  const go = await dialog({ title: 'Balão flutuante', text: 'Para mostrar o balão por cima de outras aplicações, ative "Mostrar sobre outras aplicações" para o Chats na janela que vai abrir.', ok: 'Abrir definições', cancel: 'Agora não' });
  if (go) N('overlayPerm');
}
async function askDefault() {
  try { S.defaultSms = await N('requestDefault'); } catch (e) { return fail(e); }
  toast(S.defaultSms ? 'O Chats é agora a aplicação SMS predefinida' : 'O Chats ainda não é a aplicação predefinida', !S.defaultSms);
  await refreshState();
}
async function refreshState() {
  try { const i = await N('init'); S.defaultSms = i.defaultSms; S.perms = i.perms; S.sims = i.sims; S.exact = i.exact; S.overlay = i.overlay !== false; if (i.pending) handleOpen(i.pending);
    /* zoom alterado na janela do balão */ const cz = i.settings && +i.settings.chatZoom; if (cz && cz !== S.settings.chatZoom) { S.settings.chatZoom = cz; $$('.msgs').forEach(m => m.style.setProperty('--cz', cz)); } } catch (e) { }
  if (S.perms.contacts && !S.contacts) N('contacts').then(c => { S.contacts = c; }).catch(() => { });
  loadThreads(); settingsRedraw();
}

/* ---------- nova conversa ---------- */
function newChatView(o = {}) {
  const R = [];
  push('new', (el, v) => {
    el.innerHTML = `<div class="top"><button class="ib" id="nb" aria-label="Voltar">${ic('back')}</button><h2>Nova conversa</h2></div><div class="sbar" style="flex-wrap:wrap;height:auto;min-height:48px;padding:6px 12px" id="nbar"><span id="nch" style="display:contents"></span><input id="nin" inputmode="tel" placeholder="Nome ou número" style="min-width:120px;height:36px" autocomplete="off"></div><div class="scroll"><div class="pad" id="nl"></div></div><button class="fab" id="ngo" style="display:none">${ic('chat')}Continuar</button>`;
    $('#nb').onclick = pop;
    const norm = s => s.replace(/[^\d+]/g, '');
    const draw = () => {
      $('#nch').innerHTML = R.map((r, i) => `<button class="chip on" data-i="${i}" style="margin:2px">${esc(r.name || r.number)} ✕</button>`).join('');
      $$('#nch .chip').forEach(b => b.onclick = () => { R.splice(+b.dataset.i, 1); draw(); list(); });
      $('#ngo').style.display = R.length ? 'flex' : 'none';
    };
    const add = (number, name) => { number = number.trim(); if (!number || R.some(r => norm(r.number) === norm(number))) return; R.push({ number, name }); $('#nin').value = ''; draw(); list(); };
    let lim = 100, tot = 0;
    const list = () => {
      const q = $('#nin').value.trim().toLowerCase(), digits = norm(q);
      let h = '';
      if (digits.length >= 3 && /^[+\d\s()-]+$/.test(q)) h += `<div class="row" data-add="${esc(q)}"><div class="av" style="background:var(--acc)">${ic('plus')}</div><div class="mid"><div class="nm">Enviar para ${esc(q)}</div><div class="sn">Número introduzido</div></div></div>`;
      if (S.contacts) { const fl = S.contacts.filter(c => !q || (c.name + ' ' + c.number).toLowerCase().includes(q)); tot = fl.length; h += fl.slice(0, lim).map(c => `<div class="row" data-add="${esc(c.number)}" data-nm="${esc(c.name)}">${avatar([c.number], c.name)}<div class="mid"><div class="nm">${esc(c.name)}</div><div class="sn">${esc(c.number)}</div></div></div>`).join(''); }
      else if (!S.perms.contacts) h += `<div class="card"><h3>Aceder aos contactos</h3><p>Permita o acesso para escolher destinatários e ver nomes e fotografias.</p><div class="btns"><button class="btn" id="gc">Permitir contactos</button></div></div>`;
      else h += `<div class="empty"><span class="spin"></span></div>`;
      $('#nl').innerHTML = h;
      $$('#nl .row').forEach(r => r.onclick = () => add(r.dataset.add, r.dataset.nm));
      const gc = $('#gc'); if (gc) gc.onclick = async () => { S.perms = await N('requestPerms', { which: ['contacts'] }); if (S.perms.contacts) { S.contacts = await N('contacts'); } list(); };
    };
    $('#nin').oninput = () => { lim = 100; list(); };
    { const sc = $('.scroll', el); sc.addEventListener('scroll', () => { if (tot > lim && sc.scrollTop + sc.clientHeight > sc.scrollHeight - 500) { lim += 100; list(); } }, { passive: true }); }
    $('#nin').onkeydown = e => { if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); const q = $('#nin').value; if (norm(q).length >= 3) add(q); } };
    $('#ngo').onclick = () => { const q = $('#nin').value; if (norm(q).length >= 3) add(q); const a = R.map(r => norm(r.number)); pop(); setTimeout(() => startChat(a, o), 220); };
    if (S.perms.contacts) N('contacts').then(c => { const ch = !S.contacts || c.length !== S.contacts.length; S.contacts = c; if (ch && $('#nl')) list(); }).catch(() => { });
    draw(); list(); setTimeout(() => $('#nin').focus(), 450);
  });
}
function nameFor(addrs) {
  return addrs.map(a => { const d = a.replace(/\D/g, ''); const c = S.contacts && S.contacts.find(c => c.number.replace(/\D/g, '').endsWith(d.slice(-9)) && d.length >= 7); return c ? c.name : a; }).join(', ');
}
async function startChat(addrs, o = {}) {
  try {
    if (!addrs.length) return;
    const id = await N('threadId', { addrs }); const t = S.threads.find(x => x.id === id);
    openChat({ thread: id, addrs, name: t ? t.name : nameFor(addrs), known: t ? t.known : false }, o);
  } catch (e) { fail(e); }
}
function handleOpen(p) {
  if (p.thread != null) { const t = S.threads.find(x => x.id === p.thread); if (t) openChat({ thread: t.id, addrs: t.addrs, name: t.name, known: t.known }); else loadThreads().then(() => { const u = S.threads.find(x => x.id === p.thread); if (u) openChat({ thread: u.id, addrs: u.addrs, name: u.name, known: u.known }); }); }
  else if (p.address) startChat([p.address], { draft: p.body });
  else if (p.share) newChatView({ draft: p.share });
}

/* =====================================================================
   CONVERSA
   ===================================================================== */
let C = null;
const thumbs = {};
const snip = (s, n = 60) => { s = (s || '').replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
const single = () => C && C.addrs.length === 1;
const curSub = () => S.settings.sub >= 0 ? S.settings.sub : (S.defaultSub ?? -1);

function openChat(t, o = {}) {
  if (C && C.thread === t.thread && views[views.length - 1].name === 'chat') return;
  const th = t.thread;
  const cc = C = { svc: svcAddr(t.addrs), thread: th, addrs: t.addrs, name: t.name || nameFor(t.addrs), known: t.known, msgs: [], atts: [], reply: null, subject: false, sel: new Set(), sub: curSub(), seen: null, focus: o.focus, bannerOff: false, busy: false };
  push('chat', el => {
    cc.el = el; el.classList.add('chat'); if (cc.svc) el.classList.add('nocomp');
    el.innerHTML = `<div class="wp" id="wp"></div><div class="wpd" id="wpd"></div><div class="top" id="ctop"></div><div id="cban"></div><div class="msgs" id="msgs"></div><div class="compose"><div class="tray" id="tray"></div><div id="rp"></div><div class="crow"><div class="field"><input class="subj" id="subj" hidden maxlength="120" placeholder="Assunto (MMS)"><div class="frow"><button class="emb" id="emb" aria-label="Emojis">${ic('smile', 24)}</button><textarea id="ta" rows="1" placeholder="Escreva algo…" aria-label="Mensagem"></textarea><button class="plus" id="plus" aria-label="Anexos e ações">${ic('clip', 20)}</button><button class="send on" id="micb" aria-label="Gravar mensagem de voz">${ic('mic', 20)}</button></div><span class="cnt" id="cnt"></span></div><button class="mic" id="sendb" aria-label="Enviar">${ic('send', 22)}</button></div><div class="emo" id="emo" hidden></div></div>`;
    chatTop(); chatBanner(); applyWp();
    { const mb = $('#msgs'); if (mb) mb.innerHTML = '<div class="empty" style="margin:auto"><span class="spin"></span></div>'; }
    const ta = $('#ta'), grow = () => { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 110) + 'px'; };
    ta.value = o.draft ?? S.drafts[th] ?? '';
    ta.oninput = () => { grow(); S.drafts[th] = ta.value; updSend(); };
    $('#sendb').onclick = sendNow; $('#plus').onclick = attachSheet; $('#micb').onclick = recSheet; initEmoji();
    ta.addEventListener('focus', () => setTimeout(() => { const m = $('#msgs'); m.scrollTop = m.scrollHeight; }, 300));
    grow(); updSend();
    if (o.atts) { cc.atts = o.atts; drawTray(); updSend(); }
    const m = $('#msgs'); let timer, lp = false, sx = 0, sy = 0;
    const comp = $('.compose', el);
    const syncCh = () => { const nb = m.scrollHeight - m.scrollTop - m.clientHeight < 160; el.style.setProperty('--ch', comp.offsetHeight + 'px'); if (nb) m.scrollTop = m.scrollHeight; };
    if (window.ResizeObserver) new ResizeObserver(syncCh).observe(comp); syncCh();
    m.style.setProperty('--cz', S.settings.chatZoom || 1);
    let pz = null;
    const dist = t => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
    m.addEventListener('touchstart', e => { if (e.touches.length === 2) { clearTimeout(timer); lp = false; pz = { d: dist(e.touches) || 1, z: +S.settings.chatZoom || 1 }; } }, { passive: true });
    m.addEventListener('touchmove', e => {
      if (!pz || e.touches.length !== 2) return; e.preventDefault(); clearTimeout(timer);
      const z = Math.max(.75, Math.min(2.2, pz.z * dist(e.touches) / pz.d));
      const mid = (m.scrollTop + m.clientHeight / 2) / m.scrollHeight;
      m.style.setProperty('--cz', z.toFixed(3)); S.settings.chatZoom = +z.toFixed(3);
      m.scrollTop = mid * m.scrollHeight - m.clientHeight / 2;
    }, { passive: false });
    const endPz = e => { if (pz && e.touches.length < 2) { pz = null; saveSettings(); } };
    m.addEventListener('touchend', endPz, { passive: true }); m.addEventListener('touchcancel', endPz, { passive: true });
    m.addEventListener('pointerdown', e => { const r = e.target.closest('.msg'); if (!r) return; lp = false; sx = e.clientX; sy = e.clientY; timer = setTimeout(() => { lp = true; navigator.vibrate && navigator.vibrate(12); toggleMsgSel(r); }, 430); });
    m.addEventListener('pointermove', e => { if (Math.abs(e.clientX - sx) + Math.abs(e.clientY - sy) > 10) clearTimeout(timer); });
    ['pointerup', 'pointercancel'].forEach(ev => m.addEventListener(ev, () => clearTimeout(timer)));
    m.addEventListener('scroll', () => {
      clearTimeout(timer);
      if (m.scrollTop < 160 && !cc.more && cc.msgs.length >= (cc.limit || 50)) {
        cc.more = true; cc.keep = m.scrollHeight; cc.limit = (cc.limit || 50) + 100;
        loadMsgs().finally(() => { cc.keep = 0; setTimeout(() => { cc.more = false; }, 500); });
      }
    }, { passive: true });
    m.addEventListener('click', e => {
      if (lp) { lp = false; return; }
      const lk = e.target.closest('.lk'); if (lk && !cc.sel.size) return linkSheet(lk.dataset.t, decodeURIComponent(lk.dataset.v));
      const act = e.target.closest('[data-act]'); const r = e.target.closest('.msg');
      if (act && r) { const msg = findMsg(r); if (act.dataset.act === 'retry') return retry(msg); if (act.dataset.act === 'dl') return dlMms(msg); }
      if (!r) return;
      if (cc.sel.size) return toggleMsgSel(r);
      const vc = e.target.closest('.voice');
      if (vc) { if (e.target.closest('.vspd')) return voiceSpeed(); if (e.target.closest('.vplay')) return voiceToggle(vc); if (e.target.closest('.wave')) return voiceSeek(vc, e); }
      const at = e.target.closest('.att[data-part]'); if (at && at.querySelector('img')) return openViewer(at);
      msgMenu(findMsg(r), r);
    });
  }, { onBack() { if (closeEmo()) return true; if (C && C.sel.size) { clearMsgSel(); return true; } return false; }, onClose() { const ta = $('#ta'); if (ta && C) S.drafts[C.thread] = ta.value; Media_cancelRec(); if (C === cc) C = null; loadThreads(); } });
  if (t.thread != null) { N('cancelNotif', { thread: th }).catch(() => { }); }
  loadMsgs(true);
}
const Media_cancelRec = () => N('recCancel').catch(() => { });
const findMsg = r => C.msgs.find(m => m.k === r.dataset.k && m.id === +r.dataset.id);

function chatTop() {
  const top = $('#ctop'); if (!top) return;
  if (C.sel.size) {
    top.innerHTML = `<div class="fl pill grow"><button class="ib" id="cx" aria-label="Cancelar">${ic('close')}</button><h2>${C.sel.size}</h2><button class="ib" id="cc" aria-label="Copiar">${ic('copy')}</button><button class="ib" id="cf" aria-label="Reencaminhar">${ic('fwd')}</button><button class="ib" id="cs" aria-label="Partilhar">${ic('share')}</button><button class="ib" id="cd" aria-label="Eliminar">${ic('trash')}</button></div>`;
    const sel = () => C.msgs.filter(m => C.sel.has(m.k + m.id));
    $('#cx').onclick = clearMsgSel;
    $('#cc').onclick = () => { N('copy', { text: sel().map(m => m.body).filter(Boolean).join('\n') }).then(() => toast('Copiado')); clearMsgSel(); };
    $('#cf').onclick = () => { const s = sel(); clearMsgSel(); forward(s); };
    $('#cs').onclick = () => { N('share', { text: sel().map(m => m.body).filter(Boolean).join('\n') }).catch(fail); clearMsgSel(); };
    $('#cd').onclick = () => { const s = sel(); clearMsgSel(); delMsgs(s); };
  } else {
    const lm = C.msgs[C.msgs.length - 1], lastTxt = lm ? `Última mensagem ${dayLabel(lm.date)}, ${hhmm(lm.date)}` : 'SMS e MMS';
    const sub = C.svc ? '' : C.addrs.length === 1 ? (C.name !== C.addrs[0] ? C.addrs[0] : lastTxt) : C.addrs.length + ' destinatários';
    top.innerHTML = `<button class="fl circ" id="cb" aria-label="Voltar">${ic('back', 26)}</button><button class="fl pill who" id="cw">${avatar(C.addrs, C.name, 'sm')}<span style="min-width:0"><b>${esc(C.name)}</b>${sub ? `<small>${esc(sub)}</small>` : ''}</span></button><div class="fl pill acts">${single() ? `<button class="ib" id="cp" aria-label="Ligar">${ic('phone')}</button>` : ''}<button class="ib" id="cm" aria-label="Mais">${ic('more')}</button></div>`;
    $('#cb').onclick = pop; $('#cm').onclick = chatMenu; $('#cw').onclick = profileView;
    const cp = $('#cp'); if (cp) cp.onclick = () => N('dial', { number: C.addrs[0] }).catch(fail);
  }
}
function chatBanner() {
  const b = $('#cban'); if (!b) return;
  if (single() && !C.known && !C.bannerOff && C.msgs.some(m => m.dir === 'in') && /\d{7,}/.test(C.addrs[0].replace(/\D/g, ''))) {
    b.innerHTML = `<div class="banner">${ic('info')}<span>Número desconhecido</span><button id="bAdd">Adicionar</button><button id="bBlk">Bloquear</button><button id="bX" aria-label="Fechar" style="padding:6px">${ic('close', 18)}</button></div>`;
    $('#bAdd').onclick = () => N('addContact', { number: C.addrs[0] }).catch(fail);
    $('#bBlk').onclick = blockCur; $('#bX').onclick = () => { C.bannerOff = true; chatBanner(); };
  } else b.innerHTML = '';
}
async function blockCur() {
  if (!await dialog({ title: 'Bloquear ' + C.addrs[0] + '?', text: 'Deixará de receber notificações deste número. O Android guarda a lista de bloqueados.', ok: 'Bloquear', cancel: 'Cancelar', danger: true })) return;
  try { for (const a of C.addrs) await N('block', { number: a }); toast('Número bloqueado'); } catch (e) { fail(e); }
}
async function chatMenu() {
  const th = C.thread, single1 = single();
  const it = await menu([
    single1 && !C.known ? { icon: 'user', label: 'Adicionar aos contactos', run: () => N('addContact', { number: C.addrs[0] }).catch(fail) } : null,
    { icon: 'bell', label: inList('muted', th) ? 'Reativar notificações' : 'Silenciar conversa', run: () => { toast(toggleIn('muted', th) ? 'Conversa silenciada' : 'Notificações reativadas'); } },
    { icon: 'pin', label: inList('pinned', th) ? 'Desafixar' : 'Fixar no topo', run: () => toast(toggleIn('pinned', th) ? 'Conversa fixada' : 'Conversa desafixada') },
    { icon: 'archive', label: inList('archived', th) ? 'Repor conversa' : 'Arquivar', run: () => { toggleIn('archived', th); pop(); } },
    { icon: 'mail', label: 'Marcar como não lida', run: async () => { await N('markRead', { thread: th, read: false }); pop(); } },
    { icon: 'image', label: 'Fundo desta conversa', run: () => bgView('c' + th, 'Fundo desta conversa') },
    { icon: 'bell', label: 'Notificações do sistema', sub: 'Som, vibração e prioridade', run: () => N('notifSettings') },
    { icon: 'block', label: 'Bloquear', danger: true, run: blockCur },
    { icon: 'trash', label: 'Eliminar conversa', danger: true, run: async () => { if (await confirmBox('Eliminar conversa?', 'Todas as mensagens desta conversa serão eliminadas.')) { try { await N('deleteThreads', { ids: [th] }); pop(); toast('Conversa eliminada'); } catch (e) { fail(e); } } } }
  ]);
}

/* ---------- perfil ---------- */
function profileView() {
  if (!C) return;
  const cc = C, th = cc.thread, one = cc.addrs.length === 1;
  push('profile', el => {
    el.classList.add('prof');
    const imgs = cc.msgs.reduce((n, m) => n + (m.parts || []).filter(p => /^image\//.test(p.ct)).length, 0);
    const lm = cc.msgs[cc.msgs.length - 1];
    const sub = one ? (cc.name !== cc.addrs[0] ? cc.addrs[0] : 'Serviço / número não gravado') : cc.addrs.length + ' participantes';
    const draw = () => {
      const muted = inList('muted', th), pinned = inList('pinned', th);
      el.innerHTML = `<div class="top"><button class="ib" id="pb" aria-label="Voltar">${ic('back')}</button><h2></h2><button class="ib" id="pm" aria-label="Mais">${ic('more')}</button></div>
      <div class="scroll"><div class="phead">${avatar(cc.addrs, cc.name, 'xl')}<h2>${esc(cc.name)}</h2><p>${esc(sub)}</p></div>
      <div class="pacts">${one ? `<button class="pa" id="pcall">${ic('phone', 22)}<span>Ligar</span></button>` : ''}<button class="pa" id="pmute">${ic('bell', 22)}<span>${muted ? 'Som' : 'Silenciar'}</span></button><button class="pa" id="ppin">${ic('pin', 22)}<span>${pinned ? 'Desafixar' : 'Fixar'}</span></button><button class="pa" id="pblk">${ic('block', 22)}<span>Bloquear</span></button></div>
      <div class="grp" style="margin:14px 12px">${cc.addrs.map(a => `<button class="set" data-copy="${esc(a)}">${ic('phone')}<span class="t">${esc(a)}<small>Telemóvel · toque para copiar</small></span></button>`).join('')}${one && !cc.known ? `<button class="set" id="padd">${ic('user')}<span class="t">Adicionar aos contactos</span></button>` : ''}</div>
      <div class="grp" style="margin:14px 12px"><div class="set">${ic('chat')}<span class="t">Mensagens<small>${cc.msgs.length}${lm ? ' · última ' + esc(dayLabel(lm.date)) : ''}</small></span></div><div class="set">${ic('image')}<span class="t">Imagens<small>${imgs}</small></span></div><button class="set" id="pbg">${ic('palette')}<span class="t">Fundo desta conversa</span></button></div>
      <div class="grp" style="margin:14px 12px 30px"><button class="set" id="pdel" style="color:var(--danger)">${ic('trash')}<span class="t">Eliminar conversa</span></button></div></div>`;
      $('#pb').onclick = pop; $('#pm').onclick = chatMenu;
      const pc = $('#pcall'); if (pc) pc.onclick = () => N('dial', { number: cc.addrs[0] }).catch(fail);
      $('#pmute').onclick = () => { toast(toggleIn('muted', th) ? 'Conversa silenciada' : 'Notificações reativadas'); draw(); };
      $('#ppin').onclick = () => { toast(toggleIn('pinned', th) ? 'Conversa fixada' : 'Conversa desafixada'); draw(); };
      $('#pblk').onclick = blockCur;
      $$('[data-copy]', el).forEach(b => b.onclick = () => N('copy', { text: b.dataset.copy }).then(() => toast('Número copiado')).catch(fail));
      const pa = $('#padd'); if (pa) pa.onclick = () => N('addContact', { number: cc.addrs[0] }).catch(fail);
      $('#pbg').onclick = () => bgView('c' + th, 'Fundo desta conversa');
      $('#pdel').onclick = async () => { if (await confirmBox('Eliminar conversa?', 'Todas as mensagens desta conversa serão eliminadas.')) { try { await N('deleteThreads', { ids: [th] }); pop(); setTimeout(pop, 120); toast('Conversa eliminada'); } catch (e) { fail(e); } } };
    };
    draw();
  });
}

/* ---------- fundo ---------- */
async function wpData(key) { if (S.wpc[key] === undefined) S.wpc[key] = await N('wallpaper', { key }).catch(() => null); return S.wpc[key]; }
async function applyWp() {
  if (!C) return; const w = S.settings.wp, key = w['c' + C.thread] ? 'c' + C.thread : w.global ? 'global' : null;
  const wp = $('#wp'), wpd = $('#wpd'); if (!wp) return;
  if (!key) { wp.style.backgroundImage = ''; wpd.style.background = ''; return; }
  const d = await wpData(key), cfg = w[key]; if (!d || !C) return;
  wp.style.backgroundImage = `url(${d})`; wp.style.backgroundPosition = `${cfg.x}% ${cfg.y}%`; wp.style.transform = `scale(${cfg.z})`; wp.style.filter = `blur(${cfg.blur}px)`;
  wpd.style.background = `color-mix(in srgb, var(--bg) ${Math.round(cfg.dim * 100)}%, transparent)`;
}

/* ---------- mensagens ---------- */
async function loadMsgs(first) {
  const cc = C; if (!cc) return;
  try {
    const l = await N('messages', { thread: cc.thread, limit: cc.limit || 50 });
    if (C !== cc) return;
    const sig = l.length + '|' + l.map(m => m.k + m.id + m.st + (m.read ? 1 : 0)).join(',');
    if (!first && cc.sig === sig) return;
    cc.sig = sig; cc.msgs = l; renderMsgs(first); chatBanner();
    if (l.some(m => m.dir === 'in' && !m.read) && document.visibilityState !== 'hidden') N('markRead', { thread: cc.thread, read: true }).then(() => { const t = S.threads.find(x => x.id === cc.thread); if (t) { t.unread = 0; t.read = true; } }).catch(() => { });
  } catch (e) { fail(e); }
}
function statusLine(m, last) {
  if (m.dir !== 'out') return '';
  const t = { sending: '<span class="spin"></span> A enviar…', sent: 'Enviada', delivered: 'Entregue ✓✓', undelivered: 'Não entregue', failed: '' }[m.st];
  if (m.st === 'failed') return '';
  if (m.st === 'undelivered') return `<div class="stat bad">Não entregue</div>`;
  if (m.st === 'sending' || last) return `<div class="stat">${t}${m.k === 'm' && m.st === 'sent' ? ' · MMS' : ''}</div>`;
  return '';
}
function partHtml(m, p) {
  if (/^image\//.test(p.ct) || /^video\//.test(p.ct)) return `<div class="att" data-part="${p.id}" data-mime="${esc(p.ct)}" data-name="${esc(p.name)}"><span class="spin"></span>${/^video\//.test(p.ct) ? `<div class="play">${ic('play', 22)}</div>` : ''}</div>`;
  if (/^audio\//.test(p.ct)) {
    let s = 0; for (const ch of String(p.id) + p.name) s = (s * 31 + ch.charCodeAt(0)) >>> 0;
    const bars = Array.from({ length: 34 }, (_, i) => { s = (s * 1103515245 + 12345) >>> 0; const r = ((s >> 8) % 100) / 100; return Math.round(5 + 17 * Math.abs(Math.sin(i * .5 + (s % 7))) * (.4 + r * .6)); });
    return `<div class="voice" data-part="${p.id}" data-mime="${esc(p.ct)}" data-name="${esc(p.name)}"><button class="vplay" data-s="play" aria-label="Reproduzir">${ic('play', 16)}</button><div class="vbody"><span class="wave">${bars.map(h => `<i style="height:${h}px"></i>`).join('')}</span><span class="vtm"></span></div><button class="vspd" hidden aria-label="Velocidade">1×</button></div>`;
  }
  const ico = /^audio\//.test(p.ct) ? 'audio' : 'clip';
  return `<div class="file" data-part="${p.id}" data-mime="${esc(p.ct)}" data-name="${esc(p.name)}"><div class="fi">${ic(ico, 20)}</div><div><b>${esc(p.name)}</b><small>${esc(p.ct)}</small></div></div>`;
}
function msgHtml(m, i, arr, lastOut) {
  const out = m.dir === 'out', key = m.k + m.id, prev = arr[i - 1];
  const sender = !out && C.addrs.length > 1 && (!prev || prev.dir !== 'in' || prev.addr !== m.addr) ? `<div class="snd">${esc(nameFor([m.addr]))}</div>` : '';
  let body = m.body || ''; let qt = '';
  const q = body.match(/^↪ “([^”]*)”\n/); if (q) { qt = `<div class="qt">${esc(q[1])}</div>`; body = body.slice(q[0].length); }
  let inner = '';
  if (m.k === 'm') {
    if (m.st === 'nodownload' || m.st === 'dlfailed' || m.st === 'downloading') inner += `<div class="file"><div class="fi">${ic('dl', 20)}</div><div><b>Mensagem multimédia</b><small>${kb(m.size || 0)}${m.st === 'dlfailed' ? ' · falhou' : ''}</small></div></div>${m.st === 'downloading' ? '<div class="stat"><span class="spin"></span> A transferir…</div>' : `<div class="stat"><button data-act="dl">${m.st === 'dlfailed' ? 'Tentar novamente' : 'Transferir'}</button></div>`}`;
    if (m.subject) inner += `<div class="subj">${esc(m.subject)}</div>`;
    inner += (m.parts || []).map(p => partHtml(m, p)).join('');
  }
  if (body) inner += linkify(body);
  const fav = S.settings.favorites.some(f => f.k === m.k && f.id === m.id);
  const isNew = C.seen && !C.seen.has(key);
  const grp = C.addrs.length > 1, first = !out && (!prev || prev.dir !== 'in' || prev.addr !== m.addr);
  const av = out ? '' : `<div class="mav">${first ? avatar(grp ? [m.addr] : C.addrs, grp ? nameFor([m.addr]) : C.name, 'xs') : ''}</div>`;
  return `<div class="msg ${out ? 'out' : 'in'} ${isNew ? 'new' : ''} ${C.sel.has(key) ? 'sel' : ''}" data-k="${m.k}" data-id="${m.id}">${av}${out && m.st === 'failed' ? `<button class="failx" data-act="retry" aria-label="Falhou. Tocar para tentar novamente">!</button>` : ''}<div class="mcol">${sender}<div class="bub">${qt}${inner}<span class="tm">${fav ? ic('star', 12).replace('class="i"', 'class="i fav"') + ' ' : ''}${hhmm(m.date)}</span></div>${statusLine(m, m === lastOut)}</div></div>`;
}
/* ---------- mensagens de voz (reprodução nativa) ---------- */
const durs = {}; let VS = { part: -1, playing: false, pos: 0, dur: 0, speed: 1 }, voiceBusy = false;
const fmtT = ms => { const t = Math.max(0, Math.round(ms / 1000)); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); };
function voiceApply() {
  $$('.voice').forEach(v => {
    const id = +v.dataset.part, cur = VS.part === id, d = (cur && VS.dur) || durs[id] || 0, pos = cur ? VS.pos : 0, pl = cur && VS.playing;
    v.classList.toggle('playing', pl);
    const b = $('.vplay', v), want = pl ? 'pause' : 'play';
    if (b.dataset.s !== want) { b.dataset.s = want; b.innerHTML = ic(want, 16); b.setAttribute('aria-label', pl ? 'Pausar' : 'Reproduzir'); }
    const bars = v._b || (v._b = $$('.wave i', v)), n = d ? Math.round(bars.length * pos / d) : 0;
    if (v._n !== n) { v._n = n; bars.forEach((x, i) => x.classList.toggle('on', i < n)); }
    const t = $('.vtm', v); if (t) t.textContent = d ? fmtT(cur && (pl || pos > 50) ? pos : d) : '';
    const sp = $('.vspd', v); if (sp) { sp.hidden = !(cur && (pl || pos > 50)); sp.textContent = (VS.speed || 1) + '×'; }
  });
}
async function voiceDurs() {
  if (voiceBusy) return; voiceBusy = true;
  try {
    for (const v of $$('.voice:not([data-d])').reverse()) {
      v.dataset.d = 1; const id = +v.dataset.part;
      if (durs[id] === undefined) durs[id] = await N('audioInfo', { part: id, mime: v.dataset.mime }).catch(() => 0);
      voiceApply();
    }
  } finally { voiceBusy = false; }
}
const voiceToggle = v => N('audioToggle', { part: +v.dataset.part, mime: v.dataset.mime }).catch(fail);
function voiceSeek(v, e) {
  const id = +v.dataset.part, d = (VS.part === id && VS.dur) || durs[id] || 0; if (!d) return;
  const r = $('.wave', v).getBoundingClientRect(), f = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)), ms = Math.round(f * d);
  if (VS.part === id) N('audioSeek', { part: id, ms }).catch(() => { });
  else N('audioToggle', { part: id, mime: v.dataset.mime }).then(() => N('audioSeek', { part: id, ms })).catch(fail);
}
function voiceSpeed() { const l = [1, 1.5, 2], n = l[(l.indexOf(VS.speed || 1) + 1) % l.length]; N('audioSpeed', { speed: n }).catch(() => { }); }
function renderMsgs(first) {
  const box = $('#msgs'); if (!box || !C) return;
  const near = first || box.scrollHeight - box.scrollTop - box.clientHeight < 140;
  const lastOut = [...C.msgs].reverse().find(m => m.dir === 'out');
  let h = '', day = null;
  C.msgs.forEach((m, i, a) => { const d = dayKey(m.date); if (d !== day) { day = d; h += `<div class="day">${esc(dayLabel(m.date))}</div>`; } h += msgHtml(m, i, a, lastOut); });
  if (!C.msgs.length) h = `<div class="empty" style="margin:auto"><div class="big">${ic('chat')}</div><b style="color:var(--ink)">Diga olá</b><span>Escreva abaixo para começar a conversa.</span></div>`;
  const keep = C.keep || 0; C.keep = 0;
  box.innerHTML = h; C.seen = new Set(C.msgs.map(m => m.k + m.id));
  if (keep) box.scrollTop = box.scrollHeight - keep; else if (near) box.scrollTop = box.scrollHeight;
  if (C.focus) { const f = C.focus; C.focus = null; const el = $(`.msg[data-k="${f.k}"][data-id="${f.id}"]`, box); if (el) { el.scrollIntoView({ block: 'center' }); el.classList.add('sel'); setTimeout(() => el.classList.remove('sel'), 1800); } }
  loadThumbs(); voiceApply(); voiceDurs();
}
let thumbBusy = false;
async function loadThumbs() {
  if (thumbBusy) return; thumbBusy = true;
  try {
    for (;;) {
      const todo = $$('.att[data-part]:not([data-done])').reverse(); // as de baixo (visíveis) primeiro
      if (!todo.length) break;
      let k = 0;
      const worker = async () => {
        while (k < todo.length) {
          const el = todo[k++], id = el.dataset.part; el.dataset.done = 1;
          if (thumbs[id] === undefined) thumbs[id] = await N('thumb', { part: +id, mime: el.dataset.mime, max: 640 }).catch(() => null);
          const d = thumbs[id];
          if (d && el.isConnected) { const sp = $('.spin', el); if (sp) sp.remove(); const im = new Image(); im.src = d; im.alt = el.dataset.name; el.prepend(im); }
          else if (el.isConnected) el.innerHTML = `<div class="file" style="margin:0">${ic('image', 22)}<b>${esc(el.dataset.name)}</b></div>`;
        }
      };
      await Promise.all([worker(), worker(), worker()]);
    }
  } finally { thumbBusy = false; }
}
function openViewer(at) {
  const part = at.dataset.part, mime = at.dataset.mime, name = at.dataset.name;
  viewer.innerHTML = `<div class="vb"><button class="ib" id="vx" aria-label="Fechar">${ic('close')}</button><button class="ib" id="vs" aria-label="Partilhar">${ic('share')}</button></div><div class="vi"><span class="spin"></span></div>`;
  viewer.classList.add('on');
  $('#vx').onclick = () => viewer.classList.remove('on');
  $('#vs').onclick = () => N('shareAtt', { part: +part, mime, name }).catch(fail);
  N('thumb', { part: +part, mime, max: 1600 }).then(d => { if (d) $('.vi', viewer).innerHTML = `<img src="${d}" alt="${esc(name)}">`; }).catch(() => { });
}
function toggleMsgSel(r) { try { getSelection().removeAllRanges(); } catch (e) { } const k = r.dataset.k + r.dataset.id; C.sel.has(k) ? C.sel.delete(k) : C.sel.add(k); r.classList.toggle('sel'); chatTop(); }
function clearMsgSel() { C.sel.clear(); $$('.msg.sel').forEach(e => e.classList.remove('sel')); chatTop(); }

async function msgMenu(m, el) {
  if (!m) return;
  const key = m.k + m.id, favd = S.settings.favorites.findIndex(f => f.k === m.k && f.id === m.id);
  const part = (m.parts || [])[0];
  const items = [
    m.st === 'failed' ? { icon: 'retry', label: 'Tentar novamente', run: () => retry(m) } : null,
    (m.st === 'nodownload' || m.st === 'dlfailed') ? { icon: 'dl', label: 'Transferir multimédia', run: () => dlMms(m) } : null,
    { icon: 'reply', label: 'Responder', run: () => setReply(m) },
    m.body ? { icon: 'copy', label: 'Copiar texto', run: () => N('copy', { text: m.body }).then(() => toast('Copiado')) } : null,
    { icon: 'fwd', label: 'Reencaminhar', run: () => forward([m]) },
    m.body ? { icon: 'share', label: 'Partilhar texto', run: () => N('share', { text: m.body }).catch(fail) } : null,
    part ? { icon: 'clip', label: 'Partilhar anexo', run: () => N('shareAtt', { part: part.id, mime: part.ct, name: part.name }).catch(fail) } : null,
    { icon: 'star', label: favd >= 0 ? 'Remover dos favoritos' : 'Adicionar aos favoritos', run: () => { if (favd >= 0) S.settings.favorites.splice(favd, 1); else S.settings.favorites.push({ k: m.k, id: m.id, thread: C.thread, name: C.name, addrs: C.addrs, body: m.body || '(multimédia)', date: m.date }); saveSettings(); renderMsgs(); } },
    { icon: 'info', label: 'Detalhes', run: () => details(m) },
    { icon: 'list', label: 'Selecionar', run: () => { C.sel.add(key); renderMsgs(); chatTop(); } },
    { icon: 'trash', label: 'Eliminar', danger: true, run: () => delMsgs([m]) }
  ];
  if (el) await ctxMenu(items, el); else await menu(items);
}
function setReply(m) {
  C.reply = m; const rp = $('#rp');
  rp.innerHTML = `<div class="replychip">${ic('reply', 18)}<span>${esc(snip(m.body || 'Multimédia', 70))}</span><button class="ib" style="width:34px;height:34px" id="rpx" aria-label="Cancelar resposta">${ic('close', 18)}</button></div>`;
  $('#rpx').onclick = () => { C.reply = null; rp.innerHTML = ''; }; $('#ta').focus();
}
async function delMsgs(ms) {
  if (!ms.length || !await confirmBox('Eliminar mensagem' + (ms.length > 1 ? 's' : '') + '?', 'A eliminação é definitiva.')) return;
  try { await N('deleteMessages', { items: ms.map(m => ({ k: m.k, id: m.id })) }); toast('Eliminada'); } catch (e) { fail(e); }
  loadMsgs();
}
function details(m) {
  const sim = S.sims.find(s => s.sub === m.sub), sg = m.k === 's' ? segs(m.body || '') : null;
  const stTxt = { received: 'Recebida', sending: 'A enviar', sent: 'Enviada (aceite pela rede)', delivered: 'Entrega confirmada pela rede', undelivered: 'Entrega falhou', failed: 'Falha no envio', nodownload: 'Por transferir', downloading: 'A transferir', dlfailed: 'Transferência falhou' }[m.st] || m.st;
  const rows = [['Tipo', m.k === 'm' ? 'MMS' : 'SMS'], [m.dir === 'in' ? 'De' : 'Para', m.dir === 'in' ? (m.addr || C.addrs.join(', ')) : C.addrs.join(', ')], [m.dir === 'in' ? 'Recebida' : 'Enviada', full(m.date)], ...(m.dateSent ? [['Enviada pelo remetente', full(m.dateSent)]] : []), ['Estado', stTxt], ...(sim ? [['SIM', `SIM ${sim.slot} · ${sim.name}`]] : []), ...(sg ? [['Tamanho', `${sg.len} carateres · ${sg.n} SMS${sg.uni ? ' (Unicode)' : ''}`]] : [['Tamanho', kb(m.size || 0)]]), ...(m.subject ? [['Assunto', m.subject]] : [])];
  dialog({ title: 'Detalhes da mensagem', html: `<dl class="dl">${rows.map(r => `<dt>${esc(r[0])}</dt><dd>${esc(r[1])}</dd>`).join('')}</dl>`, ok: 'Fechar' });
}
async function retry(m) { try { await N('retry', { k: m.k, id: m.id }); toast('A reenviar…'); } catch (e) { fail(e); } loadMsgs(); }
async function dlMms(m) { try { await N('downloadMms', { id: m.id }); } catch (e) { fail(e); } loadMsgs(); }
async function forward(ms) {
  if (!ms.length) return;
  const text = ms.map(m => m.body).filter(Boolean).join('\n'); let atts = [];
  if (ms.length === 1) for (const p of (ms[0].parts || [])) { try { atts.push(await N('attachFromPart', { part: p.id, mime: p.ct, name: p.name })); } catch (e) { } }
  const tops = S.threads.slice().sort((a, b) => b.date - a.date).slice(0, 25);
  const it = await menu([{ icon: 'plus', label: 'Outro contacto ou número', v: 'new' }, ...tops.map(t => ({ icon: 'chat', label: t.name, sub: snip(t.snippet, 40), v: t }))], 'Reencaminhar para');
  if (!it) return;
  pop(); await wait(260);
  if (it.v === 'new') newChatView({ draft: text, atts }); else openChat({ thread: it.v.id, addrs: it.v.addrs, name: it.v.name, known: it.v.known }, { draft: text, atts });
}

/* =====================================================================
   COMPOSIÇÃO E MENU “+”
   ===================================================================== */
function updSend() {
  const ta = $('#ta'); if (!ta || !C) return;
  const subj = $('#subj').value.trim(), mms = C.atts.length || (C.subject && subj);
  $('#sendb').classList.toggle('on', !!(ta.value.trim() || C.atts.length));
  const cnt = $('#cnt');
  if (!mms && ta.value.length > 100) { const s = segs(ta.value); cnt.textContent = `${s.len}/${s.max} · ${s.n} SMS`; cnt.classList.add('on'); } else cnt.classList.remove('on');
  ta.placeholder = mms ? 'Mensagem multimédia (MMS)' : 'Escreva algo…';
}
function drawTray() {
  const t = $('#tray'); if (!t) return;
  t.innerHTML = C.atts.map((a, i) => `<div class="t" style="${a.thumb ? `background-image:url(${a.thumb})` : ''}">${a.thumb ? '' : ic(/^audio/.test(a.mime) ? 'audio' : 'clip', 26)}<small>${esc(a.name)}</small><button class="x" data-i="${i}" aria-label="Remover">${ic('close')}</button></div>`).join('');
  $$('.x', t).forEach(b => b.onclick = () => { const a = C.atts.splice(+b.dataset.i, 1)[0]; N('dropAtt', { id: a.id }).catch(() => { }); drawTray(); updSend(); });
}
function addAtt(a) {
  if (!/^(image|video\/(mp4|3gpp))|^audio/.test(a.mime) && !/^(text\/x-vcard|text\/vcard)/.test(a.mime)) toast('Aviso: este tipo de ficheiro pode não ser aceite pela operadora.');
  else if (a.size > 600 * 1024 && !/^image/.test(a.mime)) toast('Ficheiro grande (' + kb(a.size) + '): o limite de MMS costuma rondar 300 KB a 1 MB.');
  C.atts.push(a); drawTray(); updSend();
}
function insertText(t) { const ta = $('#ta'); ta.value += (ta.value && !ta.value.endsWith('\n') ? '\n' : '') + t; ta.dispatchEvent(new Event('input')); ta.focus(); }
async function sendNow() {
  if (!C || C.busy) return;
  const ta = $('#ta'), text = ta.value.trim(), subj = C.subject ? $('#subj').value.trim() : '';
  if (!text && !C.atts.length) return;
  if (!S.defaultSms) { if (await dialog({ title: 'Defina o Chats como predefinida', text: 'O Android só deixa guardar e enviar mensagens à aplicação SMS predefinida.', ok: 'Definir', cancel: 'Agora não' })) askDefault(); return; }
  const body = (C.reply ? `↪ “${snip(C.reply.body || 'Multimédia', 40).replace(/[”\n]/g, ' ')}”\n` : '') + text;
  const cc = C, mms = cc.atts.length || subj;
  if (!mms) {
    // SMS: aparece e limpa logo; o envio corre em segundo plano
    const tmp = { k: 's', id: 't' + Date.now(), addr: '', body, date: Date.now(), read: true, dir: 'out', st: 'sending' };
    ta.value = ''; S.drafts[cc.thread] = ''; ta.style.height = 'auto'; cc.reply = null; $('#rp').innerHTML = ''; updSend();
    const box = $('#msgs'), prevOut = $('.msg.out .stat', box);
    if (box) {
      const emp = $('.empty', box); if (emp) emp.remove();
      const last = cc.msgs[cc.msgs.length - 1];
      if (!last || dayKey(last.date) !== dayKey(tmp.date)) box.insertAdjacentHTML('beforeend', `<div class="day">${esc(dayLabel(tmp.date))}</div>`);
      cc.msgs.push(tmp);
      box.insertAdjacentHTML('beforeend', msgHtml(tmp, cc.msgs.length - 1, cc.msgs, tmp));
      $$('.msg.out .stat', box).forEach((x, n, a) => { if (n < a.length - 1 && !/Falhou|Não entregue/.test(x.textContent)) x.remove(); });
      box.scrollTop = box.scrollHeight;
    }
    N('sendSms', { addrs: cc.addrs, body, sub: curSub() }).then(() => setTimeout(() => { if (C === cc && cc.msgs.some(m => String(m.id)[0] === 't')) loadMsgs(); }, 2500)).catch(e => {
      fail(e); if (C === cc) { if (!$('#ta').value) { $('#ta').value = text; updSend(); } loadMsgs(); }
    });
    return;
  }
  const btn = $('#sendb'); C.busy = true; btn.style.opacity = .6;
  try {
    await N('sendMms', { addrs: C.addrs, body, subject: subj, atts: C.atts.map(a => a.id), sub: curSub() });
    ta.value = ''; S.drafts[C.thread] = ''; ta.style.height = 'auto'; C.atts = []; C.reply = null; $('#rp').innerHTML = ''; $('#subj').value = ''; $('#subj').hidden = true; C.subject = false; drawTray(); updSend();
  } catch (e) { fail(e); }
  if (C) { C.busy = false; btn.style.opacity = 1; loadMsgs(true); }
}
const COL = { clock: ['#7F9CF5', '#4A67D6'], bolt: ['#F7BE5B', '#E08E1B'], tag: ['#B59AF0', '#7B58D0'], user: ['#6CC8EA', '#2F95C0'], map: ['#F28B7D', '#D4533F'], image: ['#59CFA2', '#27A073'], video: ['#EE7BA0', '#CC3C6C'], audio: ['#F6A266', '#DB7430'], cal: ['#7C93EE', '#4A5FCC'], note: ['#EDC95A', '#C79A1A'], mic: ['#E8695A', '#BC3A2B'] };
function attachSheet() {
  $('#plus').classList.add('open');
  const items = [['clock', 'Programar', schedFromChat], ['bolt', 'Resposta rápida', quickSheet], ['tag', 'Assunto', toggleSubject], ['user', 'Contactos', pickContactAtt], ['map', 'Localização', shareLocation], ['image', 'Imagem', () => pickAtt('image/*')], ['video', 'Vídeo', () => pickAtt('video/*')], ['audio', 'Áudio', () => pickAtt('audio/*')], ['cal', 'Agenda', agendaSheet], ['note', 'Notas', notesSheet], ['mic', 'Gravador de voz', recSheet]];
  openSheet(`<h3>Adicionar</h3><div class="grid">${items.map((it, i) => `<button class="gi" data-i="${i}" style="--n:${i}"><span class="c" style="background:linear-gradient(150deg,${COL[it[0]][0]},${COL[it[0]][1]})">${ic(it[0], 26)}</span>${it[1]}</button>`).join('')}</div>`, el => {
    $$('.gi', el).forEach(b => b.onclick = () => { closeSheet(); setTimeout(items[+b.dataset.i][2], 200); });
    el.onclose = () => $('#plus') && $('#plus').classList.remove('open');
  });
}
async function pickAtt(mime) { try { const a = await N('pick', { mime }); if (a) addAtt(a); } catch (e) { fail(e); } }
function toggleSubject() { C.subject = !C.subject; const s = $('#subj'); s.hidden = !C.subject; if (C.subject) { s.focus(); toast('O assunto torna a mensagem num MMS'); } updSend(); }
async function pickContactAtt() { try { const c = await N('pickContact'); if (c) insertText(`👤 ${c.name}: ${c.number}`); } catch (e) { fail(e); } }
async function shareLocation() { toast('A obter localização…'); try { const l = await N('location'); insertText(`📍 Localização: https://maps.google.com/?q=${l.lat.toFixed(6)},${l.lon.toFixed(6)}`); } catch (e) { fail(e); } }
function quickSheet() {
  const q = S.settings.quick, cur = $('#ta').value.trim();
  openSheet(`<h3>Respostas rápidas</h3>${q.map((t, i) => `<button class="mi" data-i="${i}">${ic('bolt')}<span class="grow">${esc(t)}</span></button>`).join('') || '<p class="hint">Ainda não tem respostas guardadas.</p>'}${cur ? `<button class="mi" id="qs">${ic('plus')}<span class="grow">Guardar o texto atual<small>${esc(snip(cur, 50))}</small></span></button>` : ''}<button class="mi" id="qm">${ic('gear')}<span class="grow">Gerir respostas</span></button>`, el => {
    $$('.mi[data-i]', el).forEach(b => b.onclick = () => { closeSheet(); insertText(q[+b.dataset.i]); });
    const qs = $('#qs', el); if (qs) qs.onclick = () => { q.push(cur.slice(0, 300)); saveSettings(); closeSheet(); toast('Resposta guardada'); };
    $('#qm', el).onclick = () => { closeSheet(); setTimeout(quickView, 220); };
  });
}
async function agendaSheet() {
  try {
    const ev = await N('events');
    openSheet(`<h3>Agenda</h3>${ev.length ? ev.map((e, i) => `<button class="mi" data-i="${i}">${ic('cal')}<span class="grow">${esc(e.title)}<small>${esc(new Date(e.begin).toLocaleString('pt-PT', { dateStyle: 'medium', timeStyle: e.allDay ? undefined : 'short' }))}${e.loc ? ' · ' + esc(e.loc) : ''}</small></span></button>`).join('') : '<p class="hint">Sem eventos nos próximos 90 dias.</p>'}`, el => {
      $$('.mi', el).forEach(b => b.onclick = () => { const e = ev[+b.dataset.i]; closeSheet(); insertText(`📅 ${e.title}\n${new Date(e.begin).toLocaleString('pt-PT', { dateStyle: 'full', timeStyle: e.allDay ? undefined : 'short' })}${e.loc ? '\n' + e.loc : ''}`); });
    });
  } catch (e) { fail(e); }
}
function notesSheet() {
  const n = S.settings.notes;
  openSheet(`<h3>Notas</h3>${n.map((x, i) => `<div class="mi" data-i="${i}" role="button" tabindex="0">${ic('note')}<span class="grow">${esc(snip(x.t, 90))}<small>${esc(new Date(x.d).toLocaleDateString('pt-PT'))}</small></span><button class="ib" data-e="${i}" aria-label="Editar">${ic('edit', 20)}</button><button class="ib" data-d="${i}" aria-label="Eliminar">${ic('trash', 20)}</button></div>`).join('') || '<p class="hint">As notas ficam guardadas só neste telemóvel.</p>'}<button class="mi" id="nn">${ic('plus')}<span class="grow">Nova nota</span></button>`, el => {
    $$('.mi[data-i]', el).forEach(b => b.onclick = e => { if (e.target.closest('[data-e],[data-d]')) return; closeSheet(); insertText(n[+b.dataset.i].t); });
    $$('[data-e]', el).forEach(b => b.onclick = async () => { const i = +b.dataset.e; closeSheet(); const t = await dialog({ title: 'Editar nota', area: 'Nota', value: n[i].t, ok: 'Guardar', cancel: 'Cancelar' }); if (t && t.trim()) { n[i].t = t.trim(); saveSettings(); } notesSheet(); });
    $$('[data-d]', el).forEach(b => b.onclick = () => { n.splice(+b.dataset.d, 1); saveSettings(); notesSheet(); });
    $('#nn', el).onclick = async () => { closeSheet(); const t = await dialog({ title: 'Nova nota', area: 'Escreva a nota', ok: 'Guardar e inserir', cancel: 'Cancelar' }); if (t && t.trim()) { n.unshift({ t: t.trim(), d: Date.now() }); saveSettings(); insertText(t.trim()); } };
  });
}
async function recSheet() {
  try { await N('recStart'); } catch (e) { return fail(e); }
  let sec = 0, iv, lv; const t0 = Date.now();
  openSheet(`<h3>Gravador de voz</h3><div class="rec"><div class="tm" id="rt">0:00</div><div class="bars" id="rb">${'<i></i>'.repeat(24)}</div><button class="recbtn" id="rs" aria-label="Parar e anexar">${ic('check', 34)}</button><button class="btn ghost" id="rc">Cancelar</button></div>`, el => {
    const bars = $$('#rb i', el); let k = 0;
    iv = setInterval(() => { sec = Math.floor((Date.now() - t0) / 1000); $('#rt').textContent = Math.floor(sec / 60) + ':' + pad(sec % 60); }, 250);
    lv = setInterval(async () => { const a = await N('recLevel').catch(() => 0); bars[k++ % bars.length].style.height = (6 + Math.min(48, a / 400)) + 'px'; bars.forEach(b => b.style.opacity = .5 + Math.random() * .5); }, 110);
    const stop = () => { clearInterval(iv); clearInterval(lv); };
    $('#rs').onclick = async () => { stop(); el.onclose = null; closeSheet(); try { addAtt(await N('recStop')); } catch (e) { fail(e); } };
    $('#rc').onclick = () => { closeSheet(); };
    el.onclose = () => { stop(); N('recCancel').catch(() => { }); };
  });
}

/* =====================================================================
   MENSAGENS PROGRAMADAS
   ===================================================================== */
async function schedDialog(item) {
  const d = new Date(item.time || Date.now() + 3600e3); d.setSeconds(0, 0);
  const val = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const r = await dialog({ title: item.id ? 'Editar mensagem programada' : 'Programar mensagem', html: `<p style="margin-bottom:2px">Para: ${esc(nameFor(item.addrs))}</p><textarea id="sb" class="inp" rows="4" maxlength="2000" placeholder="Mensagem">${esc(item.body || '')}</textarea><input id="st" class="inp" type="datetime-local" value="${val}"><p class="hint" style="margin:10px 0 0">Enviada como SMS de texto.${S.exact ? '' : ' Sem a permissão de alarmes exatos, o envio pode atrasar alguns minutos.'}</p>`, ok: 'Guardar', cancel: 'Cancelar' });
  if (!r) return false;
  const body = $('#sb') ? $('#sb').value : item.body, tv = $('#st') ? $('#st').value : val;
  try {
    const o = await N('schedSave', { item: { id: item.id || 0, addrs: item.addrs, body, time: new Date(tv).getTime(), sub: item.sub ?? -1 } });
    toast('Programada para ' + new Date(o.time).toLocaleString('pt-PT', { dateStyle: 'medium', timeStyle: 'short' })); S.exact = o.exact; return true;
  } catch (e) { fail(e); return false; }
}
async function schedFromChat() {
  if (!S.defaultSms) return toast('Defina o Chats como aplicação SMS predefinida primeiro.', true);
  const ta = $('#ta'); if (await schedDialog({ addrs: C.addrs, body: ta.value.trim(), sub: curSub() })) { ta.value = ''; ta.dispatchEvent(new Event('input')); }
}
function subView(title, body, mount, o = {}) {
  return push(o.name || 'sub', (el, v) => {
    el.innerHTML = `<div class="top"><button class="ib" id="sb0" aria-label="Voltar">${ic('back')}</button><h2>${esc(title)}</h2>${o.actions || ''}</div><div class="scroll" id="sc0"><div class="pad" id="sbody">${body}</div></div>`;
    $('#sb0', el).onclick = pop; mount && mount(el, v);
  }, o);
}
async function schedView() {
  const v = subView('Programadas', '<div class="empty"><span class="spin"></span></div>', el => { }, { name: 'sched' });
  const render = async () => {
    let l = []; try { l = await N('schedList'); } catch (e) { fail(e); } if (!v.el.isConnected) return;
    l.sort((a, b) => a.time - b.time);
    const st = { pending: 'Agendada', sent: 'Enviada', failed: 'Não enviada' };
    $('#sbody', v.el).innerHTML = (!S.exact ? `<div class="card"><h3>Alarmes exatos desativados</h3><p>O Android pode atrasar o envio. Pode permitir alarmes exatos para o Chats.</p><div class="btns"><button class="btn" id="ex">Permitir</button></div></div>` : '') + (l.map(s => `<div class="row" data-id="${s.id}">${avatar(s.addrs, nameFor(s.addrs))}<div class="mid"><div class="nm">${esc(nameFor(s.addrs))}</div><div class="sn">${esc(s.body)}</div><div class="sn" style="font-size:12.5px;${s.status === 'failed' ? 'color:var(--danger)' : ''}">${st[s.status] || s.status} · ${new Date(s.time).toLocaleString('pt-PT', { dateStyle: 'medium', timeStyle: 'short' })}${s.error ? ' · ' + esc(s.error) : ''}</div></div><button class="ib" data-del="${s.id}" aria-label="Eliminar">${ic('trash', 22)}</button></div>`).join('') || `<div class="empty"><div class="big">${ic('clock')}</div><b style="color:var(--ink);font-size:18px">Nada programado</b><span>Abra uma conversa, toque em “+” e escolha “Programar”.</span></div>`);
    const ex = $('#ex', v.el); if (ex) ex.onclick = () => N('exactAlarmSettings');
    $$('.row', v.el).forEach(r => r.onclick = async e => {
      const id = +r.dataset.id; const s = l.find(x => x.id === id);
      if (e.target.closest('[data-del]')) { if (await confirmBox('Cancelar envio?', 'A mensagem programada será eliminada.', 'Eliminar')) { await N('schedDelete', { id }); render(); } return; }
      if (s.status === 'pending' && await schedDialog(s)) render();
    });
  };
  v.onShow = render; window.__sched = render; v.onClose = () => { window.__sched = null; }; render();
}
function favView() {
  const f = S.settings.favorites.slice().sort((a, b) => b.date - a.date);
  subView('Favoritas', f.map((m, i) => `<div class="row" data-i="${i}">${avatar(m.addrs || [], m.name || '')}<div class="mid"><div class="nm">${esc(m.name || '')}</div><div class="sn" style="white-space:normal">${esc(m.body)}</div></div><span class="tm" style="font-size:12px;color:var(--mute)">${short(m.date)}</span></div>`).join('') || `<div class="empty"><div class="big">${ic('star')}</div><b style="color:var(--ink);font-size:18px">Sem favoritas</b><span>Toque numa mensagem e escolha “Adicionar aos favoritos”.</span></div>`, el => {
    $$('.row', el).forEach(r => r.onclick = () => { const m = f[+r.dataset.i]; const t = S.threads.find(x => x.id === m.thread); openChat({ thread: m.thread, addrs: m.addrs || [], name: m.name, known: t && t.known }, { focus: { k: m.k, id: m.id } }); });
  });
}
function quickView() {
  const draw = el => {
    $('#sbody', el).innerHTML = `<div class="grp">${S.settings.quick.map((q, i) => `<div class="set"><span class="t">${esc(q)}</span><button class="ib" data-d="${i}" aria-label="Eliminar">${ic('trash', 22)}</button></div>`).join('')}</div><div class="btns" style="padding:0 6px"><button class="btn" id="qa">${ic('plus', 20)} Nova resposta</button></div>`;
    $$('[data-d]', el).forEach(b => b.onclick = () => { S.settings.quick.splice(+b.dataset.d, 1); saveSettings(); draw(el); });
    $('#qa', el).onclick = async () => { const t = await dialog({ title: 'Nova resposta rápida', input: 'Texto', ok: 'Guardar', cancel: 'Cancelar' }); if (t && t.trim()) { S.settings.quick.push(t.trim().slice(0, 300)); saveSettings(); draw(el); } };
  };
  subView('Respostas rápidas', '', draw);
}

/* =====================================================================
   DEFINIÇÕES
   ===================================================================== */
const sw = (id, on) => `<span class="sw ${on ? 'on' : ''}" id="${id}" role="switch" aria-checked="${!!on}"></span>`;
const seg = (id, opts, cur) => `<div class="seg" id="${id}">${opts.map(([k, l]) => `<button data-v="${k}" class="${cur === k ? 'on' : ''}">${l}</button>`).join('')}</div>`;
function bindSeg(el, id, fn) { $$('#' + id + ' button', el).forEach(b => b.onclick = () => { $$('#' + id + ' button', el).forEach(x => x.classList.toggle('on', x === b)); fn(b.dataset.v); }); }
function bindSw(el, id, key, after) { const s = $('#' + id, el); s.onclick = () => { const v = !S.settings[key]; set(key, v); s.classList.toggle('on', v); s.setAttribute('aria-checked', v); after && after(v); }; }

P.chev = 'M9 6l6 6-6 6';
const TC = { blue: ['#5BB4FF', '#1F6FF0'], green: ['#4FD18B', '#1E9F5E'], indigo: ['#8F8CFF', '#5448E0'], pink: ['#FF8DB3', '#E0407E'], orange: ['#FFB25E', '#EC7A12'], teal: ['#4FD6D0', '#18A3A0'], red: ['#FF8A7A', '#E04534'], gray: ['#A5ADB8', '#6C7683'], purple: ['#C08BFF', '#8744E0'], yellow: ['#FFD25E', '#E5A413'] };
const tile = (n, c) => `<span class="ti" style="background:linear-gradient(150deg,${c[0]},${c[1]})">${ic(n, 19)}</span>`;
const srow = (id, icon, col, label, right = '') => `<button class="set" id="${id}">${tile(icon, col)}<span class="t">${label}</span>${right}<svg class="i chev" viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></svg></button>`;
const swrow = (id, icon, col, label, on) => `<div class="set">${tile(icon, col)}<span class="t">${label}</span>${sw(id, on)}</div>`;
const rv = (t, k = '') => `<b class="rv ${k}">${esc(t)}</b>`;
function settingsView() {
  subView('Definições', '', (el, v) => {
    const st = S.settings;
    const draw = () => {
      const nSims = S.sims.length, sim = S.sims.find(x => x.sub === st.sub), allP = Object.values(S.perms).length && Object.values(S.perms).every(Boolean);
      const sb = $('#sbody', el); sb.classList.add('stg');
      sb.innerHTML = `
      <div class="sec">Geral</div><div class="grp">
        ${srow('sDef', 'chat', TC.blue, 'SMS predefinida', rv(S.defaultSms ? 'Ativa' : 'Inativa', S.defaultSms ? 'ok' : 'bad'))}
        ${srow('sPerm', 'check', TC.green, 'Permissões', rv(allP ? 'Concedidas' : 'Em falta', allP ? 'ok' : 'bad'))}</div>
      <div class="sec">Aparência</div><div class="grp">
        <div class="set stack">${tile('moon', TC.indigo)}<span class="t">Tema</span>${seg('sTheme', [['auto', 'Auto'], ['light', 'Claro'], ['dark', 'Escuro']], st.theme)}</div>
        ${srow('sWp', 'image', TC.pink, 'Fundo das conversas', st.wp.global ? rv('Personalizado') : '')}
        ${srow('sBub', 'palette', TC.orange, 'Balões e texto')}</div>
      <div class="sec">Notificações</div><div class="grp">
        ${swrow('wNot', 'bell', TC.red, 'Notificações', st.notify)}
        ${swrow('wBub', 'chat', TC.purple, 'Balão flutuante', st.bubble)}
        ${st.bubble && !S.overlay ? srow('sOv', 'gear', TC.gray, 'Mostrar sobre outras apps', rv('Em falta', 'bad')) : ''}
        <div class="set stack">${tile('eye', TC.teal)}<span class="t">Pré-visualização</span>${seg('sPrev', [['full', 'Total'], ['name', 'Nome'], ['hidden', 'Oculta']], st.preview)}</div>
        ${srow('sSnd', 'audio', TC.purple, 'Som', rv(st.soundTitle || 'Predefinido'))}
        ${swrow('wDn', 'check', TC.green, 'Entrega confirmada', st.deliveryNotif)}
        ${swrow('wCc', 'copy', TC.blue, 'Códigos de verificação', st.copyCodes)}
        ${srow('sSys', 'gear', TC.gray, 'Notificações do sistema')}</div>
      <div class="sec">Mensagens</div><div class="grp">
        ${swrow('wDr', 'mail', TC.blue, 'Relatórios de entrega', st.deliveryReports)}
        ${swrow('wAd', 'dl', TC.teal, 'Transferir MMS automaticamente', st.autoDownload)}
        ${nSims > 1 ? srow('sSim', 'sim', TC.orange, 'SIM para envio', rv(sim ? `SIM ${sim.slot} · ${sim.name}` : 'Predefinido')) : ''}
        ${srow('sQr', 'bolt', TC.yellow, 'Respostas rápidas')}
        ${srow('sFav', 'star', TC.orange, 'Favoritas')}
        ${srow('sSch', 'clock', TC.indigo, 'Programadas')}</div>
      <div class="sec">Dados</div><div class="grp">
        ${srow('sBlk', 'block', TC.red, 'Números bloqueados')}
        ${srow('sSto', 'disk', TC.gray, 'Armazenamento')}</div>
      <div class="sec">Sobre</div><div class="grp"><div class="set">${tile('info', TC.blue)}<span class="t">Versão</span>${rv(S.version || '1.0.0')}</div></div>
      <div style="height:24px"></div>`;
      $('#sDef', el).onclick = async () => { await askDefault(); draw(); };
      $('#sPerm', el).onclick = async () => { if (allP) N('appSettings'); else { await askAllPerms(); draw(); } };
      bindSeg(el, 'sTheme', x => { set('theme', x); applyTheme(); });
      $('#sWp', el).onclick = () => bgView('global', 'Fundo das conversas');
      $('#sBub', el).onclick = bubView;
      bindSw(el, 'wNot', 'notify'); bindSw(el, 'wBub', 'bubble', v => { if (v && !S.overlay) askOverlay(); draw(); });
      const so = $('#sOv', el); if (so) so.onclick = askOverlay;
      bindSeg(el, 'sPrev', x => set('preview', x));
      $('#sSnd', el).onclick = async () => { try { const r = await N('pickRingtone'); if (r) { set('sound', r.uri === 'none' ? 'none' : r.uri); set('soundTitle', r.title); draw(); } } catch (e) { fail(e); } };
      bindSw(el, 'wDn', 'deliveryNotif'); bindSw(el, 'wCc', 'copyCodes'); bindSw(el, 'wDr', 'deliveryReports'); bindSw(el, 'wAd', 'autoDownload');
      $('#sSys', el).onclick = () => N('notifSettings');
      const ss = $('#sSim', el); if (ss) ss.onclick = async () => { const it = await menu([{ label: 'Predefinido do sistema', v: -1 }, ...S.sims.map(x => ({ icon: 'sim', label: `SIM ${x.slot} · ${x.name}`, v: x.sub }))], 'SIM para envio'); if (it) { set('sub', it.v); draw(); } };
      $('#sQr', el).onclick = quickView; $('#sFav', el).onclick = favView; $('#sSch', el).onclick = schedView; $('#sBlk', el).onclick = blockedView; $('#sSto', el).onclick = storageView;
    };
    v.redraw = draw; v.onShow = draw; draw();
  }, { name: 'settings' });
}
function settingsRedraw() { const v = views.find(x => x.name === 'settings'); if (v && v.redraw) v.redraw(); }
async function blockedView() {
  const v = subView('Números bloqueados', '<div class="empty"><span class="spin"></span></div>');
  const draw = async () => {
    let l = []; try { l = await N('blocked'); } catch (e) { }
    $('#sbody', v.el).innerHTML = l.length ? `<div class="grp">${l.map(n => `<div class="set">${ic('block')}<span class="t">${esc(n)}</span><button class="btn ghost" data-u="${esc(n)}">Desbloquear</button></div>`).join('')}</div>` : `<div class="empty"><div class="big">${ic('block')}</div><b style="color:var(--ink);font-size:18px">Sem números bloqueados</b><span></span></div>`;
    $$('[data-u]', v.el).forEach(b => b.onclick = async () => { try { await N('unblock', { number: b.dataset.u }); toast('Desbloqueado'); } catch (e) { fail(e); } draw(); });
  };
  draw();
}
async function storageView() {
  const v = subView('Armazenamento', '<div class="empty"><span class="spin"></span></div>');
  const draw = async () => {
    let o = { sms: 0, mms: 0, cache: 0, wallpapers: 0 }; try { o = await N('storage'); } catch (e) { fail(e); }
    $('#sbody', v.el).innerHTML = `<div class="grp"><div class="set"><span class="t">SMS guardados</span><b>${o.sms}</b></div><div class="set"><span class="t">MMS guardados</span><b>${o.mms}</b></div><div class="set"><span class="t">Cache</span><b>${kb(o.cache)}</b></div><div class="set"><span class="t">Fundos personalizados</span><b>${kb(o.wallpapers)}</b></div></div>
    <div class="btns" style="padding:8px 6px"><button class="btn ghost" id="cc">Limpar cache</button><button class="btn danger" id="co">Eliminar mensagens antigas…</button></div>`;
    $('#cc', v.el).onclick = async () => { await N('clearCache'); toast('Cache limpa'); draw(); };
    $('#co', v.el).onclick = async () => {
      const d = await dialog({ title: 'Eliminar mensagens antigas', text: 'Indique há quantos dias (ou mais) as mensagens devem ser eliminadas. Esta ação não pode ser desfeita.', input: 'Dias (ex.: 365)', value: '365', ok: 'Eliminar', cancel: 'Cancelar', danger: true });
      const n = parseInt(d, 10); if (!n || n < 1) return;
      if (!await confirmBox('Confirmar eliminação', `Eliminar todas as mensagens com mais de ${n} dias?`)) return;
      try { const r = await N('deleteOld', { days: n }); toast(r + ' mensagens eliminadas'); } catch (e) { fail(e); } draw(); loadThreads();
    };
  };
  draw();
}

/* ---------- balões ---------- */
function bubView() {
  const b = S.settings.bub, dark = () => document.documentElement.dataset.t === 'dark';
  subView('Balões', `<div class="pv"><div class="msgs"><div class="msg in"><div class="bub">Olá! Como correu o dia?<span class="tm">10:41</span></div></div><div class="msg out"><div class="bub">Muito bem, obrigado 🙂<span class="tm">10:42</span></div><div class="stat">Entregue ✓✓</div></div></div></div>
  <div class="grp"><div class="set"><span class="t">Balão enviado</span><input type="color" id="cS" value="${b.sent || (dark() ? '#1F5E52' : '#CBEADF')}"></div>
  <div class="set"><span class="t">Balão recebido</span><input type="color" id="cR" value="${b.recv || (dark() ? '#26332F' : '#ECE7DA')}"></div>
  <div class="set" style="display:block"><div class="lab" style="margin:0"><span>Arredondamento</span><span id="vR">${b.r}px</span></div><input type="range" id="rR" min="6" max="28" value="${b.r}"></div>
  <div class="set" style="display:block"><div class="lab" style="margin:0"><span>Tamanho do texto</span><span id="vF">${b.fs}px</span></div><input type="range" id="rF" min="13" max="22" value="${b.fs}"></div></div>
  <div class="btns" style="padding:10px 6px"><button class="btn ghost" id="bR">Repor</button></div>`, el => {
    const up = () => { saveSettings(); applyTheme(); };
    $('#cS', el).oninput = e => { b.sent = e.target.value; up(); }; $('#cR', el).oninput = e => { b.recv = e.target.value; up(); };
    $('#rR', el).oninput = e => { b.r = +e.target.value; $('#vR', el).textContent = b.r + 'px'; up(); };
    $('#rF', el).oninput = e => { b.fs = +e.target.value; $('#vF', el).textContent = b.fs + 'px'; up(); };
    $('#bR', el).onclick = () => { Object.assign(b, { sent: '', recv: '', r: 18, fs: 16 }); up(); pop(); setTimeout(bubView, 80); };
  });
}

/* ---------- fundo personalizado ---------- */
async function bgView(key, title) {
  const w = S.settings.wp; let cfg = w[key] ? { ...w[key] } : { x: 50, y: 50, z: 1.05, dim: 0.25, blur: 0 };
  let img = w[key] ? await wpData(key) : null;
  subView(title, `<div class="pv" id="pv"><div class="wp" id="pw"></div><div class="wpd" id="pd"></div><div class="msgs"><div class="msg in"><div class="bub">Pré-visualização do fundo<span class="tm">10:41</span></div></div><div class="msg out"><div class="bub">Ótima legibilidade 👌<span class="tm">10:42</span></div></div></div></div>
  <div class="btns" style="padding:0 6px"><button class="btn" id="bP">${ic('image', 20)} Escolher da galeria</button><button class="btn ghost" id="bX">Restaurar original</button></div>
  <div class="grp" style="margin-top:14px;padding:6px 16px 14px" id="bC">
    <div class="lab"><span>Posição horizontal</span><span id="l1"></span></div><input type="range" id="r1" min="0" max="100">
    <div class="lab"><span>Posição vertical</span><span id="l2"></span></div><input type="range" id="r2" min="0" max="100">
    <div class="lab"><span>Zoom</span><span id="l3"></span></div><input type="range" id="r3" min="100" max="250">
    <div class="lab"><span>Filtro de legibilidade</span><span id="l4"></span></div><input type="range" id="r4" min="0" max="90">
    <div class="lab"><span>Desfocagem</span><span id="l5"></span></div><input type="range" id="r5" min="0" max="20"></div>
  `, el => {
    const paint = () => {
      const pw = $('#pw', el); pw.style.backgroundImage = img ? `url(${img})` : ''; pw.style.backgroundPosition = `${cfg.x}% ${cfg.y}%`; pw.style.transform = `scale(${cfg.z})`; pw.style.filter = `blur(${cfg.blur}px)`;
      $('#pd', el).style.background = img ? `color-mix(in srgb, var(--bg) ${Math.round(cfg.dim * 100)}%, transparent)` : '';
      $('#bC', el).style.opacity = img ? 1 : .4; $('#bC', el).style.pointerEvents = img ? 'auto' : 'none';
      [['r1', 'x', 1, '%'], ['r2', 'y', 1, '%'], ['r3', 'z', 100, '×'], ['r4', 'dim', 100, '%'], ['r5', 'blur', 1, 'px']].forEach(([id, k, m, u], i) => { $('#' + id, el).value = cfg[k] * m; $('#l' + (i + 1), el).textContent = (k === 'z' ? cfg[k].toFixed(2) : Math.round(cfg[k] * m)) + (k === 'z' ? '×' : u); });
    };
    const save = () => { if (img) { w[key] = { ...cfg }; saveSettings(); applyWp(); } };
    [['r1', 'x', 1], ['r2', 'y', 1], ['r3', 'z', 100], ['r4', 'dim', 100], ['r5', 'blur', 1]].forEach(([id, k, m]) => $('#' + id, el).oninput = e => { cfg[k] = +e.target.value / m; paint(); save(); });
    $('#bP', el).onclick = async () => { try { const d = await N('pickWallpaper', { key }); if (d) { img = d; S.wpc[key] = d; save(); paint(); toast('Fundo aplicado'); } } catch (e) { fail(e); } };
    $('#bX', el).onclick = async () => { await N('removeWallpaper', { key }).catch(() => { }); delete w[key]; delete S.wpc[key]; saveSettings(); img = null; paint(); toast('Fundo original restaurado'); };
    paint();
  });
}

/* =====================================================================
   LIXO (30 dias) E PROTEÇÃO (PIN, senha ou padrão)
   ===================================================================== */
const LOCKN = { pin: 'PIN', password: 'Senha', pattern: 'Padrão' };
S.trashLock = '';
function dropTop() { const v = views.pop(); if (v) v.el.remove(); const p = views[views.length - 1]; if (p) p.el.classList.remove('under'); }
function lockPad(type, o) {
  const el = document.createElement('div'); el.className = 'lockpad';
  el.innerHTML = `<div class="lk-ico">${ic('lock', 30)}</div><h3>${esc(o.title || '')}</h3><p class="lk-msg">${esc(o.hint || '')}</p><div class="lk-body"></div>`;
  const body = $('.lk-body', el), msg = $('.lk-msg', el); let busy = false, reset = () => { };
  const say = (t, bad) => { msg.textContent = t; msg.classList.toggle('bad', !!bad); };
  const shake = () => { el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake'); };
  const go = async sec => {
    if (busy) return; busy = true;
    let r; try { r = await o.onDone(sec); } catch (e) { r = { error: e.message }; }
    busy = false;
    if (r && r.error) { say(r.error, true); shake(); setTimeout(() => reset(), 350); }
    else if (r && r.hint) { say(r.hint); reset(); }
  };
  if (type === 'pin') {
    let val = '';
    body.innerHTML = `<div class="pdots"></div><div class="pkeys">${[1, 2, 3, 4, 5, 6, 7, 8, 9, '⌫', 0, 'OK'].map(k => `<button data-k="${k}">${k}</button>`).join('')}</div>`;
    const dots = $('.pdots', body), draw = () => { dots.innerHTML = Array.from({ length: Math.max(4, val.length) }, (_, i) => `<i class="${i < val.length ? 'on' : ''}"></i>`).join(''); };
    draw(); reset = () => { val = ''; draw(); };
    body.onclick = e => {
      const b = e.target.closest('button'); if (!b || busy) return; const k = b.dataset.k;
      if (k === '⌫') val = val.slice(0, -1);
      else if (k === 'OK') { if (val.length < 4) { say('Use pelo menos 4 dígitos', true); shake(); return; } return go(val); }
      else if (val.length < 8) val += k;
      draw();
    };
  } else if (type === 'password') {
    body.innerHTML = `<input class="pwin" type="password" placeholder="Senha" autocomplete="off" autocapitalize="off"><button class="btn" style="margin-top:14px;width:100%">Continuar</button>`;
    const inp = $('.pwin', body); reset = () => { inp.value = ''; inp.focus(); };
    const sub = () => { const v = inp.value; if (v.length < 4) { say('Use pelo menos 4 caracteres', true); shake(); return; } go(v); };
    $('.btn', body).onclick = sub; inp.onkeydown = e => { if (e.key === 'Enter') sub(); };
    setTimeout(() => inp.focus(), 380);
  } else {
    body.innerHTML = `<svg class="pat" viewBox="0 0 240 240"><polyline class="pl" points=""/>${[...Array(9)].map((_, i) => `<circle class="pd" cx="${40 + (i % 3) * 80}" cy="${40 + Math.floor(i / 3) * 80}" r="9"/>`).join('')}</svg>`;
    const svg = $('.pat', body), pl = $('.pl', svg), dots = $$('.pd', svg); let path = [], drawing = false, cur = null;
    const xy = i => [40 + (i % 3) * 80, 40 + Math.floor(i / 3) * 80];
    const upd = () => { const pts = path.map(i => xy(i).join(',')); if (cur) pts.push(cur.join(',')); pl.setAttribute('points', pts.join(' ')); dots.forEach((d, i) => d.classList.toggle('on', path.includes(i))); };
    const hit = e => { const r = svg.getBoundingClientRect(), x = (e.clientX - r.left) * 240 / r.width, y = (e.clientY - r.top) * 240 / r.height; cur = [x, y]; for (let i = 0; i < 9; i++) { const [cx, cy] = xy(i); if (Math.hypot(x - cx, y - cy) < 30 && !path.includes(i)) path.push(i); } upd(); };
    reset = () => { path = []; cur = null; upd(); };
    svg.addEventListener('pointerdown', e => { if (busy) return; try { svg.setPointerCapture(e.pointerId); } catch (_) { } drawing = true; path = []; hit(e); });
    svg.addEventListener('pointermove', e => { if (drawing) hit(e); });
    const end = () => { if (!drawing) return; drawing = false; cur = null; upd(); if (path.length < 4) { say('Ligue pelo menos 4 pontos', true); shake(); setTimeout(reset, 450); return; } go(path.join('')); };
    svg.addEventListener('pointerup', end); svg.addEventListener('pointercancel', end);
  }
  return { el, say };
}
function lockScreen(name, title, build) {
  return push(name, el => {
    el.innerHTML = `<div class="top"><button class="ib" aria-label="Voltar">${ic('back')}</button><h2>${esc(title)}</h2></div><div class="scroll"><div class="pad" id="lkh"></div></div>`;
    $('.ib', el).onclick = pop; $('#lkh', el).appendChild(build().el);
  }, { name });
}
async function trashEntry() {
  let st = ''; try { st = await N('trashLockState'); } catch (e) { return fail(e); }
  S.trashLock = st;
  if (!st) return trashView();
  const hint = { pin: 'Introduza o PIN', password: 'Introduza a senha', pattern: 'Desenhe o padrão' }[st];
  lockScreen('trashlock', 'Lixo', () => lockPad(st, {
    title: 'Lixo protegido', hint,
    onDone: async sec => {
      const r = await N('trashLockCheck', { secret: sec }).catch(() => ({ ok: false }));
      if (r.ok) { dropTop(); trashView(); return; }
      return { error: r.wait ? `Demasiadas tentativas. Aguarde ${r.wait} s.` : 'Incorreto. Tente novamente.' };
    }
  }));
}
function lockSetup(type) {
  let first = null;
  const hs = { pin: ['Escolha um PIN (4 a 8 dígitos)', 'Repita o PIN'], password: ['Escolha uma senha (mín. 4 caracteres)', 'Repita a senha'], pattern: ['Desenhe um padrão (mín. 4 pontos)', 'Desenhe o padrão outra vez'] }[type];
  lockScreen('trashp2', LOCKN[type], () => lockPad(type, {
    title: 'Proteger o lixo', hint: hs[0],
    onDone: async sec => {
      if (first === null) { first = sec; return { hint: hs[1] }; }
      if (sec !== first) { first = null; return { error: 'Não coincidem. Comece de novo.' }; }
      await N('trashLockSet', { type, secret: sec }); S.trashLock = type; toast('Proteção ativada'); pop();
    }
  }));
}
function lockView() {
  subView('Proteção do lixo', '', (el, v) => {
    const draw = () => {
      const t = S.trashLock;
      $('#sbody', el).innerHTML = `<p class="hint">${t ? `O lixo está protegido com ${LOCKN[t].toLowerCase()}.` : 'Opcional. Ao ativar, o lixo só abre com PIN, senha ou padrão.'}</p>
      <div class="grp">${t ? srow('lkC', 'lock', TC.blue, 'Alterar proteção', rv(LOCKN[t])) + srow('lkO', 'block', TC.red, 'Desativar proteção') : srow('lkA', 'lock', TC.green, 'Ativar proteção')}</div>
      <p class="hint">Se esquecer a proteção não é possível recuperá-la. As mensagens do lixo continuam a ser apagadas ao fim de 30 dias.</p>`;
      const pick = async () => { const it = await menu([{ icon: 'lock', label: 'PIN', sub: '4 a 8 dígitos', v: 'pin' }, { icon: 'lock', label: 'Senha', sub: 'Letras e números', v: 'password' }, { icon: 'lock', label: 'Padrão', sub: 'Ligar pontos', v: 'pattern' }], 'Tipo de proteção'); if (it) lockSetup(it.v); };
      const a = $('#lkA', el), c = $('#lkC', el), o = $('#lkO', el);
      if (a) a.onclick = pick; if (c) c.onclick = pick;
      if (o) o.onclick = () => lockScreen('trashp2', 'Desativar proteção', () => lockPad(S.trashLock, {
        title: 'Confirme para desativar', hint: { pin: 'Introduza o PIN', password: 'Introduza a senha', pattern: 'Desenhe o padrão' }[S.trashLock],
        onDone: async sec => { const ok = await N('trashLockOff', { secret: sec }).catch(() => false); if (!ok) return { error: 'Incorreto. Tente novamente.' }; S.trashLock = ''; toast('Proteção desativada'); pop(); }
      }));
    };
    v.onShow = draw; draw();
  }, { name: 'trashp' });
}
const daysTxt = n => `${n} ${n === 1 ? 'dia' : 'dias'}`;
function trashView() {
  subView('Lixo', '<div class="empty"><span class="spin"></span></div>', (el, vw) => {
    const draw = async () => {
      let l = []; try { l = await N('trashList'); } catch (e) { fail(e); return; } if (!el.isConnected) return;
      $('#sbody', el).innerHTML = `<p class="hint">As mensagens eliminadas ficam aqui durante 30 dias. Depois são apagadas para sempre.</p>` + (l.length ? l.map((g, i) => `<div class="row" data-i="${i}">${avatar(g.addrs, g.name)}<div class="mid"><div class="nm">${esc(g.name)}</div><div class="sn">${g.count} ${g.count === 1 ? 'mensagem' : 'mensagens'}${g.snippet ? ' · ' + esc(g.snippet) : ''}</div><div class="sn" style="font-size:12.5px;${g.left <= 3 ? 'color:var(--danger);font-weight:600' : ''}">Apaga em ${daysTxt(g.left)}</div></div></div>`).join('') : `<div class="empty"><div class="big">${ic('trash')}</div><b style="color:var(--ink);font-size:18px">Lixo vazio</b><span>As mensagens que eliminar aparecem aqui.</span></div>`);
      $$('.row', el).forEach(r => r.onclick = () => trashGroup(l[+r.dataset.i], draw));
    };
    $('#tmore', el).onclick = () => menu([
      { icon: 'lock', label: 'Proteção do lixo', sub: S.trashLock ? 'Ativa · ' + LOCKN[S.trashLock] : 'Desativada', run: lockView },
      { icon: 'trash', label: 'Esvaziar lixo', danger: true, run: async () => { if (await confirmBox('Esvaziar lixo?', 'Todas as mensagens do lixo serão eliminadas para sempre.', 'Esvaziar')) { try { await N('trashEmpty'); toast('Lixo vazio'); } catch (e) { fail(e); } draw(); } } }
    ]);
    vw.onShow = draw; draw();
  }, { name: 'trash', actions: `<button class="ib" id="tmore" aria-label="Mais">${ic('more')}</button>` });
}
function trashGroup(g, refresh) {
  subView(g.name, '<div class="empty"><span class="spin"></span></div>', el => {
    let items = [];
    const draw = async () => {
      try { items = await N('trashItems', { ckey: g.ckey }); } catch (e) { fail(e); return; } if (!el.isConnected) return;
      if (!items.length) { $('#sbody', el).innerHTML = `<div class="empty"><div class="big">${ic('trash')}</div><b style="color:var(--ink);font-size:18px">Nada aqui</b><span></span></div>`; setTimeout(pop, 400); return; }
      $('#sbody', el).innerHTML = items.map((m, i) => `<div class="trow ${m.dir}" data-i="${i}"><div class="tbub">${m.subject ? `<b>${esc(m.subject)}</b><br>` : ''}${esc(m.body) || (m.atts.length ? '' : '(sem texto)')}${m.atts.length ? `<div class="tatt">${ic('clip', 14)} ${m.atts.length} ${m.atts.length === 1 ? 'anexo' : 'anexos'}</div>` : ''}</div><div class="tmeta">${m.dir === 'in' ? 'Recebida' : 'Enviada'} · ${esc(new Date(m.date).toLocaleString('pt-PT', { dateStyle: 'short', timeStyle: 'short' }))} · apaga em ${daysTxt(m.left)}</div></div>`).join('') +
        `<div class="btns" style="padding:14px 6px"><button class="btn" id="tra">Restaurar tudo</button><button class="btn danger" id="tda">Eliminar tudo</button></div>`;
      $$('.trow', el).forEach(r => r.onclick = () => { const m = items[+r.dataset.i]; menu([{ icon: 'retry', label: 'Restaurar', run: () => restore([m.id]) }, { icon: 'trash', label: 'Eliminar para sempre', danger: true, run: () => purge([m.id], 'Esta mensagem não poderá ser recuperada.') }]); });
      $('#tra', el).onclick = () => restore(items.map(m => m.id));
      $('#tda', el).onclick = () => purge(items.map(m => m.id), 'Estas mensagens não poderão ser recuperadas.');
    };
    const restore = async ids => {
      if (!S.defaultSms) return toast('Defina o Chats como aplicação SMS predefinida para restaurar.', true);
      try { const n = await N('trashRestore', { ids }); toast(n === ids.length ? (n === 1 ? 'Mensagem restaurada' : n + ' mensagens restauradas') : `Restauradas ${n} de ${ids.length}`, n !== ids.length); } catch (e) { fail(e); }
      await draw(); refresh(); loadThreads();
    };
    const purge = async (ids, txt) => { if (!await confirmBox('Eliminar para sempre?', txt, 'Eliminar')) return; try { await N('trashDelete', { ids }); } catch (e) { fail(e); } await draw(); refresh(); };
    draw();
  }, { name: 'trashg' });
}

/* =====================================================================
   ARRANQUE E EVENTOS
   ===================================================================== */
const refreshDeb = debounce(p => { if (C) { if (p.thread == null || p.thread === C.thread || p.thread < 0) loadMsgs(); } else loadThreads(); }, 300);
window.__ev = (n, d) => {
  let p = {}; try { p = JSON.parse(d); } catch (e) { }
  if (n === 'changed') refreshDeb(p);
  else if (n === 'audio') { VS = Object.assign({ part: -1, playing: false, pos: 0, dur: 0, speed: 1 }, p); if (p.dur) durs[p.part] = p.dur; voiceApply(); }
  else if (n === 'open') handleOpen(p);
  else if (n === 'default' || n === 'perms') refreshState();
  else if (n === 'scheduled' && window.__sched) window.__sched();
};
window.__resume = () => {
  if (S.trashLock && views.some(v => /^trash/.test(v.name))) { while (views.length > 1 && /^trash/.test(views[views.length - 1].name)) dropTop(); }
  if (!S.loaded && !S.perms.sms) { refreshState(); return; } refreshState(); if (C) loadMsgs(); };
document.addEventListener('contextmenu', e => e.preventDefault());

(async function boot() {
  const t0 = Date.now();
  try {
    const i = await N('init');
    Object.assign(S.settings, i.settings); S.settings.bub = Object.assign({}, DEF.bub, S.settings.bub || {}); S.settings.wp = S.settings.wp || {};
    for (const k of ['pinned', 'archived', 'muted', 'favorites', 'notes', 'quick']) if (!Array.isArray(S.settings[k])) S.settings[k] = DEF[k].slice();
    S.defaultSms = i.defaultSms; S.perms = i.perms; S.sims = i.sims; S.exact = i.exact; S.overlay = i.overlay !== false; S.sdk = i.sdk; S.defaultSub = i.defaultSub; S.version = i.version;
    applyTheme();
    if (S.perms.sms) cacheLoad();
    push('home', homeView, { cls: 'first', onBack: () => v_home.onBack() });
    if (S.perms.contacts) N('contacts').then(c => { S.contacts = c; renderChips(); }).catch(() => { });
    if (S.perms.sms) loadThreads();
    if (i.pending) setTimeout(() => handleOpen(i.pending), 500);
    if (!S.perms.sms || !S.defaultSms) renderThreads();
  } catch (e) {
    push('home', homeView, { cls: 'first', onBack: () => false }); toast(e.message, true);
  }
})();
