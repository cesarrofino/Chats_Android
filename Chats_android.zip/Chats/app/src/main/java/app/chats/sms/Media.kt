package app.chats.sms

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import android.webkit.MimeTypeMap
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

object Media {
    data class Att(val id: String, val uri: Uri, val mime: String, val name: String, val size: Long)
    class Blob(val ct: String, val name: String, val data: ByteArray)

    /** Anexos escolhidos: o JavaScript só conhece identificadores, nunca URIs arbitrários. */
    val atts = ConcurrentHashMap<String, Att>()
    private val counter = AtomicInteger(0)

    fun register(c: Context, uri: Uri, hintMime: String? = null, hintName: String? = null): Att {
        var name = hintName ?: "ficheiro"
        var size = -1L
        try {
            c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
                ?.use { cur ->
                    if (cur.moveToFirst()) {
                        cur.getString(0)?.let { n -> name = n }
                        size = cur.getLong(1)
                    }
                }
        } catch (_: Exception) {
        }
        var mime = hintMime ?: c.contentResolver.getType(uri) ?: "application/octet-stream"
        if (mime == "application/octet-stream") {
            val ext = MimeTypeMap.getFileExtensionFromUrl(name).lowercase()
            MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)?.let { mime = it }
        }
        val id = "a" + counter.incrementAndGet()
        val a = Att(id, uri, mime, name, size)
        atts[id] = a
        return a
    }

    fun toJson(c: Context, a: Att): JSONObject = JSONObject()
        .put("id", a.id).put("mime", a.mime).put("name", a.name).put("size", a.size)
        .put("thumb", thumb(c, a.uri, a.mime, 240) ?: JSONObject.NULL)

    fun thumb(c: Context, uri: Uri, mime: String, max: Int): String? = try {
        val bmp: Bitmap? = when {
            mime.startsWith("image/") -> load(c, uri, max)
            mime.startsWith("video/") -> {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(c, uri)
                    r.getFrameAtTime(0)?.let { scale(it, max) }
                } finally {
                    r.release()
                }
            }
            else -> null
        }
        bmp?.let { "data:image/jpeg;base64," + b64(it, 78) }
    } catch (e: Throwable) {
        null
    }

    fun load(c: Context, uri: Uri, maxEdge: Int): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        if (o.outWidth <= 0) return null
        var s = 1
        while (o.outWidth / (s * 2) >= maxEdge || o.outHeight / (s * 2) >= maxEdge) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        var bmp = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: return null
        val rot = try {
            c.contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
            } ?: 1
        } catch (e: Throwable) {
            1
        }
        val deg = when (rot) {
            6 -> 90f
            3 -> 180f
            8 -> 270f
            else -> 0f
        }
        if (deg != 0f) {
            val m = Matrix()
            m.postRotate(deg)
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        return scale(bmp, maxEdge)
    }

    fun scale(b: Bitmap, max: Int): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= max) return b
        val f = max.toFloat() / m
        return Bitmap.createScaledBitmap(
            b, (b.width * f).toInt().coerceAtLeast(1), (b.height * f).toInt().coerceAtLeast(1), true
        )
    }

    fun jpeg(b: Bitmap, q: Int): ByteArray {
        val o = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, q, o)
        return o.toByteArray()
    }

    fun b64(b: Bitmap, q: Int): String = Base64.encodeToString(jpeg(b, q), Base64.NO_WRAP)

    private fun baseName(n: String): String {
        val b = n.substringBeforeLast('.', n).replace(Regex("[^A-Za-z0-9_-]"), "_")
        return if (b.isEmpty()) "img" else b.take(40)
    }

    /** Prepara um anexo para MMS: imagens são redimensionadas até caberem no limite. */
    fun blob(c: Context, a: Att, budget: Int): Blob {
        if (a.mime.startsWith("image/") && a.mime != "image/gif") {
            var edge = 1280
            var q = 85
            while (true) {
                val bmp = load(c, a.uri, edge) ?: throw Exception("Não foi possível ler a imagem «${a.name}».")
                val d = jpeg(bmp, q)
                if (d.size <= budget) return Blob("image/jpeg", baseName(a.name) + ".jpg", d)
                if (edge <= 320 && q <= 45) {
                    throw Exception("A imagem «${a.name}» não cabe no limite de MMS (${budget / 1024} KB).")
                }
                if (q > 55) q -= 10 else edge = (edge * 0.75).toInt().coerceAtLeast(320)
                if (edge == 320 && q <= 55) q = (q - 5).coerceAtLeast(40)
            }
        }
        val d = c.contentResolver.openInputStream(a.uri)?.use { it.readBytes() }
            ?: throw Exception("Não foi possível ler o ficheiro «${a.name}».")
        if (d.size > budget) {
            throw Exception(
                "«${a.name}» tem ${d.size / 1024} KB e excede o limite de MMS da operadora (${budget / 1024} KB). " +
                    "Escolha um ficheiro mais pequeno."
            )
        }
        val safe = a.name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(60)
        return Blob(a.mime, safe, d)
    }

    // ---- Gravador de voz ----
    private var rec: MediaRecorder? = null
    private var recFile: File? = null

    @Suppress("DEPRECATION")
    fun recStart(c: Context) {
        recCancel()
        val f = File(c.cacheDir, "voz_" + System.currentTimeMillis() + ".amr")
        val mr = if (android.os.Build.VERSION.SDK_INT >= 31) MediaRecorder(c) else MediaRecorder()
        mr.setAudioSource(MediaRecorder.AudioSource.MIC)
        mr.setOutputFormat(MediaRecorder.OutputFormat.AMR_NB)
        mr.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
        mr.setOutputFile(f.absolutePath)
        mr.prepare()
        mr.start()
        rec = mr
        recFile = f
    }

    fun recLevel(): Int = try {
        rec?.maxAmplitude ?: 0
    } catch (e: Throwable) {
        0
    }

    fun recStop(c: Context): Att? {
        val mr = rec ?: return null
        val f = recFile
        rec = null
        recFile = null
        try {
            mr.stop()
        } catch (e: Throwable) {
            f?.delete()
            mr.release()
            return null
        }
        mr.release()
        if (f == null || f.length() < 200) {
            f?.delete()
            return null
        }
        return register(c, Uri.fromFile(f), "audio/amr", "Mensagem de voz.amr")
    }

    fun recCancel() {
        try {
            rec?.stop()
        } catch (_: Throwable) {
        }
        try {
            rec?.release()
        } catch (_: Throwable) {
        }
        rec = null
        recFile?.delete()
        recFile = null
    }
}
