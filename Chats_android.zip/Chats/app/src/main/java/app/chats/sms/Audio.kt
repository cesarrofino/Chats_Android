package app.chats.sms

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.File

/** Reprodução nativa de mensagens de voz (leve: sem base64, sem <audio> na WebView). */
object Player {
    private val h = Handler(Looper.getMainLooper())
    private var mp: MediaPlayer? = null
    private var part = -1L
    private var speed = 1f
    private val cache = HashMap<Long, Int>()

    private val tick = object : Runnable {
        override fun run() {
            emit()
            if (mp?.isPlaying == true) h.postDelayed(this, 120)
        }
    }

    private fun ext(mime: String) = when {
        mime.contains("amr") -> "amr"
        mime.contains("3gp") -> "3gp"
        mime.contains("mp4") || mime.contains("m4a") || mime.contains("aac") -> "m4a"
        mime.contains("ogg") || mime.contains("opus") -> "ogg"
        mime.contains("mpeg") || mime.contains("mp3") -> "mp3"
        mime.contains("wav") -> "wav"
        else -> "bin"
    }

    private fun file(c: Context, id: Long, mime: String): File {
        val dir = File(c.cacheDir, "audio")
        dir.mkdirs()
        val f = File(dir, "p$id.${ext(mime)}")
        if (!f.exists() || f.length() == 0L) {
            c.contentResolver.openInputStream(Uri.parse("content://mms/part/$id"))?.use { ins ->
                f.outputStream().use { ins.copyTo(it) }
            } ?: throw Exception("Não foi possível ler o áudio.")
        }
        return f
    }

    fun duration(c: Context, id: Long, mime: String): Int {
        synchronized(cache) { cache[id]?.let { return it } }
        var d = 0
        try {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(file(c, id, mime).absolutePath)
                d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toIntOrNull() ?: 0
            } finally {
                try { r.release() } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {
        }
        synchronized(cache) { cache[id] = d }
        return d
    }

    private fun emit() {
        val p = mp
        val o = JSONObject().put("part", part).put("speed", speed.toDouble())
        if (p == null) {
            o.put("playing", false).put("pos", 0).put("dur", 0)
        } else {
            try {
                o.put("playing", p.isPlaying).put("pos", p.currentPosition).put("dur", p.duration)
            } catch (_: Throwable) {
                o.put("playing", false).put("pos", 0).put("dur", 0)
            }
        }
        Events.emit("audio", o.toString())
    }

    @Synchronized
    fun toggle(c: Context, id: Long, mime: String) {
        val cur = mp
        if (cur != null && part == id) {
            if (cur.isPlaying) cur.pause() else { cur.start(); h.post(tick) }
            emit()
            return
        }
        stopLocked()
        val m = MediaPlayer()
        try {
            m.setAudioAttributes(
                AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .setUsage(AudioAttributes.USAGE_MEDIA).build()
            )
            m.setDataSource(file(c, id, mime).absolutePath)
            m.prepare()
            if (Build.VERSION.SDK_INT >= 23 && speed != 1f) {
                try { m.playbackParams = m.playbackParams.setSpeed(speed) } catch (_: Throwable) {}
            }
            m.setOnCompletionListener {
                try { it.seekTo(0) } catch (_: Throwable) {}
                h.post { emitDone() }
            }
            m.start()
        } catch (e: Throwable) {
            try { m.release() } catch (_: Throwable) {}
            throw Exception("Não foi possível reproduzir este áudio.")
        }
        mp = m
        part = id
        h.post(tick)
        emit()
    }

    private fun emitDone() {
        val o = JSONObject().put("part", part).put("playing", false).put("pos", 0)
            .put("dur", try { mp?.duration ?: 0 } catch (_: Throwable) { 0 }).put("speed", speed.toDouble())
        Events.emit("audio", o.toString())
    }

    @Synchronized
    fun seek(id: Long, ms: Int) {
        val p = mp ?: return
        if (part != id) return
        try { p.seekTo(ms.coerceIn(0, p.duration)) } catch (_: Throwable) {}
        emit()
    }

    @Synchronized
    fun setSpeed(s: Float) {
        speed = s.coerceIn(0.5f, 2f)
        val p = mp
        if (p != null && Build.VERSION.SDK_INT >= 23) {
            try {
                val was = p.isPlaying
                p.playbackParams = p.playbackParams.setSpeed(speed)
                if (!was) p.pause()
            } catch (_: Throwable) {}
        }
        emit()
    }

    private fun stopLocked() {
        val p = mp ?: return
        mp = null
        try { p.stop() } catch (_: Throwable) {}
        try { p.release() } catch (_: Throwable) {}
        val old = part
        part = -1
        Events.emit("audio", JSONObject().put("part", old).put("playing", false).put("pos", 0).put("dur", 0).put("speed", speed.toDouble()).toString())
    }

    @Synchronized
    fun pause() {
        val p = mp ?: return
        try { if (p.isPlaying) p.pause() } catch (_: Throwable) {}
        emit()
    }

    @Synchronized
    fun stop() = stopLocked()
}
