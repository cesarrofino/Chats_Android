package app.chats.sms

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.Telephony
import java.nio.charset.Charset

/** Persistência de MMS no armazenamento de mensagens do Android (apenas a app SMS predefinida pode escrever). */
object MmsStore {
    private const val SMIL = "application/smil"

    fun insertPart(c: Context, mid: Long, ct: String, name: String, cid: String, data: ByteArray, charset: String? = null) {
        val v = ContentValues()
        v.put("mid", mid)
        v.put("ct", ct)
        v.put("name", name)
        v.put("cl", name)
        v.put("cid", cid)
        val isText = ct.startsWith("text/plain") || ct == SMIL
        if (isText) {
            v.put("chset", 106)
            val cs = try { Charset.forName(charset ?: "UTF-8") } catch (e: Exception) { Charsets.UTF_8 }
            v.put("text", String(data, cs))
        }
        val pu = c.contentResolver.insert(Uri.parse("content://mms/$mid/part"), v)
        if (!isText && pu != null) {
            c.contentResolver.openOutputStream(pu)?.use { it.write(data) }
        }
    }

    private fun insertAddr(c: Context, mid: Long, address: String, type: Int) {
        val v = ContentValues()
        v.put("address", address)
        v.put("type", type)
        v.put("charset", 106)
        v.put("msg_id", mid)
        c.contentResolver.insert(Uri.parse("content://mms/$mid/addr"), v)
    }

    /** Cria o MMS de saída (caixa de saída) com todas as partes. Devolve o id. */
    fun insertOutgoing(c: Context, to: List<String>, subject: String?, parts: List<Pdu.Part>, subId: Int): Long {
        val tid = Telephony.Threads.getOrCreateThreadId(c, to.toSet())
        val now = System.currentTimeMillis() / 1000
        val v = ContentValues()
        v.put("thread_id", tid)
        v.put("date", now)
        v.put("msg_box", 4)
        v.put("read", 1)
        v.put("seen", 1)
        v.put("m_type", 128)
        v.put("v", 18)
        if (!subject.isNullOrEmpty()) {
            v.put("sub", subject)
            v.put("sub_cs", 106)
        }
        v.put("ct_t", "application/vnd.wap.multipart.related")
        v.put("m_cls", "personal")
        v.put("pri", 129)
        v.put("rr", 129)
        v.put("d_rpt", 129)
        v.put("exp", 604800)
        v.put("tr_id", "T" + java.lang.Long.toHexString(System.currentTimeMillis()))
        v.put("m_size", parts.sumOf { it.data.size })
        if (subId >= 0) v.put("sub_id", subId)
        val uri = c.contentResolver.insert(Uri.parse("content://mms/outbox"), v)
            ?: throw IllegalStateException("Não foi possível guardar a mensagem. Verifique se o Chats é a aplicação SMS predefinida.")
        val id = ContentUris.parseId(uri)
        for (t in to) insertAddr(c, id, t, 151)
        insertAddr(c, id, "insert-address-token", 137)
        for (p in parts) insertPart(c, id, p.ct, p.name, p.cid, p.data)
        return id
    }

    fun setBox(c: Context, id: Long, box: Int) {
        val v = ContentValues()
        v.put("msg_box", box)
        try { c.contentResolver.update(Uri.parse("content://mms/$id"), v, null, null) } catch (_: Exception) {}
    }

    class Draft(val to: List<String>, val subject: String?, val parts: List<Pdu.Part>, val subId: Int, val thread: Long)

    /** Reconstrói um MMS guardado (para reenviar). */
    fun loadDraft(c: Context, id: Long): Draft {
        var subject: String? = null
        var subId = -1
        var thread = -1L
        c.contentResolver.query(Uri.parse("content://mms/$id"), null, null, null, null)?.use { cur ->
            if (cur.moveToFirst()) {
                cur.getColumnIndex("sub").let { i -> if (i >= 0) subject = cur.getString(i) }
                cur.getColumnIndex("sub_id").let { i -> if (i >= 0) subId = cur.getInt(i) }
                cur.getColumnIndex("thread_id").let { i -> if (i >= 0) thread = cur.getLong(i) }
            }
        }
        val to = ArrayList<String>()
        c.contentResolver.query(Uri.parse("content://mms/$id/addr"), arrayOf("address", "type"), null, null, null)?.use { cur ->
            while (cur.moveToNext()) if (cur.getInt(1) == 151) to.add(cur.getString(0))
        }
        val parts = ArrayList<Pdu.Part>()
        c.contentResolver.query(
            Uri.parse("content://mms/$id/part"), arrayOf("_id", "ct", "name", "cl", "cid", "text"), null, null, null
        )?.use { cur ->
            while (cur.moveToNext()) {
                val pid = cur.getLong(0)
                val ct = cur.getString(1) ?: continue
                if (ct == SMIL) continue
                val name = cur.getString(2) ?: cur.getString(3) ?: "anexo$pid"
                val cid = cur.getString(4) ?: "<$name>"
                val data: ByteArray = if (ct.startsWith("text/plain")) {
                    (cur.getString(5) ?: "").toByteArray(Charsets.UTF_8)
                } else {
                    c.contentResolver.openInputStream(Uri.parse("content://mms/part/$pid"))?.use { it.readBytes() }
                        ?: ByteArray(0)
                }
                parts.add(Pdu.Part(ct, name, data, cid))
            }
        }
        return Draft(to, subject, parts, subId, thread)
    }

    /** Cria a linha de notificação de MMS recebido (ainda por transferir). */
    fun insertNotification(c: Context, n: Pdu.Notif, subId: Int): Long {
        val from = n.from ?: "desconhecido"
        val tid = try { Telephony.Threads.getOrCreateThreadId(c, from) } catch (e: Exception) { 0L }
        val v = ContentValues()
        v.put("thread_id", tid)
        v.put("date", System.currentTimeMillis() / 1000)
        v.put("msg_box", 1)
        v.put("read", 0)
        v.put("seen", 0)
        v.put("m_type", 130)
        v.put("v", 18)
        v.put("ct_l", n.location)
        v.put("m_size", n.size)
        v.put("exp", 604800)
        v.put("tr_id", n.tid)
        v.put("m_cls", "personal")
        v.put("pri", 129)
        if (!n.subject.isNullOrEmpty()) {
            v.put("sub", n.subject)
            v.put("sub_cs", 106)
        }
        if (subId >= 0) v.put("sub_id", subId)
        val uri = c.contentResolver.insert(Uri.parse("content://mms/inbox"), v) ?: return -1
        val id = ContentUris.parseId(uri)
        insertAddr(c, id, from, 137)
        return id
    }

    fun threadOf(c: Context, id: Long): Long {
        c.contentResolver.query(Uri.parse("content://mms/$id"), arrayOf("thread_id"), null, null, null)?.use { cur ->
            if (cur.moveToFirst()) return cur.getLong(0)
        }
        return -1L
    }

    fun location(c: Context, id: Long): String? {
        c.contentResolver.query(Uri.parse("content://mms/$id"), arrayOf("ct_l"), null, null, null)?.use { cur ->
            if (cur.moveToFirst()) return cur.getString(0)
        }
        return null
    }

    fun subIdOf(c: Context, id: Long): Int {
        c.contentResolver.query(Uri.parse("content://mms/$id"), arrayOf("sub_id"), null, null, null)?.use { cur ->
            if (cur.moveToFirst()) return cur.getInt(0)
        }
        return -1
    }

    /** Converte a notificação num MMS completo depois da transferência. */
    fun persistRetrieved(c: Context, id: Long, r: Pdu.Retr) {
        val v = ContentValues()
        v.put("m_type", 132)
        v.put("date", if (r.date > 0) r.date else System.currentTimeMillis() / 1000)
        v.put("ct_t", "application/vnd.wap.multipart.related")
        v.put("read", 0)
        v.put("seen", 0)
        v.put("msg_box", 1)
        v.put("m_size", r.parts.sumOf { it.data.size })
        if (!r.subject.isNullOrEmpty()) {
            v.put("sub", r.subject)
            v.put("sub_cs", 106)
        }
        c.contentResolver.update(Uri.parse("content://mms/$id"), v, null, null)
        for (p in r.parts) {
            val cid = p.cid ?: "<${p.name}>"
            insertPart(c, id, p.ct, p.name, cid, p.data, p.charset)
        }
        Store.setDlFailed(c, id, false)
    }

    fun isDownloaded(c: Context, id: Long): Boolean {
        c.contentResolver.query(Uri.parse("content://mms/$id"), arrayOf("m_type"), null, null, null)?.use { cur ->
            if (cur.moveToFirst()) return cur.getInt(0) != 130
        }
        return false
    }
}
