package app.chats.sms

import android.content.Context
import android.os.Build
import android.os.PowerManager

/** Acende o ecrã quando chega uma mensagem ou um relatório de entrega (ecrã bloqueado / em standby). */
object Wake {
    @Suppress("DEPRECATION")
    fun screen(c: Context, ms: Long = 6000L) {
        if (!Store.bool(c, "wakeScreen", true)) return
        try {
            val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (pm.isInteractive) return // já está ligado
            val flags = PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                PowerManager.ACQUIRE_CAUSES_WAKEUP or
                PowerManager.ON_AFTER_RELEASE
            val wl = pm.newWakeLock(flags, "Chats:wake")
            wl.setReferenceCounted(false)
            wl.acquire(ms) // liberta-se sozinho; o ecrã continua bloqueado, só acende
        } catch (_: Throwable) {
        }
    }
}
