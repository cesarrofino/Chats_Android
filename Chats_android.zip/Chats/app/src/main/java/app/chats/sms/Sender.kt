package app.chats.sms

import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Telephony
import android.telephony.SmsManager
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/** Estado de transferências MMS em curso e tratamento de notificações MMS recebidas. */
object Mms {
    val downloading: MutableSet<Long> = ConcurrentHashMap.newKeySet<Long>()

    fun onNotification(c: Context, data: ByteArray, subId: Int) {
        val n = Pdu.parseNotification(data) ?: return
        val id = MmsStore.insertNotification(c, n, subId)
        if (id < 0) return
        val from = n.from ?: "desconhecido"
        val thread = try { Telephony.Threads.getOrCreateThreadId(c, from) } catch (e: Exception) { 0L }
        if (Notifier.isBlocked(c, from)) {
            Messages.markRead(c, thread, true)
        } else {
            Notifier.incoming(c, thread, from, "Mensagem multimédia" + (if (n.subject.isNullOrEmpty()) "" else ": ${n.subject}"))
        }
        Events.emit("changed", JSONObject().put("thread", thread).toString())
        if (Store.bool(c, "autoDownload", true)) {
            try { Sender.downloadMms(c, id) } catch (_: Exception) {}
        }
    }
}

object Sender {
    const val ACT_SENT = "app.chats.sms.SMS_SENT"
    const val ACT_DELIVERED = "app.chats.sms.SMS_DELIVERED"
    const val ACT_MMS_SENT = "app.chats.sms.MMS_SENT"
    const val ACT_MMS_DL = "app.chats.sms.MMS_DOWNLOADED"

    fun isDefault(c: Context): Boolean = Telephony.Sms.getDefaultSmsPackage(c) == c.packageName

    @Suppress("DEPRECATION")
    fun sm(c: Context, subId: Int): SmsManager {
        return if (Build.VERSION.SDK_INT >= 31) {
            val base = c.getSystemService(SmsManager::class.java)
            if (subId >= 0) base.createForSubscriptionId(subId) else base
        } else {
            if (subId >= 0) SmsManager.getSmsManagerForSubscriptionId(subId) else SmsManager.getDefault()
        }
    }

    private fun pi(c: Context, action: String, data: Uri, extras: Bundle? = null): PendingIntent {
        val i = Intent(c, StatusReceiver::class.java).setAction(action).setData(data)
        if (extras != null) i.putExtras(extras)
        // Mutável: o sistema acrescenta dados (PDU do relatório de entrega, resultado MMS).
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        return PendingIntent.getBroadcast(c, 0, i, flags)
    }

    // ------------------------------------------------------------------ SMS
    fun sendSms(c: Context, addrs: List<String>, body: String, subId: Int, report: Boolean): JSONObject {
        val ids = JSONArray()
        var thread = -1L
        for (raw in addrs) {
            val addr = raw.trim()
            if (addr.isEmpty()) continue
            val v = ContentValues()
            v.put(Telephony.Sms.ADDRESS, addr)
            v.put(Telephony.Sms.BODY, body)
            v.put(Telephony.Sms.DATE, System.currentTimeMillis())
            v.put(Telephony.Sms.READ, 1)
            v.put(Telephony.Sms.SEEN, 1)
            v.put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_OUTBOX)
            v.put(Telephony.Sms.STATUS, if (report) Telephony.Sms.STATUS_PENDING else Telephony.Sms.STATUS_NONE)
            if (subId >= 0) v.put(Telephony.Sms.SUBSCRIPTION_ID, subId)
            val uri = c.contentResolver.insert(Telephony.Sms.Outbox.CONTENT_URI, v)
                ?: throw IllegalStateException("Não foi possível guardar a mensagem. O Chats tem de ser a aplicação SMS predefinida.")
            ids.put(android.content.ContentUris.parseId(uri))
            // 1.º: entrega ao rádio já (é o que o utilizador espera). 2.º: só depois consulta o thread.
            dispatchSms(c, uri, addr, body, subId, report)
            c.contentResolver.query(uri, arrayOf("thread_id"), null, null, null)?.use {
                if (it.moveToFirst()) thread = it.getLong(0)
            }
        }
        return JSONObject().put("ids", ids).put("thread", thread)
    }

    fun dispatchSms(c: Context, uri: Uri, addr: String, body: String, subId: Int, report: Boolean) {
        try {
            val m = sm(c, subId)
            val parts = m.divideMessage(body)
            val sent = pi(c, ACT_SENT, uri)
            val del = if (report) pi(c, ACT_DELIVERED, uri) else null
            if (parts.size <= 1) {
                m.sendTextMessage(addr, null, body, sent, del)
            } else {
                val sl = ArrayList<PendingIntent>()
                val dl = ArrayList<PendingIntent?>()
                for (i in parts.indices) {
                    sl.add(sent)
                    dl.add(if (i == parts.size - 1) del else null)
                }
                m.sendMultipartTextMessage(addr, null, parts, sl, dl)
            }
        } catch (e: Exception) {
            val v = ContentValues()
            v.put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_FAILED)
            try { c.contentResolver.update(uri, v, null, null) } catch (_: Exception) {}
            Events.emit("changed")
            throw Exception(e.message ?: "Falha ao enviar o SMS.")
        }
    }

    fun retrySms(c: Context, id: Long, report: Boolean) {
        val uri = Uri.parse("content://sms/$id")
        var addr = ""
        var body = ""
        var sub = -1
        c.contentResolver.query(uri, arrayOf("address", "body", "sub_id"), null, null, null)?.use {
            if (it.moveToFirst()) {
                addr = it.getString(0) ?: ""
                body = it.getString(1) ?: ""
                sub = it.getInt(2)
            }
        }
        if (addr.isEmpty()) throw Exception("Mensagem não encontrada.")
        val v = ContentValues()
        v.put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_OUTBOX)
        v.put(Telephony.Sms.DATE, System.currentTimeMillis())
        v.put(Telephony.Sms.STATUS, if (report) Telephony.Sms.STATUS_PENDING else Telephony.Sms.STATUS_NONE)
        c.contentResolver.update(uri, v, null, null)
        dispatchSms(c, uri, addr, body, sub, report)
    }

    // ------------------------------------------------------------------ MMS
    private fun maxMms(m: SmsManager): Int {
        val v = try { m.carrierConfigValues.getInt("maxMessageSize", 0) } catch (e: Throwable) { 0 }
        return if (v in 50_000..20_000_000) v else 300 * 1024
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace("\"", "&quot;")

    private fun smil(parts: List<Pdu.Part>): String {
        val sb = StringBuilder(
            "<smil><head><layout><root-layout width=\"320\" height=\"480\"/>" +
                "<region id=\"Image\" fit=\"meet\" top=\"0\" left=\"0\" height=\"80%\" width=\"100%\"/>" +
                "<region id=\"Text\" fit=\"meet\" top=\"80%\" left=\"0\" height=\"20%\" width=\"100%\"/>" +
                "</layout></head><body>"
        )
        val media = parts.filter { !it.ct.startsWith("text/") }
        val texts = parts.filter { it.ct.startsWith("text/") }
        fun textTags() = texts.forEach { sb.append("<text src=\"${esc(it.name)}\" region=\"Text\"/>") }
        if (media.isEmpty()) {
            sb.append("<par dur=\"5000ms\">"); textTags(); sb.append("</par>")
        } else {
            media.forEachIndexed { i, m ->
                sb.append("<par dur=\"5000ms\">")
                val tag = when {
                    m.ct.startsWith("image/") -> "img"
                    m.ct.startsWith("video/") -> "video"
                    m.ct.startsWith("audio/") -> "audio"
                    else -> "ref"
                }
                val region = if (tag == "audio") "" else " region=\"Image\""
                sb.append("<$tag src=\"${esc(m.name)}\"$region/>")
                if (i == 0) textTags()
                sb.append("</par>")
            }
        }
        sb.append("</body></smil>")
        return sb.toString()
    }

    fun sendMms(c: Context, addrs: List<String>, subject: String?, body: String, attIds: List<String>, subId: Int): JSONObject {
        val to = addrs.map { it.trim() }.filter { it.isNotEmpty() }
        if (to.isEmpty()) throw Exception("Indique pelo menos um destinatário.")
        val m = sm(c, subId)
        var budget = maxMms(m) - 4000 - body.toByteArray().size - (subject?.length ?: 0) * 3
        if (budget < 20_000) throw Exception("O texto é demasiado longo para um MMS.")
        val atts = attIds.mapNotNull { Media.atts[it] }
        val blobs = arrayOfNulls<Media.Blob>(atts.size)
        val isImg = { a: Media.Att -> a.mime.startsWith("image/") && a.mime != "image/gif" }
        // 1.º ficheiros que não são imagens; 2.º imagens repartem o que sobra
        atts.forEachIndexed { i, a ->
            if (!isImg(a)) {
                val b = Media.blob(c, a, budget)
                budget -= b.data.size
                blobs[i] = b
            }
        }
        var imgLeft = atts.count { isImg(it) }
        atts.forEachIndexed { i, a ->
            if (isImg(a)) {
                val b = Media.blob(c, a, (budget / imgLeft).coerceAtLeast(10_000))
                budget -= b.data.size
                imgLeft--
                blobs[i] = b
            }
        }
        val parts = ArrayList<Pdu.Part>()
        val used = HashSet<String>()
        blobs.forEachIndexed { i, b ->
            if (b != null) {
                var n = b.name
                if (!used.add(n)) { n = "${i}_$n"; used.add(n) }
                parts.add(Pdu.Part(b.ct, n, b.data))
            }
        }
        if (body.isNotEmpty()) parts.add(Pdu.Part("text/plain", "text_0.txt", body.toByteArray(Charsets.UTF_8)))
        if (parts.isEmpty()) throw Exception("A mensagem está vazia.")
        val id = MmsStore.insertOutgoing(c, to, subject, parts, subId)
        dispatchMms(c, id, MmsStore.Draft(to, subject, parts, subId, -1))
        val thread = MmsStore.threadOf(c, id)
        return JSONObject().put("id", id).put("thread", thread)
    }

    private fun grant(c: Context, uri: Uri) {
        for (pkg in arrayOf("com.android.phone", "com.android.mms.service", "com.google.android.apps.messaging")) {
            try {
                c.grantUriPermission(
                    pkg, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {
            }
        }
    }

    fun dispatchMms(c: Context, id: Long, d: MmsStore.Draft) {
        try {
            val bytes = Pdu.build(Pdu.SendReq(d.to, d.subject, d.parts), smil(d.parts))
            val dir = File(c.cacheDir, "mms")
            dir.mkdirs()
            val f = File(dir, "send_$id.pdu")
            f.writeBytes(bytes)
            val uri = FileProvider.getUriForFile(c, c.packageName + ".files", f)
            grant(c, uri)
            val b = Bundle()
            b.putString("file", f.absolutePath)
            val p = pi(c, ACT_MMS_SENT, Uri.parse("content://mms/$id"), b)
            sm(c, d.subId).sendMultimediaMessage(c, uri, null, null, p)
        } catch (e: Exception) {
            MmsStore.setBox(c, id, 5)
            Events.emit("changed")
            throw Exception(e.message ?: "Falha ao enviar o MMS.")
        }
    }

    fun retryMms(c: Context, id: Long) {
        MmsStore.setBox(c, id, 4)
        dispatchMms(c, id, MmsStore.loadDraft(c, id))
    }

    fun downloadMms(c: Context, id: Long) {
        val loc = MmsStore.location(c, id)
            ?: throw Exception("Sem endereço de transferência. A mensagem pode ter expirado.")
        Mms.downloading.add(id)
        Store.setDlFailed(c, id, false)
        try {
            val dir = File(c.cacheDir, "mms")
            dir.mkdirs()
            val f = File(dir, "dl_$id.pdu")
            f.writeBytes(ByteArray(0))
            val uri = FileProvider.getUriForFile(c, c.packageName + ".files", f)
            grant(c, uri)
            val b = Bundle()
            b.putString("file", f.absolutePath)
            val p = pi(c, ACT_MMS_DL, Uri.parse("content://mms/$id"), b)
            sm(c, MmsStore.subIdOf(c, id)).downloadMultimediaMessage(c, loc, uri, null, p)
        } catch (e: Exception) {
            Mms.downloading.remove(id)
            Store.setDlFailed(c, id, true)
            Events.emit("changed")
            throw Exception(e.message ?: "Falha ao transferir o MMS.")
        }
        Events.emit("changed")
    }
}
