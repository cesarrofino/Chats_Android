package app.chats.sms

import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ExecutionException
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/**
 * Tradução feita no próprio aparelho (ML Kit). O texto das mensagens nunca sai do telemóvel:
 * só a transferência dos pacotes de idioma (uma vez por idioma) usa a internet.
 * Chamar sempre fora da thread principal (usa Tasks.await).
 */
object Translator {
    private const val MAX_CHARS = 5000

    private val NAMES = linkedMapOf(
        "pt" to "Português", "en" to "English", "es" to "Español", "fr" to "Français",
        "de" to "Deutsch", "it" to "Italiano", "nl" to "Nederlands", "ru" to "Русский",
        "uk" to "Українська", "pl" to "Polski", "tr" to "Türkçe", "ar" to "العربية",
        "hi" to "हिन्दी", "zh" to "中文", "ja" to "日本語", "ko" to "한국어"
    )

    fun languages(): JSONArray {
        val a = JSONArray()
        for ((code, name) in NAMES) {
            if (TranslateLanguage.fromLanguageTag(code) != null) a.put(JSONObject().put("code", code).put("name", name))
        }
        return a
    }

    private fun downloaded(): Set<String> {
        val models = Tasks.await(
            RemoteModelManager.getInstance().getDownloadedModels(TranslateRemoteModel::class.java),
            20, TimeUnit.SECONDS
        )
        return models.map { it.language }.toSet()
    }

    fun models(): JSONArray {
        val a = JSONArray()
        downloaded().filter { it != TranslateLanguage.ENGLISH }.sorted().forEach { a.put(JSONObject().put("code", it)) }
        return a
    }

    fun delete(code: String) {
        val tag = TranslateLanguage.fromLanguageTag(code) ?: throw Exception("Idioma inválido.")
        try {
            Tasks.await(RemoteModelManager.getInstance().deleteDownloadedModel(TranslateRemoteModel.Builder(tag).build()), 30, TimeUnit.SECONDS)
        } catch (e: Exception) {
            throw Exception("Não foi possível eliminar o idioma.")
        }
    }

    private fun detect(text: String): String {
        val client = LanguageIdentification.getClient()
        try {
            val tag = Tasks.await(client.identifyLanguage(text), 15, TimeUnit.SECONDS)
            return TranslateLanguage.fromLanguageTag(tag) ?: ""
        } catch (e: Exception) {
            return ""
        } finally {
            client.close()
        }
    }

    /**
     * Devolve {text, from, to}; {same:true} se o texto já estiver no idioma de destino;
     * ou {needs:[...]} se faltarem pacotes de idioma e [download] for falso (a interface pergunta ao utilizador).
     */
    fun translate(text: String, from: String?, to: String, download: Boolean): JSONObject {
        val t = text.trim()
        if (t.isEmpty()) throw Exception("Nada para traduzir.")
        if (t.length > MAX_CHARS) throw Exception("O texto é demasiado longo para traduzir.")
        val target = TranslateLanguage.fromLanguageTag(to) ?: throw Exception("Idioma de destino não suportado.")
        val source = (from?.takeIf { it.isNotEmpty() }?.let { TranslateLanguage.fromLanguageTag(it) } ?: detect(t))
        if (source.isEmpty()) throw Exception("Não foi possível identificar o idioma do texto.")
        if (source == target) return JSONObject().put("same", true).put("from", source).put("to", target)

        if (!download) {
            val have = try { downloaded() } catch (e: Exception) { emptySet() }
            val need = listOf(source, target).filter { it != TranslateLanguage.ENGLISH && it !in have }
            if (need.isNotEmpty()) return JSONObject().put("needs", JSONArray(need)).put("from", source).put("to", target)
        }

        val translator = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(target).build()
        )
        try {
            Tasks.await(translator.downloadModelIfNeeded(DownloadConditions.Builder().build()), 5, TimeUnit.MINUTES)
            val out = Tasks.await(translator.translate(t), 60, TimeUnit.SECONDS)
            return JSONObject().put("text", out).put("from", source).put("to", target)
        } catch (e: ExecutionException) {
            throw Exception("Não foi possível traduzir. A transferência do idioma precisa de internet.")
        } catch (e: TimeoutException) {
            throw Exception("A tradução demorou demasiado. Tente novamente.")
        } finally {
            translator.close()
        }
    }
}
