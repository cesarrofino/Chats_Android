package app.chats.sms

import android.app.Activity
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.provider.Telephony
import android.telephony.SmsMessage
import android.telephony.SubscriptionManager
import androidx.core.app.RemoteInput
import org.json.JSONObject
import java.io.File

/** Receção de SMS (entregue apenas à aplicação SMS predefinida). */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val sub = intent.getIntExtra("subscription", -1)
        val pr = goAsync()
        val app = context.applicationContext
        Thread {
            try {
                val byAddr = LinkedHashMap<String, StringBuilder>()
                var sent = System.currentTimeMillis()
                for (m in msgs) {
                    val a = m.displayOriginatingAddress ?: m.originatingAddress ?: "desconhecido"
                    byAddr.getOrPut(a) { StringBuilder() }.append(m.displayMessageBody ?: "")
                    sent = m.timestampMillis
                }
                for ((addr, sb) in byAddr) {
                    val blocked = Notifier.isBlocked(app, addr)
                    val v = ContentValues()
                    v.put(Telephony.Sms.ADDRESS, addr)
                    v.put(Telephony.Sms.BODY, sb.toString())
                    v.put(Telephony.Sms.DATE, System.currentTimeMillis())
                    v.put(Telephony.Sms.DATE_SENT, sent)
                    v.put(Telephony.Sms.READ, if (blocked) 1 else 0)
                    v.put(Telephony.Sms.SEEN, if (blocked) 1 else 0)
                    if (sub >= 0) v.put(Telephony.Sms.SUBSCRIPTION_ID, sub)
                    val uri = app.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, v)
                    var thread = -1L
                    if (uri != null) {
                        app.contentResolver.query(uri, arrayOf("thread_id"), null, null, null)?.use {
                            if (it.moveToFirst()) thread = it.getLong(0)
                        }
                    }
                    if (!blocked && thread >= 0) Notifier.incoming(app, thread, addr, sb.toString())
                    Events.emit("changed", JSONObject().put("thread", thread).toString())
                }
            } catch (_: Exception) {
            } finally {
                pr.finish()
            }
        }.start()
    }
}

/** Receção de notificações de MMS (WAP push). */
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.WAP_PUSH_DELIVER_ACTION) return
        val data = intent.getByteArrayExtra("data") ?: return
        val sub = intent.getIntExtra("subscription", intent.getIntExtra("android.telephony.extra.SUBSCRIPTION_INDEX", -1))
        val pr = goAsync()
        val app = context.applicationContext
        Thread {
            try {
                Mms.onNotification(app, data, sub)
            } catch (_: Exception) {
            } finally {
                pr.finish()
            }
        }.start()
    }
}

/** Resposta rápida a chamadas ("Rejeitar com mensagem"). */
class RespondViaMessageService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ctx = applicationContext
        Thread {
            try {
                if (intent != null && intent.action == "android.intent.action.RESPOND_VIA_MESSAGE") {
                    val to = intent.data?.schemeSpecificPart?.substringBefore("?")
                    val text = intent.getStringExtra(Intent.EXTRA_TEXT)
                    if (!to.isNullOrBlank() && !text.isNullOrBlank() && Sender.isDefault(ctx)) {
                        Sender.sendSms(ctx, listOf(to), text, SubscriptionManager.getDefaultSmsSubscriptionId(), false)
                    }
                }
            } catch (_: Exception) {
            } finally {
                stopSelf(startId)
            }
        }.start()
        return START_NOT_STICKY
    }
}

/** Resultados do sistema: enviado, entregue, MMS enviado, MMS transferido. */
class StatusReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val data = intent.data ?: return
        val action = intent.action ?: return
        val code = resultCode
        val extras = intent.extras
        val pdu = extras?.getByteArray("pdu")
        val format = extras?.getString("format")
        val file = extras?.getString("file")
        val pr = goAsync()
        val app = context.applicationContext
        Thread {
            try {
                when (action) {
                    Sender.ACT_SENT -> onSent(app, data, code, extras?.getInt("errorCode", 0) ?: 0)
                    Sender.ACT_DELIVERED -> onDelivered(app, data, pdu, format)
                    Sender.ACT_MMS_SENT -> onMmsSent(app, data, code, file)
                    Sender.ACT_MMS_DL -> onMmsDownloaded(app, data, code, file)
                }
            } catch (_: Exception) {
            } finally {
                pr.finish()
            }
        }.start()
    }

    private fun rowInfo(c: Context, uri: android.net.Uri): Triple<Long, String, Long> {
        var thread = 0L
        var addr = ""
        val id = try { ContentUris.parseId(uri) } catch (e: Exception) { 0L }
        try {
            c.contentResolver.query(uri, arrayOf("thread_id", "address"), null, null, null)?.use {
                if (it.moveToFirst()) {
                    thread = it.getLong(0)
                    addr = it.getString(1) ?: ""
                }
            }
        } catch (_: Exception) {
        }
        return Triple(thread, addr, id)
    }

    /** Normaliza para content://sms/<id> (o URI devolvido pelo insert pode vir com outro formato). */
    private fun smsUri(uri: android.net.Uri): android.net.Uri {
        val id = try { ContentUris.parseId(uri) } catch (e: Exception) { return uri }
        return ContentUris.withAppendedId(Telephony.Sms.CONTENT_URI, id)
    }

    private fun upd(c: Context, uri: android.net.Uri, v: ContentValues, where: String?): Int =
        try { c.contentResolver.update(uri, v, where, null) } catch (_: Exception) { 0 }

    private fun onSent(c: Context, raw: android.net.Uri, code: Int, err: Int) {
        val uri = smsUri(raw)
        val v = ContentValues()
        if (code == Activity.RESULT_OK) {
            v.put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_SENT)
            // 1.º caixa de saída/fila; 2.º qualquer estado que não seja recebida/falhada (nunca fica preso em "A enviar")
            if (upd(c, uri, v, "type IN (4,6)") == 0) upd(c, uri, v, "type NOT IN (1,5)")
        } else {
            v.put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_FAILED)
            v.put(Telephony.Sms.ERROR_CODE, if (err != 0) err else code)
            upd(c, uri, v, null)
            val (thread, addr, id) = rowInfo(c, uri)
            Notifier.failed(c, thread, addr, id)
        }
        Events.emit("changed")
    }

    private fun onDelivered(c: Context, raw: android.net.Uri, pdu: ByteArray?, format: String?) {
        val uri = smsUri(raw)
        var status = -1
        if (pdu != null) {
            try {
                status = SmsMessage.createFromPdu(pdu, format).status
            } catch (_: Exception) {
            }
        }
        // Só confirma "entregue" quando a rede o indica (TP-Status 0). 0x20–0x3F: ainda a tentar; >=0x40: falhou.
        val v = ContentValues()
        when {
            status == 0 -> v.put(Telephony.Sms.STATUS, Telephony.Sms.STATUS_COMPLETE)
            status in 0x20..0x3F -> v.put(Telephony.Sms.STATUS, Telephony.Sms.STATUS_PENDING)
            status >= 0x40 -> v.put(Telephony.Sms.STATUS, Telephony.Sms.STATUS_FAILED)
            else -> return
        }
        c.contentResolver.update(uri, v, null, null)
        if (status >= 0 && status < 0x40) {
            // Se o relatório chegou, a mensagem foi enviada: tira-a de "A enviar" mesmo que o aviso de envio se tenha perdido.
            val t = ContentValues()
            t.put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_SENT)
            upd(c, uri, t, "type IN (4,6)")
        }
        if (status == 0) {
            val (thread, addr, id) = rowInfo(c, uri)
            Notifier.delivered(c, thread, addr, id)
        }
        Events.emit("changed")
    }

    private fun onMmsSent(c: Context, uri: android.net.Uri, code: Int, file: String?) {
        val id = ContentUris.parseId(uri)
        if (code == Activity.RESULT_OK) {
            MmsStore.setBox(c, id, 2)
        } else {
            MmsStore.setBox(c, id, 5)
            val thread = MmsStore.threadOf(c, id)
            Notifier.failed(c, thread, "", id)
        }
        if (file != null) File(file).delete()
        Events.emit("changed")
    }

    private fun onMmsDownloaded(c: Context, uri: android.net.Uri, code: Int, file: String?) {
        val id = ContentUris.parseId(uri)
        Mms.downloading.remove(id)
        var ok = false
        if (code == Activity.RESULT_OK && file != null) {
            try {
                val r = Pdu.parseRetrieve(File(file).readBytes())
                if (r != null) {
                    MmsStore.persistRetrieved(c, id, r)
                    ok = true
                }
            } catch (_: Exception) {
            }
        }
        if (!ok) Store.setDlFailed(c, id, true)
        if (file != null) File(file).delete()
        Events.emit("changed")
    }
}

/** Ações a partir das notificações: responder, marcar como lida, copiar código. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val thread = intent.getLongExtra("thread", -1L)
        val addr = intent.getStringExtra("addr") ?: ""
        val action = intent.action ?: return
        val pr = goAsync()
        val app = context.applicationContext
        val replyText = RemoteInput.getResultsFromIntent(intent)?.getCharSequence("reply_text")?.toString()
        val extra = intent.getStringExtra("extra")
        Thread {
            try {
                when (action) {
                    "read" -> {
                        Messages.markRead(app, thread, true)
                        Notifier.cancel(app, thread)
                    }
                    "copy" -> {
                        val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("código", extra ?: ""))
                        Messages.markRead(app, thread, true)
                        Notifier.cancel(app, thread)
                    }
                    "reply" -> {
                        if (!replyText.isNullOrBlank() && addr.isNotEmpty() && Sender.isDefault(app)) {
                            Sender.sendSms(
                                app, listOf(addr), replyText,
                                SubscriptionManager.getDefaultSmsSubscriptionId(),
                                Store.bool(app, "deliveryReports", true)
                            )
                            Messages.markRead(app, thread, true)
                        }
                        Notifier.cancel(app, thread)
                    }
                }
                Notifier.badge(app)
                Events.emit("changed")
            } catch (_: Exception) {
            } finally {
                pr.finish()
            }
        }.start()
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", 0)
        val pr = goAsync()
        val app = context.applicationContext
        Thread {
            try {
                Scheduler.fire(app, id)
            } catch (_: Exception) {
            } finally {
                pr.finish()
            }
        }.start()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pr = goAsync()
        val app = context.applicationContext
        Thread {
            try {
                Scheduler.rescheduleAll(app)
                Trash.purge(app)
            } catch (_: Exception) {
            } finally {
                pr.finish()
            }
        }.start()
    }
}
