package app.chats.sms

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.RemoteViews

/** Widget "Conversas": cabeçalho com não lidas e botão "+", e a lista das conversas mais recentes. */
class ChatsWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        // O contador de não lidas consulta o fornecedor de SMS: fora da thread principal.
        val pr = goAsync()
        val app = context.applicationContext
        Thread {
            try {
                for (id in ids) update(app, manager, id)
            } catch (_: Throwable) {
            } finally {
                pr.finish()
            }
        }.start()
    }

    companion object {
        private val NEW_TASK = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP

        private fun flags(mutable: Boolean): Int {
            var f = PendingIntent.FLAG_UPDATE_CURRENT
            if (mutable) { if (Build.VERSION.SDK_INT >= 31) f = f or PendingIntent.FLAG_MUTABLE }
            else f = f or PendingIntent.FLAG_IMMUTABLE
            return f
        }

        fun update(c: Context, m: AppWidgetManager, id: Int) {
            val rv = RemoteViews(c.packageName, R.layout.widget_chats)

            val svc = Intent(c, WidgetService::class.java).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            svc.data = Uri.parse(svc.toUri(Intent.URI_INTENT_SCHEME))
            rv.setRemoteAdapter(R.id.w_list, svc)
            rv.setEmptyView(R.id.w_list, R.id.w_empty)

            // Cada linha preenche o extra "thread" neste modelo.
            val tpl = Intent(c, MainActivity::class.java).setAction(Intent.ACTION_VIEW).addFlags(NEW_TASK)
            rv.setPendingIntentTemplate(R.id.w_list, PendingIntent.getActivity(c, 0, tpl, flags(true)))

            val nw = Intent(c, MainActivity::class.java).setAction(Widgets.ACTION_NEW).addFlags(NEW_TASK)
            rv.setOnClickPendingIntent(R.id.w_new, PendingIntent.getActivity(c, 1, nw, flags(false)))

            val open = Intent(c, MainActivity::class.java).setAction(Intent.ACTION_MAIN).addFlags(NEW_TASK)
            rv.setOnClickPendingIntent(R.id.w_head, PendingIntent.getActivity(c, 2, open, flags(false)))

            Widgets.header(c, rv)
            m.updateAppWidget(id, rv)
            m.notifyAppWidgetViewDataChanged(id, R.id.w_list)
        }
    }
}
