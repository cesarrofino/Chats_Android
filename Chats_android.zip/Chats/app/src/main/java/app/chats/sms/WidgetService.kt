package app.chats.sms

import android.content.Context
import android.content.Intent
import android.text.format.DateUtils
import android.view.View
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Fornece as linhas (conversas recentes) da lista do widget. */
class WidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = Factory(applicationContext)

    private class Factory(private val c: Context) : RemoteViewsFactory {
        @Volatile private var items = JSONArray()

        override fun onCreate() {}

        override fun onDataSetChanged() {
            items = try {
                if (Widgets.canRead(c)) Messages.threads(c, 15) else JSONArray()
            } catch (_: Throwable) {
                JSONArray()
            }
        }

        override fun onDestroy() { items = JSONArray() }
        override fun getCount() = items.length()
        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 1
        override fun hasStableIds() = true
        override fun getItemId(position: Int): Long = items.optJSONObject(position)?.optLong("id", position.toLong()) ?: position.toLong()

        override fun getViewAt(position: Int): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.widget_item)
            val t = items.optJSONObject(position) ?: return rv
            val name = t.optString("name").ifBlank { "Chats" }
            val unread = t.optInt("unread")
            val seed = t.optJSONArray("addrs")?.optString(0)?.ifEmpty { null } ?: name

            rv.setTextViewText(R.id.wi_initial, Widgets.initial(name))
            rv.setInt(R.id.wi_circle, "setColorFilter", Widgets.color(seed))
            rv.setTextViewText(R.id.wi_name, name)

            var snippet = t.optString("snippet").replace('\n', ' ')
            if (t.optBoolean("error")) snippet = "\u26A0 $snippet"
            rv.setTextViewText(R.id.wi_snippet, snippet)

            rv.setTextViewText(R.id.wi_time, time(t.optLong("date")))
            rv.setTextColor(R.id.wi_time, c.getColor(if (unread > 0) R.color.w_acc else R.color.w_mute))

            if (unread > 0) {
                rv.setTextViewText(R.id.wi_count, if (unread > 99) "99+" else unread.toString())
                rv.setViewVisibility(R.id.wi_count, View.VISIBLE)
            } else {
                rv.setViewVisibility(R.id.wi_count, View.GONE)
            }

            rv.setOnClickFillInIntent(R.id.wi_root, Intent().putExtra("thread", t.optLong("id")))
            return rv
        }

        private fun time(ms: Long): String {
            if (ms <= 0L) return ""
            return if (DateUtils.isToday(ms)) android.text.format.DateFormat.getTimeFormat(c).format(Date(ms))
            else SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(ms))
        }
    }
}
