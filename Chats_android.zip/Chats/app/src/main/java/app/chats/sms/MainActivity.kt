package app.chats.sms

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    lateinit var web: WebView
    private lateinit var bridge: Bridge

    /** O splash fica até a interface estar desenhada (ou 2,5 s no máximo), para não aparecer ecrã branco. */
    @Volatile private var uiReady = false
    fun markReady() { uiReady = true }

    private var pickCb: ((Uri?) -> Unit)? = null
    private var resultCb: ((ActivityResult) -> Unit)? = null
    private var permCb: ((Map<String, Boolean>) -> Unit)? = null

    private val pickLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val cb = pickCb
        pickCb = null
        cb?.invoke(uri)
    }
    private val resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = resultCb
        resultCb = null
        cb?.invoke(r)
    }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { m ->
        val cb = permCb
        permCb = null
        cb?.invoke(m)
    }

    fun pick(mime: String, cb: (Uri?) -> Unit) {
        runOnUiThread {
            pickCb = cb
            try {
                pickLauncher.launch(mime)
            } catch (e: Exception) {
                pickCb = null
                cb(null)
            }
        }
    }

    fun startForResult(i: Intent, fallback: Intent? = null, cb: (ActivityResult) -> Unit) {
        runOnUiThread {
            resultCb = cb
            try {
                resultLauncher.launch(i)
            } catch (e: Exception) {
                DefaultSms.log("startForResult falhou (${e.javaClass.simpleName}: ${e.message}); alternativa=${fallback?.action}")
                try {
                    if (fallback == null) throw e
                    resultLauncher.launch(fallback)
                } catch (e2: Exception) {
                    resultCb = null
                    cb(ActivityResult(Activity.RESULT_CANCELED, null))
                }
            }
        }
    }

    fun askPerms(perms: Array<String>, cb: (Map<String, Boolean>) -> Unit) {
        runOnUiThread {
            permCb = cb
            permLauncher.launch(perms)
        }
    }

    fun setBars(dark: Boolean, color: Int) {
        runOnUiThread {
            window.statusBarColor = color
            window.navigationBarColor = color
            val c = WindowCompat.getInsetsController(window, window.decorView)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        splash.setKeepOnScreenCondition { !uiReady }
        super.onCreate(savedInstanceState)
        window.decorView.postDelayed({ uiReady = true }, 2500)
        web = WebView(this)
        web.setBackgroundColor(getColor(R.color.splash_bg))
        setContentView(web)
        // Android 15+/One UI 9 podem desenhar por baixo das barras do sistema: reservamos esse espaço
        // (barra de estado, navegação, câmara e teclado) para que as setas e botões fiquem tocáveis.
        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }
        bridge = Bridge(this)
        // Aquece os contactos enquanto a WebView arranca: a lista atualiza-se mais depressa.
        val app = applicationContext
        Thread { try { Contacts.warm(app) } catch (_: Throwable) {} }.start()
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false          // os recursos locais vêm de file:///android_asset
            allowContentAccess = false
            blockNetworkLoads = true         // a interface é 100 % local
            setSupportZoom(false)
            builtInZoomControls = false
            textZoom = 100
            mediaPlaybackRequiresUserGesture = false
        }
        web.overScrollMode = android.view.View.OVER_SCROLL_NEVER
        web.addJavascriptInterface(bridge, "ChatsNative")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url.toString()
                if (u.startsWith("file:///android_asset/")) return false
                bridge.openExternal(u)
                return true
            }
        }
        Events.sink = { n, d ->
            runOnUiThread {
                web.evaluateJavascript(
                    "window.__ev&&window.__ev(${JSONObject.quote(n)},${JSONObject.quote(d)})", null
                )
            }
        }
        handleIntent(intent, false)
        DefaultSms.logState(app, "onCreate")
        Thread { try { DefaultSms.checkComponents(app) } catch (_: Throwable) {} }.start()
        lastDefault = Sender.isDefault(app)
        web.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.__back?window.__back():false") { r ->
                    if (r != "true") moveTaskToBack(true)
                }
            }
        })
    }

    private fun handleIntent(i: Intent?, live: Boolean) {
        if (i == null) return
        val o = JSONObject()
        val t = i.getLongExtra("thread", -1L)
        if (t >= 0) o.put("thread", t)
        val d = i.data
        val sch = d?.scheme
        if (d != null && (sch == "sms" || sch == "smsto" || sch == "mms" || sch == "mmsto")) {
            val ssp = d.schemeSpecificPart ?: ""
            val addr = ssp.substringBefore('?').trim()
            if (addr.isNotEmpty()) o.put("address", Uri.decode(addr))
            val body = i.getStringExtra("sms_body")
                ?: ssp.substringAfter('?', "").split("&").firstOrNull { it.startsWith("body=") }
                    ?.substring(5)?.let { Uri.decode(it) }
            if (!body.isNullOrEmpty()) o.put("body", body)
        }
        if (i.action == Intent.ACTION_SEND && i.type == "text/plain") {
            i.getStringExtra(Intent.EXTRA_TEXT)?.let { o.put("share", it.take(20_000)) }
            // Partilha direta: o atalho "t<id>" escolhido no menu Partilhar abre essa conversa com o texto.
            i.getStringExtra(Intent.EXTRA_SHORTCUT_ID)?.takeIf { it.startsWith("t") }
                ?.substring(1)?.toLongOrNull()?.let { o.put("thread", it) }
        }
        if (i.action == Widgets.ACTION_NEW) o.put("new", true)
        if (o.length() > 0) {
            if (live) Events.emit("open", o.toString()) else Events.pending = o
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent, true)
    }

    // Estado da aplicação SMS predefinida visto pela última vez; serve para detetar mudanças tardias.
    @Volatile var lastDefault = false
    @Volatile private var visible = false
    private val mainH = android.os.Handler(android.os.Looper.getMainLooper())
    private val recheckDefault = Runnable { checkDefaultChange("onResume+atraso") }
    // Enquanto a app está visível e ainda não é a predefinida, volta a ler a cada 3 s (o One UI 8.5 pode
    // demorar mais de 15 s a propagar a escolha feita nas Definições). Pára sozinho ao ficar predefinida.
    private val pollDefault = object : Runnable {
        override fun run() {
            if (!visible) return
            checkDefaultChange("poll")
            if (!lastDefault) mainH.postDelayed(this, 3000)
        }
    }

    // O sistema avisa quando a aplicação SMS predefinida muda: relê logo, sem esperar pelos atrasos.
    private val defaultObserver = object : android.database.ContentObserver(mainH) {
        override fun onChange(selfChange: Boolean) { checkDefaultChange("observador") }
    }
    private fun watchDefault(on: Boolean) {
        try {
            if (on) contentResolver.registerContentObserver(
                android.provider.Settings.Secure.getUriFor(DefaultSms.SECURE_KEY), false, defaultObserver
            ) else contentResolver.unregisterContentObserver(defaultObserver)
        } catch (_: Throwable) {
        }
    }

    /** Relê o estado real no sistema e, se mudou, avisa a interface (que volta a ler com "init"). */
    private fun checkDefaultChange(why: String) {
        val app = applicationContext
        Thread {
            try {
                val now = Sender.isDefault(app)
                if (now != lastDefault) {
                    DefaultSms.logState(app, "$why: mudou ${lastDefault} -> $now")
                    lastDefault = now
                    Events.emit("default")
                    if (!now && visible) { mainH.removeCallbacks(pollDefault); mainH.postDelayed(pollDefault, 3000) }
                }
            } catch (_: Throwable) {
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        Bubbles.appVisible = true
        web.onResume()
        DefaultSms.logState(applicationContext, "onResume")
        web.evaluateJavascript("window.__resume&&window.__resume()", null)
        // Ao voltar das Definições do Android o sistema pode demorar a atualizar a aplicação predefinida
        // (Android 16 / One UI 8.5): relê várias vezes durante ~15 s e escuta a definição do sistema.
        visible = true
        mainH.removeCallbacks(recheckDefault)
        mainH.removeCallbacks(pollDefault)
        watchDefault(true)
        if (!lastDefault) mainH.postDelayed(pollDefault, 3000)
        for (d in longArrayOf(0, 400, 1000, 2000, 3500, 5000, 7500, 10000, 15000)) mainH.postDelayed(recheckDefault, d)
        if (!lastDefault) Thread { try { DefaultSms.checkComponents(applicationContext) } catch (_: Throwable) {} }.start()
    }

    override fun onPause() {
        visible = false
        mainH.removeCallbacks(recheckDefault)
        mainH.removeCallbacks(pollDefault)
        watchDefault(false)
        Bubbles.appVisible = false
        Media.recCancel()
        Player.pause()
        TrashLock.lockNow()
        // Envia já qualquer mensagem à espera do “Desfazer”: a app vai para segundo plano.
        web.evaluateJavascript("window.__pause&&window.__pause()", null)
        web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        Events.sink = null
        Player.stop()
        web.removeJavascriptInterface("ChatsNative")
        web.destroy()
        super.onDestroy()
    }
}
