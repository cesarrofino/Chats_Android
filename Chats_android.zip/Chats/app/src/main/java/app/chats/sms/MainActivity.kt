package app.chats.sms

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    lateinit var web: WebView
    private lateinit var bridge: Bridge

    private var pickCb: ((Uri?) -> Unit)? = null
    private var resultCb: ((ActivityResult) -> Unit)? = null
    private var permCb: ((Map<String, Boolean>) -> Unit)? = null

    private val pickLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val cb = pickCb
        pickCb = null
        cb?.invoke(uri)
    }
    private val resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = resultCb
        resultCb = null
        cb?.invoke(r)
    }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { m ->
        val cb = permCb
        permCb = null
        cb?.invoke(m)
    }

    fun pick(mime: String, cb: (Uri?) -> Unit) {
        runOnUiThread {
            pickCb = cb
            try {
                pickLauncher.launch(mime)
            } catch (e: Exception) {
                pickCb = null
                cb(null)
            }
        }
    }

    fun startForResult(i: Intent, cb: (ActivityResult) -> Unit) {
        runOnUiThread {
            resultCb = cb
            try {
                resultLauncher.launch(i)
            } catch (e: Exception) {
                resultCb = null
                cb(ActivityResult(Activity.RESULT_CANCELED, null))
            }
        }
    }

    fun askPerms(perms: Array<String>, cb: (Map<String, Boolean>) -> Unit) {
        runOnUiThread {
            permCb = cb
            permLauncher.launch(perms)
        }
    }

    fun setBars(dark: Boolean, color: Int) {
        runOnUiThread {
            window.statusBarColor = color
            window.navigationBarColor = color
            val c = WindowCompat.getInsetsController(window, window.decorView)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        // Android 15+/One UI 9 podem desenhar por baixo das barras do sistema: reservamos esse espaço
        // (barra de estado, navegação, câmara e teclado) para que as setas e botões fiquem tocáveis.
        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }
        bridge = Bridge(this)
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false          // os recursos locais vêm de file:///android_asset
            allowContentAccess = false
            blockNetworkLoads = true         // a interface é 100 % local
            setSupportZoom(false)
            builtInZoomControls = false
            textZoom = 100
            mediaPlaybackRequiresUserGesture = false
        }
        web.overScrollMode = android.view.View.OVER_SCROLL_NEVER
        web.addJavascriptInterface(bridge, "ChatsNative")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url.toString()
                if (u.startsWith("file:///android_asset/")) return false
                bridge.openExternal(u)
                return true
            }
        }
        Events.sink = { n, d ->
            runOnUiThread {
                web.evaluateJavascript(
                    "window.__ev&&window.__ev(${JSONObject.quote(n)},${JSONObject.quote(d)})", null
                )
            }
        }
        handleIntent(intent, false)
        web.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.__back?window.__back():false") { r ->
                    if (r != "true") moveTaskToBack(true)
                }
            }
        })
    }

    private fun handleIntent(i: Intent?, live: Boolean) {
        if (i == null) return
        val o = JSONObject()
        val t = i.getLongExtra("thread", -1L)
        if (t >= 0) o.put("thread", t)
        val d = i.data
        val sch = d?.scheme
        if (d != null && (sch == "sms" || sch == "smsto" || sch == "mms" || sch == "mmsto")) {
            val ssp = d.schemeSpecificPart ?: ""
            val addr = ssp.substringBefore('?').trim()
            if (addr.isNotEmpty()) o.put("address", Uri.decode(addr))
            val body = i.getStringExtra("sms_body")
                ?: ssp.substringAfter('?', "").split("&").firstOrNull { it.startsWith("body=") }
                    ?.substring(5)?.let { Uri.decode(it) }
            if (!body.isNullOrEmpty()) o.put("body", body)
        }
        if (i.action == Intent.ACTION_SEND && i.type == "text/plain") {
            i.getStringExtra(Intent.EXTRA_TEXT)?.let { o.put("share", it.take(20_000)) }
        }
        if (o.length() > 0) {
            if (live) Events.emit("open", o.toString()) else Events.pending = o
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent, true)
    }

    override fun onResume() {
        super.onResume()
        Bubbles.appVisible = true
        Bubbles.clearAll()
        web.onResume()
        web.evaluateJavascript("window.__resume&&window.__resume()", null)
    }

    override fun onPause() {
        Bubbles.appVisible = false
        Media.recCancel()
        Player.pause()
        TrashLock.lockNow()
        web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        Events.sink = null
        Player.stop()
        web.removeJavascriptInterface("ChatsNative")
        web.destroy()
        super.onDestroy()
    }
}
