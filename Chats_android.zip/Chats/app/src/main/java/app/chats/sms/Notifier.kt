package app.chats.sms

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.provider.BlockedNumberContract
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput

object Notifier {
    private const val BRAND = 0xFF2BB39D.toInt()
    private val codeRe = Regex("\\b\\d{4,8}\\b")
    private val codeWords = Regex("(c[óo]digo|code|verifica|otp|pin|senha|password|token|2fa|confirma)", RegexOption.IGNORE_CASE)

    fun isBlocked(c: Context, number: String): Boolean = try {
        BlockedNumberContract.isBlocked(c, number)
    } catch (e: Throwable) {
        false
    }

    private fun enabled(c: Context) = NotificationManagerCompat.from(c).areNotificationsEnabled()

    private fun channel(c: Context): String {
        val snd = Store.str(c, "sound", "")
        val id = when {
            snd.isEmpty() -> "msgs"
            snd == "none" -> "msgs_silent"
            else -> "msgs_" + Integer.toHexString(snd.hashCode())
        }
        if (Build.VERSION.SDK_INT >= 26) {
            val m = c.getSystemService(NotificationManager::class.java)
            if (m.getNotificationChannel(id) == null) {
                val ch = NotificationChannel(
                    id, "Mensagens",
                    if (snd == "none") NotificationManager.IMPORTANCE_LOW else NotificationManager.IMPORTANCE_HIGH
                )
                ch.description = "Novas mensagens SMS e MMS"
                ch.lockscreenVisibility = Notification.VISIBILITY_PRIVATE
                if (snd == "none") {
                    ch.setSound(null, null)
                } else if (snd.isNotEmpty()) {
                    ch.setSound(
                        Uri.parse(snd),
                        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                    )
                }
                m.createNotificationChannel(ch)
            }
            if (m.getNotificationChannel("delivery") == null) {
                val d = NotificationChannel("delivery", "Entrega e agendamento", NotificationManager.IMPORTANCE_DEFAULT)
                d.description = "Confirmações de entrega, falhas e mensagens programadas"
                m.createNotificationChannel(d)
            }
        }
        return id
    }

    private fun openIntent(c: Context, thread: Long): PendingIntent {
        val i = Intent(c, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("thread", thread)
        return PendingIntent.getActivity(c, thread.toInt(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun act(c: Context, action: String, thread: Long, addr: String, mutable: Boolean, extra: String? = null): PendingIntent {
        val i = Intent(c, ActionReceiver::class.java).setAction(action)
            .setData(Uri.parse("chats://$action/$thread"))
            .putExtra("thread", thread).putExtra("addr", addr)
        if (extra != null) i.putExtra("extra", extra)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (mutable) (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0) else PendingIntent.FLAG_IMMUTABLE)
        return PendingIntent.getBroadcast(c, thread.toInt(), i, flags)
    }

    /** Notificação de mensagem recebida. */
    fun incoming(c: Context, thread: Long, address: String, body: String) {
        if (!Store.bool(c, "notify", true) || Store.isMuted(c, thread) || !enabled(c)) return
        if (isBlocked(c, address)) return
        val name = Contacts.name(c, address) ?: address
        val mode = Store.str(c, "preview", "full")
        val isCode = codeRe.containsMatchIn(body) && codeWords.containsMatchIn(body)
        val text = when {
            isCode -> "Código de verificação"
            mode == "full" -> body
            else -> "Nova mensagem"
        }
        val title = if (mode == "hidden") "Chats" else name
        val chan = channel(c)
        val b = NotificationCompat.Builder(c, chan)
            .setSmallIcon(R.drawable.ic_stat_chat)
            .setColor(BRAND)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setAutoCancel(true)
            .setContentIntent(openIntent(c, thread))
        if (Build.VERSION.SDK_INT < 26) {
            val snd = Store.str(c, "sound", "")
            if (snd == "none") b.setSilent(true) else if (snd.isNotEmpty()) b.setSound(Uri.parse(snd))
            else b.setDefaults(NotificationCompat.DEFAULT_SOUND or NotificationCompat.DEFAULT_VIBRATE)
        }
        if (isCode && Store.bool(c, "copyCodes", true)) {
            val code = codeRe.find(body)?.value ?: ""
            b.addAction(0, "Copiar código", act(c, "copy", thread, address, false, code))
        } else if (mode != "hidden") {
            val ri = RemoteInput.Builder("reply_text").setLabel("Responder").build()
            val reply = NotificationCompat.Action.Builder(0, "Responder", act(c, "reply", thread, address, true))
                .addRemoteInput(ri).setAllowGeneratedReplies(true).build()
            b.addAction(reply)
        }
        b.addAction(0, "Marcar como lida", act(c, "read", thread, address, false))
        try {
            NotificationManagerCompat.from(c).notify(thread.toInt(), b.build())
        } catch (_: SecurityException) {
        }
    }

    fun cancel(c: Context, thread: Long) {
        try { NotificationManagerCompat.from(c).cancel(thread.toInt()) } catch (_: Exception) {}
    }

    private fun simple(c: Context, id: Int, title: String, text: String, thread: Long) {
        if (!enabled(c)) return
        channel(c)
        val b = NotificationCompat.Builder(c, "delivery")
            .setSmallIcon(R.drawable.ic_stat_chat).setColor(BRAND)
            .setContentTitle(title).setContentText(text)
            .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(openIntent(c, thread))
        try { NotificationManagerCompat.from(c).notify(id, b.build()) } catch (_: SecurityException) {}
    }

    fun delivered(c: Context, thread: Long, address: String, msgId: Long) {
        if (!Store.bool(c, "deliveryNotif", true)) return
        val name = Contacts.name(c, address) ?: address
        simple(c, (0x40000000 or (msgId.toInt() and 0x3FFFFFFF)), "Entrega confirmada", "A mensagem para $name foi entregue.", thread)
    }

    fun failed(c: Context, thread: Long, address: String, msgId: Long) {
        val name = if (address.isBlank()) "o destinatário" else (Contacts.name(c, address) ?: address)
        simple(c, (0x20000000 or (msgId.toInt() and 0x1FFFFFFF)), "Falha no envio", "Não foi possível enviar a mensagem para $name. Toque para tentar novamente.", thread)
    }

    fun info(c: Context, id: Int, title: String, text: String) = simple(c, id, title, text, 0L)
}
