package app.chats.sms

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.provider.BlockedNumberContract
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.app.RemoteInput
import androidx.core.content.LocusIdCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat

object Notifier {
    private const val BRAND = 0xFF1F7BFF.toInt()
    private const val GROUP = "app.chats.sms.MESSAGES"
    private const val SUMMARY_ID = 0x5A000001
    @Volatile private var lastBadge = -1
    private val PAL = arrayOf(
        intArrayOf(0xFFFF885E.toInt(), 0xFFFF516A.toInt()), intArrayOf(0xFFFFCD6A.toInt(), 0xFFFFA85C.toInt()),
        intArrayOf(0xFF82B1FF.toInt(), 0xFF665FFF.toInt()), intArrayOf(0xFFA0DE7E.toInt(), 0xFF54CB68.toInt()),
        intArrayOf(0xFF53EDD6.toInt(), 0xFF28C9B7.toInt()), intArrayOf(0xFF72D5FD.toInt(), 0xFF2A9EF1.toInt()),
        intArrayOf(0xFFFF8FB8.toInt(), 0xFFE5579B.toInt())
    )
    private val codeRe = Regex("\\b\\d{4,8}\\b")
    private val codeWords = Regex("(c[óo]digo|code|verifica|otp|pin|senha|password|token|2fa|confirma)", RegexOption.IGNORE_CASE)

    fun isBlocked(c: Context, number: String): Boolean = try {
        BlockedNumberContract.isBlocked(c, number)
    } catch (e: Throwable) {
        false
    }

    private fun enabled(c: Context) = NotificationManagerCompat.from(c).areNotificationsEnabled()

    private fun channel(c: Context): String {
        val snd = Store.str(c, "sound", "")
        val id = when {
            snd.isEmpty() -> "msgs"
            snd == "none" -> "msgs_silent"
            else -> "msgs_" + Integer.toHexString(snd.hashCode())
        }
        if (Build.VERSION.SDK_INT >= 26) {
            val m = c.getSystemService(NotificationManager::class.java)
            if (m.getNotificationChannel(id) == null) {
                val ch = NotificationChannel(
                    id, "Mensagens",
                    if (snd == "none") NotificationManager.IMPORTANCE_LOW else NotificationManager.IMPORTANCE_HIGH
                )
                ch.description = "Novas mensagens SMS e MMS"
                ch.lockscreenVisibility = Notification.VISIBILITY_PRIVATE
                if (snd == "none") {
                    ch.setSound(null, null)
                } else if (snd.isNotEmpty()) {
                    ch.setSound(
                        Uri.parse(snd),
                        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                    )
                }
                m.createNotificationChannel(ch)
            }
            if (m.getNotificationChannel("delivery") == null) {
                val d = NotificationChannel("delivery", "Entrega e agendamento", NotificationManager.IMPORTANCE_DEFAULT)
                d.description = "Confirmações de entrega, falhas e mensagens programadas"
                m.createNotificationChannel(d)
            }
        }
        return id
    }

    private fun openIntent(c: Context, thread: Long): PendingIntent {
        val i = Intent(c, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("thread", thread)
        return PendingIntent.getActivity(c, thread.toInt(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun act(c: Context, action: String, thread: Long, addr: String, mutable: Boolean, extra: String? = null): PendingIntent {
        val i = Intent(c, ActionReceiver::class.java).setAction(action)
            .setData(Uri.parse("chats://$action/$thread"))
            .putExtra("thread", thread).putExtra("addr", addr)
        if (extra != null) i.putExtra("extra", extra)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (mutable) (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0) else PendingIntent.FLAG_IMMUTABLE)
        return PendingIntent.getBroadcast(c, thread.toInt(), i, flags)
    }

    // ---------------------------------------------------------------- avatar
    private fun circle(src: Bitmap, size: Int): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val sc = Bitmap.createScaledBitmap(src, size, size, true)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = BitmapShader(sc, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        Canvas(out).drawCircle(size / 2f, size / 2f, size / 2f, p)
        return out
    }

    private fun avatar(c: Context, address: String, name: String, size: Int = 192): Bitmap {
        try {
            val u = Contacts.lookup(c, address)[1]
            if (u != null) {
                c.contentResolver.openInputStream(Uri.parse(u))?.use { ins ->
                    val b = BitmapFactory.decodeStream(ins)
                    if (b != null) return circle(b, size)
                }
            }
        } catch (_: Exception) {
        }
        var h = 0L
        for (ch in (address.ifEmpty { name })) h = (h * 31 + ch.code) and 0xFFFFFFFFL
        val pal = PAL[(h % 7).toInt()]
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, size.toFloat(), size.toFloat(), pal[0], pal[1], Shader.TileMode.CLAMP)
        cv.drawCircle(size / 2f, size / 2f, size / 2f, p)
        val letters = if (name.all { it.isDigit() || it in "+ ()-" }) "" else
            name.split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.first().uppercase() }
        val t = Paint(Paint.ANTI_ALIAS_FLAG)
        t.shader = null; t.color = 0xFFFFFFFF.toInt(); t.textAlign = Paint.Align.CENTER
        t.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        if (letters.isNotEmpty()) {
            t.textSize = size * 0.42f
            cv.drawText(letters, size / 2f, size / 2f - (t.descent() + t.ascent()) / 2f, t)
        } else {
            // silhueta simples
            cv.drawCircle(size / 2f, size * 0.38f, size * 0.15f, t)
            cv.drawCircle(size / 2f, size * 0.92f, size * 0.30f, t)
        }
        return circle(out, size)
    }

    private fun textFor(mode: String, body: String): String {
        val isCode = codeRe.containsMatchIn(body) && codeWords.containsMatchIn(body)
        return when {
            isCode -> "Código de verificação"
            mode == "full" -> body
            else -> "Nova mensagem"
        }
    }

    // ---------------------------------------------------------------- badge
    /** Atualiza o número no ícone da app: todas as mensagens por abrir (chats, desconhecidos e serviços). */
    fun badge(c: Context, known: Int? = null) {
        val n = known ?: try { Messages.totalUnread(c) } catch (e: Throwable) { return }
        if (n == lastBadge) return
        lastBadge = n
        try {
            // Samsung One UI / launchers compatíveis
            val i = Intent("android.intent.action.BADGE_COUNT_UPDATE")
                .putExtra("badge_count", n)
                .putExtra("badge_count_package_name", c.packageName)
                .putExtra("badge_count_class_name", MainActivity::class.java.name)
            c.sendBroadcast(i)
        } catch (_: Throwable) {
        }
        refreshSummary(c, n)
    }

    private fun activeChildren(c: Context): Int {
        if (Build.VERSION.SDK_INT < 23) return 1
        return try {
            c.getSystemService(NotificationManager::class.java).activeNotifications
                .count { it.id != SUMMARY_ID && it.notification.group == GROUP }
        } catch (e: Throwable) { 0 }
    }

    private fun refreshSummary(c: Context, total: Int) {
        if (!enabled(c)) return
        try {
            val nm = NotificationManagerCompat.from(c)
            if (total <= 0 || activeChildren(c) == 0) { nm.cancel(SUMMARY_ID); return }
            val chan = channel(c)
            val open = Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val s = NotificationCompat.Builder(c, chan)
                .setSmallIcon(R.drawable.ic_stat_chat).setColor(BRAND)
                .setContentTitle("Chats")
                .setContentText(if (total == 1) "1 mensagem por abrir" else "$total mensagens por abrir")
                .setStyle(NotificationCompat.InboxStyle().setSummaryText(if (total == 1) "1 mensagem nova" else "$total mensagens novas"))
                .setNumber(total)
                .setGroup(GROUP).setGroupSummary(true)
                .setGroupAlertBehavior(NotificationCompat.GROUP_ALERT_CHILDREN)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            nm.notify(SUMMARY_ID, s.build())
        } catch (_: SecurityException) {
        }
    }

    /** Notificação de mensagem recebida (estilo conversa, agrupada). */
    fun incoming(c: Context, thread: Long, address: String, body: String) {
        badge(c)
        if (!Store.bool(c, "notify", true) || Store.isMuted(c, thread) || !enabled(c)) return
        if (isBlocked(c, address)) return
        val name = Contacts.name(c, address) ?: address
        val mode = Store.str(c, "preview", "full")
        val isCode = codeRe.containsMatchIn(body) && codeWords.containsMatchIn(body)
        val chan = channel(c)
        val total = try { Messages.totalUnread(c) } catch (e: Throwable) { 1 }
        val shownName = if (mode == "hidden") "Chats" else name
        val av = avatar(c, address, name)
        val sender = Person.Builder().setName(shownName).setKey(address.ifEmpty { "t$thread" })
            .setIcon(IconCompat.createWithBitmap(av)).setImportant(true).build()
        val me = Person.Builder().setName("Eu").build()
        val style = NotificationCompat.MessagingStyle(me)
        val recent = Messages.recentUnread(c, thread, 5)
        if (recent.isEmpty()) {
            style.addMessage(textFor(mode, body), System.currentTimeMillis(), sender)
        } else {
            recent.forEach { style.addMessage(textFor(mode, it.first), it.second, sender) }
        }
        val count = maxOf(recent.size, 1)
        val b = NotificationCompat.Builder(c, chan)
            .setSmallIcon(R.drawable.ic_stat_chat)
            .setColor(BRAND)
            .setLargeIcon(av)
            .setContentTitle(shownName)
            .setContentText(textFor(mode, body))
            .setStyle(style)
            .setNumber(maxOf(total, count))
            .setWhen(System.currentTimeMillis()).setShowWhen(true)
            .setGroup(GROUP)
            .setGroupAlertBehavior(NotificationCompat.GROUP_ALERT_CHILDREN)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setAutoCancel(true)
            .setContentIntent(openIntent(c, thread))
        try {
            val sid = "t$thread"
            val sc = Intent(c, MainActivity::class.java).setAction(Intent.ACTION_VIEW).putExtra("thread", thread)
            val info = ShortcutInfoCompat.Builder(c, sid)
                .setShortLabel(shownName).setLongLived(true).setPerson(sender)
                .setIcon(IconCompat.createWithBitmap(av)).setIntent(sc)
                .setLocusId(LocusIdCompat(sid)).build()
            ShortcutManagerCompat.pushDynamicShortcut(c, info)
            b.setShortcutId(sid).setLocusId(LocusIdCompat(sid))
        } catch (_: Throwable) {
        }
        if (Build.VERSION.SDK_INT < 26) {
            val snd = Store.str(c, "sound", "")
            if (snd == "none") b.setSilent(true) else if (snd.isNotEmpty()) b.setSound(Uri.parse(snd))
            else b.setDefaults(NotificationCompat.DEFAULT_SOUND or NotificationCompat.DEFAULT_VIBRATE)
        }
        if (isCode && Store.bool(c, "copyCodes", true)) {
            val code = codeRe.find(body)?.value ?: ""
            b.addAction(NotificationCompat.Action.Builder(0, "Copiar código", act(c, "copy", thread, address, false, code)).build())
        } else if (mode != "hidden") {
            val ri = RemoteInput.Builder("reply_text").setLabel("Responder").build()
            val reply = NotificationCompat.Action.Builder(0, "Responder", act(c, "reply", thread, address, true))
                .addRemoteInput(ri).setAllowGeneratedReplies(true)
                .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_REPLY).setShowsUserInterface(false).build()
            b.addAction(reply)
        }
        b.addAction(
            NotificationCompat.Action.Builder(0, "Marcar como lida", act(c, "read", thread, address, false))
                .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_MARK_AS_READ).setShowsUserInterface(false).build()
        )
        try {
            NotificationManagerCompat.from(c).notify(thread.toInt(), b.build())
            refreshSummary(c, total)
        } catch (_: SecurityException) {
        }
    }

    fun cancel(c: Context, thread: Long) {
        try { NotificationManagerCompat.from(c).cancel(thread.toInt()) } catch (_: Exception) {}
        lastBadge = -1
        badge(c)
    }

    private fun simple(c: Context, id: Int, title: String, text: String, thread: Long) {
        if (!enabled(c)) return
        channel(c)
        val b = NotificationCompat.Builder(c, "delivery")
            .setSmallIcon(R.drawable.ic_stat_chat).setColor(BRAND)
            .setContentTitle(title).setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(openIntent(c, thread))
        try { NotificationManagerCompat.from(c).notify(id, b.build()) } catch (_: SecurityException) {}
    }

    fun delivered(c: Context, thread: Long, address: String, msgId: Long) {
        if (!Store.bool(c, "deliveryNotif", true)) return
        val name = Contacts.name(c, address) ?: address
        simple(c, (0x40000000 or (msgId.toInt() and 0x3FFFFFFF)), "Entrega confirmada", "A mensagem para $name foi entregue.", thread)
    }

    fun failed(c: Context, thread: Long, address: String, msgId: Long) {
        val name = if (address.isBlank()) "o destinatário" else (Contacts.name(c, address) ?: address)
        simple(c, (0x20000000 or (msgId.toInt() and 0x1FFFFFFF)), "Falha no envio", "Não foi possível enviar a mensagem para $name. Toque para tentar novamente.", thread)
    }

    fun info(c: Context, id: Int, title: String, text: String) = simple(c, id, title, text, 0L)
}
