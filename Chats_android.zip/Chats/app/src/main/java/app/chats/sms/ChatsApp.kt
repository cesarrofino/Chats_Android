package app.chats.sms

import android.app.Application

/** Guarda o contexto da aplicação para o widget e os atalhos poderem atualizar-se quando as mensagens mudam. */
class ChatsApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Events.app = applicationContext
        val c = applicationContext
        Thread { try { Widgets.refresh(c) } catch (_: Throwable) {} }.start()
    }
}
