package app.chats.sms

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.provider.Telephony
import android.util.Log

/**
 * Estado real da aplicação SMS predefinida e pedido oficial para a definir.
 *
 *  - Android 10+ (API 29+): RoleManager.ROLE_SMS (o ecrã "Aplicações predefinidas" do sistema usa o mesmo papel).
 *  - Android 7–9: Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT.
 *
 * O estado NUNCA é simulado: é sempre lido do sistema com Telephony.Sms.getDefaultSmsPackage(),
 * comparado com o applicationId real. Filtrar nos logs com:  adb logcat -s ChatsDefaultSms
 */
object DefaultSms {
    const val TAG = "ChatsDefaultSms"
    private const val PERM_RESPOND = "android.permission.SEND_RESPOND_VIA_MESSAGE"
    private const val MMS_MIME = "application/vnd.wap.mms-message"

    fun log(msg: String) { Log.i(TAG, msg) }

    /** applicationId real da instalação em execução (= packageName do processo). */
    fun appId(c: Context): String = c.applicationContext.packageName

    /** Verdadeiro só se o sistema indicar este applicationId como aplicação SMS predefinida. */
    fun isDefault(c: Context): Boolean {
        val def = try { Telephony.Sms.getDefaultSmsPackage(c.applicationContext) } catch (e: Throwable) {
            Log.w(TAG, "getDefaultSmsPackage falhou: ${e.message}"); null
        }
        return def != null && def == appId(c)
    }

    /**
     * O sistema atualiza o estado de forma assíncrona depois de o utilizador escolher a aplicação
     * (sobretudo em One UI), por isso ler logo ao regressar pode devolver o valor antigo.
     * Espera (em segundo plano!) até o estado ser [expected] ou ao fim de [timeoutMs].
     */
    fun await(c: Context, expected: Boolean, timeoutMs: Long = 4000, stepMs: Long = 250): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        var now = isDefault(c)
        while (now != expected && System.currentTimeMillis() < end) {
            try { Thread.sleep(stepMs) } catch (_: InterruptedException) { break }
            now = isDefault(c)
        }
        log("await(expected=$expected) -> $now")
        return now
    }

    /** Intent principal (RoleManager em API 29+) e alternativa caso o principal não exista neste dispositivo. */
    fun requestIntents(c: Context): Pair<Intent, Intent> {
        val app = c.applicationContext
        val legacy = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
            .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, appId(app))
        val settings = Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = app.getSystemService(RoleManager::class.java)
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_SMS)) {
                return Pair(rm.createRequestRoleIntent(RoleManager.ROLE_SMS), settings)
            }
            log("ROLE_SMS indisponível (rm=${rm != null}); a usar ACTION_CHANGE_DEFAULT")
            return Pair(legacy, settings)
        }
        return Pair(legacy, settings)
    }

    /** Uma linha com o estado atual, para os logs. */
    fun logState(c: Context, why: String) {
        val app = c.applicationContext
        val def = try { Telephony.Sms.getDefaultSmsPackage(app) } catch (e: Throwable) { "erro:${e.message}" }
        var role = "n/a"
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val rm = app.getSystemService(RoleManager::class.java)
                role = "disponivel=${rm.isRoleAvailable(RoleManager.ROLE_SMS)} atribuido=${rm.isRoleHeld(RoleManager.ROLE_SMS)}"
            } catch (e: Throwable) { role = "erro:${e.message}" }
        }
        val perms = listOf(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS)
            .joinToString(",") { (if (app.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED) "+" else "-") + it.substringAfterLast('.') }
        log("[$why] appId=${appId(app)} predefinidaSistema=$def isDefault=${def == appId(app)} role{$role} " +
            "sdk=${Build.VERSION.SDK_INT} dispositivo=${Build.MANUFACTURER}/${Build.MODEL} perms=$perms")
    }

    /**
     * Confirma que o sistema "vê" os 4 componentes exigidos a uma aplicação SMS predefinida.
     * Se algum faltar, o Android deixa de listar/aceitar a aplicação e getDefaultSmsPackage devolve outra.
     * Devolve a lista de problemas (vazia = tudo certo) e escreve-a nos logs.
     */
    @Suppress("DEPRECATION")
    fun checkComponents(c: Context): List<String> {
        val app = c.applicationContext
        val pm = app.packageManager
        val me = appId(app)
        val problems = ArrayList<String>()

        val sendTo = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:+10000000000"))
        if (pm.queryIntentActivities(sendTo, 0).none { it.activityInfo.packageName == me && it.activityInfo.exported })
            problems.add("Falta Activity exportada com ACTION_SENDTO (sms/smsto/mms/mmsto) + CATEGORY_DEFAULT")

        val smsDeliver = Intent(Telephony.Sms.Intents.SMS_DELIVER_ACTION)
        val smsRx = pm.queryBroadcastReceivers(smsDeliver, 0).firstOrNull { it.activityInfo.packageName == me }
        if (smsRx == null) problems.add("Falta BroadcastReceiver para SMS_DELIVER")
        else if (smsRx.activityInfo.permission != Manifest.permission.BROADCAST_SMS)
            problems.add("Receiver SMS_DELIVER sem android:permission=BROADCAST_SMS (tem '${smsRx.activityInfo.permission}')")

        val wap = Intent(Telephony.Sms.Intents.WAP_PUSH_DELIVER_ACTION).setType(MMS_MIME)
        val mmsRx = pm.queryBroadcastReceivers(wap, 0).firstOrNull { it.activityInfo.packageName == me }
        if (mmsRx == null) problems.add("Falta BroadcastReceiver para WAP_PUSH_DELIVER ($MMS_MIME)")
        else if (mmsRx.activityInfo.permission != Manifest.permission.BROADCAST_WAP_PUSH)
            problems.add("Receiver WAP_PUSH_DELIVER sem android:permission=BROADCAST_WAP_PUSH (tem '${mmsRx.activityInfo.permission}')")

        val respond = Intent(TelephonyRespond.ACTION, Uri.parse("smsto:+10000000000"))
        val svc = pm.queryIntentServices(respond, 0).firstOrNull { it.serviceInfo.packageName == me }
        if (svc == null) problems.add("Falta Service para RESPOND_VIA_MESSAGE")
        else if (svc.serviceInfo.permission != PERM_RESPOND)
            problems.add("Service RESPOND_VIA_MESSAGE sem android:permission=SEND_RESPOND_VIA_MESSAGE (tem '${svc.serviceInfo.permission}')")

        if (problems.isEmpty()) log("Componentes SMS: OK (Activity SENDTO, receiver SMS_DELIVER, receiver WAP_PUSH_DELIVER, service RESPOND_VIA_MESSAGE)")
        else problems.forEach { Log.w(TAG, "Componente em falta/errado: $it") }
        return problems
    }

    private object TelephonyRespond { const val ACTION = "android.intent.action.RESPOND_VIA_MESSAGE" }
}
