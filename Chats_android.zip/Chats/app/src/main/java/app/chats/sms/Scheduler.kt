package app.chats.sms

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject

/** Mensagens programadas (apenas SMS de texto). Usa o AlarmManager; sem permissão de alarmes exatos o envio pode atrasar. */
object Scheduler {
    private fun pi(c: Context, id: Int): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java).putExtra("id", id)
        return PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun canExact(c: Context): Boolean =
        Build.VERSION.SDK_INT < 31 || c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    fun list(c: Context): JSONArray = Store.scheduled(c)

    private fun find(a: JSONArray, id: Int): Int {
        for (i in 0 until a.length()) if (a.getJSONObject(i).optInt("id") == id) return i
        return -1
    }

    /** Cria ou atualiza um agendamento. Devolve o item guardado. */
    fun save(c: Context, item: JSONObject): JSONObject {
        val a = Store.scheduled(c)
        var id = item.optInt("id", 0)
        if (id == 0) id = ((System.currentTimeMillis() / 1000) % 2_000_000_000L).toInt()
        val time = item.optLong("time")
        if (time < System.currentTimeMillis() + 5_000) throw Exception("Escolha uma data e hora futuras.")
        val body = item.optString("body")
        if (body.isBlank() || body.length > 2000) throw Exception("Escreva a mensagem (até 2000 caracteres).")
        val addrs = item.optJSONArray("addrs") ?: JSONArray()
        if (addrs.length() == 0 || addrs.length() > 20) throw Exception("Indique entre 1 e 20 destinatários.")
        val o = JSONObject()
            .put("id", id).put("addrs", addrs).put("body", body).put("time", time)
            .put("sub", item.optInt("sub", -1)).put("status", "pending")
        val idx = find(a, id)
        if (idx >= 0) a.put(idx, o) else a.put(o)
        Store.saveScheduled(c, a)
        arm(c, o)
        return o.put("exact", canExact(c))
    }

    fun arm(c: Context, o: JSONObject) {
        val am = c.getSystemService(AlarmManager::class.java)
        val p = pi(c, o.getInt("id"))
        val t = o.getLong("time")
        try {
            if (canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p)
        } catch (e: SecurityException) {
            am.set(AlarmManager.RTC_WAKEUP, t, p)
        }
    }

    fun delete(c: Context, id: Int) {
        val a = Store.scheduled(c)
        val out = JSONArray()
        for (i in 0 until a.length()) if (a.getJSONObject(i).optInt("id") != id) out.put(a.get(i))
        Store.saveScheduled(c, out)
        c.getSystemService(AlarmManager::class.java).cancel(pi(c, id))
    }

    fun rescheduleAll(c: Context) {
        val a = Store.scheduled(c)
        val now = System.currentTimeMillis()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optString("status") != "pending") continue
            if (o.optLong("time") <= now) fire(c, o.getInt("id")) else arm(c, o)
        }
    }

    private fun setStatus(c: Context, id: Int, st: String, err: String? = null) {
        val a = Store.scheduled(c)
        val i = find(a, id)
        if (i >= 0) {
            val o = a.getJSONObject(i).put("status", st)
            if (err != null) o.put("error", err)
            a.put(i, o)
            Store.saveScheduled(c, a)
        }
        Events.emit("scheduled")
    }

    fun fire(c: Context, id: Int) {
        val a = Store.scheduled(c)
        val i = find(a, id)
        if (i < 0) return
        val o = a.getJSONObject(i)
        if (o.optString("status") != "pending") return
        val addrs = ArrayList<String>()
        val aa = o.getJSONArray("addrs")
        for (k in 0 until aa.length()) addrs.add(aa.getString(k))
        try {
            if (!Sender.isDefault(c)) throw Exception("O Chats deixou de ser a aplicação SMS predefinida.")
            Sender.sendSms(c, addrs, o.getString("body"), o.optInt("sub", -1), Store.bool(c, "deliveryReports", true))
            setStatus(c, id, "sent")
            Notifier.info(c, id, "Mensagem programada enviada", o.getString("body").take(80))
        } catch (e: Exception) {
            val msg = e.message ?: "Erro desconhecido"
            setStatus(c, id, "failed", msg)
            Notifier.info(c, id, "Mensagem programada não enviada", msg)
        }
        Events.emit("changed")
    }
}
