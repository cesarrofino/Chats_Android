package app.chats.sms

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.provider.Telephony
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Lixo: guarda cópia das mensagens eliminadas durante 30 dias; depois apaga para sempre. */
object Trash {
    const val DAYS = 30
    private const val DAY = 86_400_000L

    private class Db(c: Context) : SQLiteOpenHelper(c.applicationContext, "trash.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE trash(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, ckey TEXT, addrs TEXT, addr TEXT," +
                    " body TEXT, subject TEXT, date INTEGER, box INTEGER, status INTEGER, sub INTEGER, mtype INTEGER," +
                    " raw TEXT, parts TEXT, deleted INTEGER)"
            )
            db.execSQL("CREATE INDEX t_ck ON trash(ckey)")
            db.execSQL("CREATE INDEX t_del ON trash(deleted)")
        }

        override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}
    }

    @Volatile private var helper: Db? = null
    private fun db(c: Context): SQLiteDatabase {
        val h = helper ?: synchronized(this) { helper ?: Db(c).also { helper = it } }
        return h.writableDatabase
    }

    private fun dir(c: Context, id: Long) = File(c.filesDir, "trash/$id")

    // ------------------------------------------------------------ utilitários
    private fun s(cur: Cursor, n: String): String {
        val i = cur.getColumnIndex(n)
        return if (i >= 0 && !cur.isNull(i)) cur.getString(i) ?: "" else ""
    }

    private fun l(cur: Cursor, n: String, d: Long = 0L): Long {
        val i = cur.getColumnIndex(n)
        return if (i >= 0 && !cur.isNull(i)) cur.getLong(i) else d
    }

    private fun norm(a: String): String {
        val digits = a.filter { it.isDigit() }
        return if (digits.length >= 7 && digits.length >= a.length - 3) digits.takeLast(9) else a.trim().lowercase()
    }

    private fun ckey(addrs: List<String>) = addrs.map { norm(it) }.distinct().sorted().joinToString("|")

    // ------------------------------------------------------------ captura
    fun captureThread(c: Context, thread: Long, stamp: Long) {
        captureSms(c, "thread_id=?", arrayOf(thread.toString()), stamp)
        captureMms(c, "thread_id=?", arrayOf(thread.toString()), stamp)
    }

    fun captureMessage(c: Context, kind: String, id: Long, stamp: Long) {
        if (kind == "m") captureMms(c, "_id=?", arrayOf(id.toString()), stamp)
        else captureSms(c, "_id=?", arrayOf(id.toString()), stamp)
    }

    fun captureSms(c: Context, where: String?, args: Array<String>?, stamp: Long) {
        try {
            c.contentResolver.query(Uri.parse("content://sms"), null, where, args, null)?.use { cur ->
                val d = db(c)
                d.beginTransaction()
                try {
                    while (cur.moveToNext()) {
                        val type = l(cur, "type").toInt()
                        if (type == 3) continue // rascunho
                        val addr = s(cur, "address")
                        val v = ContentValues()
                        v.put("kind", "s")
                        v.put("ckey", ckey(listOf(addr)))
                        v.put("addrs", JSONArray().put(addr).toString())
                        v.put("addr", addr)
                        v.put("body", s(cur, "body"))
                        v.put("date", l(cur, "date"))
                        v.put("box", type)
                        v.put("status", l(cur, "status", -1).toInt())
                        v.put("sub", l(cur, "sub_id", -1).toInt())
                        v.put("deleted", stamp)
                        d.insert("trash", null, v)
                    }
                    d.setTransactionSuccessful()
                } finally {
                    d.endTransaction()
                }
            }
        } catch (_: Exception) {
        }
    }

    fun captureMms(c: Context, where: String?, args: Array<String>?, stamp: Long) {
        try {
            c.contentResolver.query(Uri.parse("content://mms"), null, where, args, null)?.use { cur ->
                val d = db(c)
                while (cur.moveToNext()) {
                    val mid = l(cur, "_id")
                    val box = l(cur, "msg_box").toInt()
                    val mtype = l(cur, "m_type").toInt()
                    if (box == 3 || mtype == 130) continue // rascunho / notificação sem conteúdo
                    val raw = JSONArray()
                    var from = ""
                    val to = ArrayList<String>()
                    c.contentResolver.query(Uri.parse("content://mms/$mid/addr"), arrayOf("address", "type"), null, null, null)?.use { a ->
                        while (a.moveToNext()) {
                            val ad = a.getString(0) ?: continue
                            val t = a.getInt(1)
                            raw.put(JSONObject().put("a", ad).put("t", t))
                            if (ad == "insert-address-token") continue
                            if (t == 137 && from.isEmpty()) from = ad
                            if (t == 151) to.add(ad)
                        }
                    }
                    val peers = (if (box == 1) listOf(from) else to).filter { it.isNotEmpty() }.ifEmpty { listOf("desconhecido") }
                    val v = ContentValues()
                    v.put("kind", "m")
                    v.put("ckey", ckey(peers))
                    v.put("addrs", JSONArray(peers).toString())
                    v.put("addr", peers[0])
                    v.put("subject", s(cur, "sub"))
                    v.put("date", l(cur, "date") * 1000)
                    v.put("box", box)
                    v.put("mtype", mtype)
                    v.put("sub", l(cur, "sub_id", -1).toInt())
                    v.put("raw", raw.toString())
                    v.put("deleted", stamp)
                    val rid = d.insert("trash", null, v)
                    if (rid < 0) continue
                    val parts = JSONArray()
                    val body = StringBuilder()
                    c.contentResolver.query(
                        Uri.parse("content://mms/$mid/part"), arrayOf("_id", "ct", "name", "cl", "cid", "text"), null, null, null
                    )?.use { pc ->
                        var n = 0
                        while (pc.moveToNext()) {
                            val pid = pc.getLong(0)
                            val ct = pc.getString(1) ?: continue
                            if (ct == "application/smil") continue
                            val name = pc.getString(2) ?: pc.getString(3) ?: "anexo$pid"
                            val cid = pc.getString(4) ?: "<$name>"
                            if (ct.startsWith("text/plain")) {
                                val t = pc.getString(5) ?: ""
                                if (body.isNotEmpty()) body.append("\n")
                                body.append(t)
                                parts.put(JSONObject().put("ct", ct).put("name", name).put("cid", cid).put("text", t))
                            } else {
                                try {
                                    val f = File(dir(c, rid), "p${n++}")
                                    f.parentFile?.mkdirs()
                                    c.contentResolver.openInputStream(Uri.parse("content://mms/part/$pid"))?.use { ins ->
                                        f.outputStream().use { ins.copyTo(it) }
                                    }
                                    parts.put(JSONObject().put("ct", ct).put("name", name).put("cid", cid).put("file", f.name))
                                } catch (_: Exception) {
                                }
                            }
                        }
                    }
                    val u = ContentValues()
                    u.put("parts", parts.toString())
                    u.put("body", body.toString())
                    d.update("trash", u, "id=?", arrayOf(rid.toString()))
                }
            }
        } catch (_: Exception) {
        }
    }

    /** Desfaz a captura de um lote (quando a eliminação falhou). */
    fun dropBatch(c: Context, stamp: Long) {
        try {
            val ids = ArrayList<Long>()
            db(c).rawQuery("SELECT id FROM trash WHERE deleted=?", arrayOf(stamp.toString())).use { while (it.moveToNext()) ids.add(it.getLong(0)) }
            remove(c, ids)
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------ consulta
    private fun left(deleted: Long): Int {
        val ms = deleted + DAYS * DAY - System.currentTimeMillis()
        return ((ms + DAY - 1) / DAY).toInt().coerceIn(0, DAYS)
    }

    fun groups(c: Context): JSONArray {
        purge(c)
        val out = JSONArray()
        val d = db(c)
        d.rawQuery(
            "SELECT ckey, MIN(deleted), MAX(deleted), COUNT(*), addrs FROM trash GROUP BY ckey ORDER BY MAX(deleted) DESC", null
        ).use { cur ->
            while (cur.moveToNext()) {
                val key = cur.getString(0) ?: ""
                val addrs = try { JSONArray(cur.getString(4) ?: "[]") } catch (_: Exception) { JSONArray() }
                val list = (0 until addrs.length()).map { addrs.getString(it) }
                val name = list.joinToString(", ") { Contacts.name(c, it) ?: it }.ifEmpty { "Desconhecido" }
                var snip = ""
                d.rawQuery("SELECT body, subject, parts FROM trash WHERE ckey=? ORDER BY date DESC LIMIT 1", arrayOf(key)).use { r ->
                    if (r.moveToFirst()) {
                        snip = (r.getString(0) ?: "").ifEmpty { r.getString(1) ?: "" }
                        if (snip.isEmpty() && (r.getString(2) ?: "").length > 2) snip = "Multimédia"
                    }
                }
                out.put(
                    JSONObject().put("ckey", key).put("addrs", addrs).put("name", name)
                        .put("count", cur.getInt(3)).put("snippet", snip.take(80)).put("left", left(cur.getLong(1)))
                )
            }
        }
        return out
    }

    fun items(c: Context, ckey: String): JSONArray {
        val out = JSONArray()
        db(c).rawQuery(
            "SELECT id, kind, body, subject, date, box, deleted, parts FROM trash WHERE ckey=? ORDER BY date ASC", arrayOf(ckey)
        ).use { cur ->
            while (cur.moveToNext()) {
                val atts = JSONArray()
                try {
                    val p = JSONArray(cur.getString(7) ?: "[]")
                    for (i in 0 until p.length()) {
                        val o = p.getJSONObject(i)
                        if (o.has("file")) atts.put(JSONObject().put("ct", o.optString("ct")).put("name", o.optString("name")))
                    }
                } catch (_: Exception) {
                }
                out.put(
                    JSONObject().put("id", cur.getLong(0)).put("k", cur.getString(1)).put("body", cur.getString(2) ?: "")
                        .put("subject", cur.getString(3) ?: "").put("date", cur.getLong(4))
                        .put("dir", if (cur.getInt(5) == 1) "in" else "out").put("left", left(cur.getLong(6))).put("atts", atts)
                )
            }
        }
        return out
    }

    // ------------------------------------------------------------ restauro / remoção
    fun restore(c: Context, ids: List<Long>): Int {
        var n = 0
        for (id in ids) {
            try {
                if (restoreOne(c, id)) {
                    removeOne(c, id)
                    n++
                }
            } catch (_: Exception) {
            }
        }
        Events.emit("changed")
        return n
    }

    private fun restoreOne(c: Context, id: Long): Boolean {
        db(c).rawQuery("SELECT * FROM trash WHERE id=?", arrayOf(id.toString())).use { cur ->
            if (!cur.moveToFirst()) return false
            val box = l(cur, "box").toInt()
            if (s(cur, "kind") == "s") {
                val v = ContentValues()
                v.put(Telephony.Sms.ADDRESS, s(cur, "addr"))
                v.put(Telephony.Sms.BODY, s(cur, "body"))
                v.put(Telephony.Sms.DATE, l(cur, "date"))
                v.put(Telephony.Sms.DATE_SENT, l(cur, "date"))
                v.put(Telephony.Sms.TYPE, if (box in 1..6) box else 1)
                v.put(Telephony.Sms.STATUS, l(cur, "status", -1).toInt())
                v.put(Telephony.Sms.READ, 1)
                v.put(Telephony.Sms.SEEN, 1)
                val sub = l(cur, "sub", -1).toInt()
                if (sub >= 0) v.put(Telephony.Sms.SUBSCRIPTION_ID, sub)
                return c.contentResolver.insert(Uri.parse("content://sms"), v) != null
            }
            // MMS
            val addrsJ = JSONArray(s(cur, "addrs"))
            val addrs = (0 until addrsJ.length()).map { addrsJ.getString(it) }.toSet()
            val tid = Telephony.Threads.getOrCreateThreadId(c, addrs)
            val parts = try { JSONArray(s(cur, "parts")) } catch (_: Exception) { JSONArray() }
            var size = 0L
            val datas = ArrayList<Triple<JSONObject, ByteArray, Boolean>>()
            for (i in 0 until parts.length()) {
                val o = parts.getJSONObject(i)
                if (o.has("file")) {
                    val f = File(dir(c, id), o.getString("file"))
                    val b = if (f.exists()) f.readBytes() else ByteArray(0)
                    size += b.size
                    datas.add(Triple(o, b, false))
                } else {
                    val b = o.optString("text").toByteArray(Charsets.UTF_8)
                    size += b.size
                    datas.add(Triple(o, b, true))
                }
            }
            val v = ContentValues()
            v.put("thread_id", tid)
            v.put("date", l(cur, "date") / 1000)
            v.put("msg_box", if (box in 1..5) box else 1)
            v.put("read", 1)
            v.put("seen", 1)
            val mt = l(cur, "mtype").toInt()
            v.put("m_type", if (mt > 0) mt else if (box == 1) 132 else 128)
            v.put("v", 18)
            val sub = s(cur, "subject")
            if (sub.isNotEmpty()) { v.put("sub", sub); v.put("sub_cs", 106) }
            v.put("ct_t", "application/vnd.wap.multipart.related")
            v.put("m_cls", "personal")
            v.put("m_size", size)
            v.put("tr_id", "R" + java.lang.Long.toHexString(System.currentTimeMillis()))
            val su = l(cur, "sub", -1).toInt()
            if (su >= 0) v.put("sub_id", su)
            val uri = c.contentResolver.insert(Uri.parse("content://mms"), v) ?: return false
            val mid = android.content.ContentUris.parseId(uri)
            val raw = try { JSONArray(s(cur, "raw")) } catch (_: Exception) { JSONArray() }
            for (i in 0 until raw.length()) {
                val o = raw.getJSONObject(i)
                val av = ContentValues()
                av.put("address", o.getString("a"))
                av.put("type", o.getInt("t"))
                av.put("charset", 106)
                av.put("msg_id", mid)
                try { c.contentResolver.insert(Uri.parse("content://mms/$mid/addr"), av) } catch (_: Exception) {}
            }
            for ((o, b, _) in datas) {
                MmsStore.insertPart(c, mid, o.optString("ct"), o.optString("name"), o.optString("cid", "<${o.optString("name")}>"), b)
            }
            return true
        }
    }

    private fun removeOne(c: Context, id: Long) {
        try { db(c).delete("trash", "id=?", arrayOf(id.toString())) } catch (_: Exception) {}
        try { dir(c, id).deleteRecursively() } catch (_: Exception) {}
    }

    fun remove(c: Context, ids: List<Long>): Int {
        ids.forEach { removeOne(c, it) }
        return ids.size
    }

    fun empty(c: Context): Int {
        val ids = ArrayList<Long>()
        db(c).rawQuery("SELECT id FROM trash", null).use { while (it.moveToNext()) ids.add(it.getLong(0)) }
        return remove(c, ids)
    }

    /** Apaga para sempre tudo o que está no lixo há mais de 30 dias. */
    fun purge(c: Context) {
        try {
            val cutoff = System.currentTimeMillis() - DAYS * DAY
            val ids = ArrayList<Long>()
            db(c).rawQuery("SELECT id FROM trash WHERE deleted<?", arrayOf(cutoff.toString())).use { while (it.moveToNext()) ids.add(it.getLong(0)) }
            remove(c, ids)
        } catch (_: Exception) {
        }
    }
}

/** Proteção opcional do lixo: PIN, senha ou padrão. Só guarda um hash com sal (PBKDF2). */
object TrashLock {
    @Volatile var unlocked = false
    private fun p(c: Context) = c.applicationContext.getSharedPreferences("chats_lock", Context.MODE_PRIVATE)
    fun type(c: Context): String = p(c).getString("type", "") ?: ""
    fun lockNow() { unlocked = false }

    private fun hash(secret: String, salt: ByteArray): String {
        val spec = PBEKeySpec(secret.toCharArray(), salt, 30_000, 256)
        val k = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded
        return Base64.encodeToString(k, Base64.NO_WRAP)
    }

    fun require(c: Context) {
        if (type(c).isNotEmpty() && !unlocked) throw Exception("O lixo está bloqueado.")
    }

    fun set(c: Context, type: String, secret: String) {
        if (type(c).isNotEmpty() && !unlocked) throw Exception("Desbloqueie o lixo primeiro.")
        val ok = when (type) {
            "pin" -> secret.length in 4..8 && secret.all { it.isDigit() }
            "password" -> secret.length in 4..64
            "pattern" -> secret.length in 4..9 && secret.all { it in '0'..'8' } && secret.toSet().size == secret.length
            else -> false
        }
        if (!ok) throw Exception("Proteção inválida.")
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p(c).edit().putString("type", type).putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", hash(secret, salt)).putInt("fails", 0).putLong("until", 0).apply()
        unlocked = true
    }

    fun check(c: Context, secret: String): JSONObject {
        val sp = p(c)
        val now = System.currentTimeMillis()
        val until = sp.getLong("until", 0)
        if (now < until) return JSONObject().put("ok", false).put("wait", ((until - now + 999) / 1000).toInt())
        val salt = Base64.decode(sp.getString("salt", "") ?: "", Base64.NO_WRAP)
        val good = MessageDigest.isEqual(
            hash(secret, salt).toByteArray(), (sp.getString("hash", "") ?: "").toByteArray()
        )
        if (good) {
            sp.edit().putInt("fails", 0).putLong("until", 0).apply()
            unlocked = true
            return JSONObject().put("ok", true)
        }
        val f = sp.getInt("fails", 0) + 1
        val e = sp.edit().putInt("fails", f)
        var wait = 0
        if (f >= 5) {
            wait = minOf(300, 30 * (f - 4))
            e.putLong("until", now + wait * 1000L)
        }
        e.apply()
        return JSONObject().put("ok", false).put("wait", wait)
    }

    fun clear(c: Context, secret: String): Boolean {
        val r = check(c, secret)
        if (!r.optBoolean("ok")) return false
        p(c).edit().clear().apply()
        unlocked = false
        return true
    }
}
