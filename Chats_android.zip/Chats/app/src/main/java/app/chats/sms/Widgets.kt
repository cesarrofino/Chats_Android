package app.chats.sms

import android.Manifest
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View
import android.widget.RemoteViews
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import java.util.concurrent.atomic.AtomicBoolean

/** Widget do ecrã inicial e atalhos do launcher (conversas recentes, "Nova mensagem" e partilha direta). */
object Widgets {
    const val ACTION_NEW = "app.chats.sms.NEW_MESSAGE"
    const val SHARE_CATEGORY = "app.chats.sms.category.SHARE_TARGET"
    private const val MAX_SHORTCUTS = 6

    private val busy = AtomicBoolean(false)
    @Volatile private var again = false
    @Volatile private var shortcutSig = ""

    fun canRead(c: Context) =
        c.checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

    /** Mesma cor para o mesmo contacto no widget e nos atalhos. */
    fun color(seed: String): Int {
        val hue = ((seed.hashCode() and 0x7fffffff) % 360).toFloat()
        return Color.HSVToColor(floatArrayOf(hue, 0.55f, 0.78f))
    }

    fun initial(name: String): String {
        val ch = name.trim().firstOrNull { it.isLetterOrDigit() } ?: return "#"
        return if (ch.isDigit()) "#" else ch.uppercaseChar().toString()
    }

    /** Contador de não lidas no cabeçalho do widget. */
    fun header(c: Context, rv: RemoteViews) {
        val n = try { if (canRead(c)) Messages.totalUnread(c) else 0 } catch (_: Throwable) { 0 }
        if (n > 0) {
            rv.setTextViewText(R.id.w_badge, if (n > 99) "99+" else n.toString())
            rv.setViewVisibility(R.id.w_badge, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.w_badge, View.GONE)
        }
    }

    /** Chamar fora da thread principal. Pedidos que chegam durante uma atualização são agrupados. */
    fun refresh(c: Context) {
        if (!busy.compareAndSet(false, true)) { again = true; return }
        try {
            do {
                again = false
                try { refreshWidgets(c) } catch (_: Throwable) {}
                try { updateShortcuts(c) } catch (_: Throwable) {}
            } while (again)
        } finally {
            busy.set(false)
        }
    }

    private fun refreshWidgets(c: Context) {
        val m = AppWidgetManager.getInstance(c)
        val ids = m.getAppWidgetIds(ComponentName(c, ChatsWidget::class.java))
        if (ids.isEmpty()) return
        val rv = RemoteViews(c.packageName, R.layout.widget_chats)
        header(c, rv)
        m.partiallyUpdateAppWidget(ids, rv)
        m.notifyAppWidgetViewDataChanged(ids, R.id.w_list)
    }

    private fun avatarIcon(name: String, seed: String): IconCompat {
        val s = 216
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.drawColor(color(seed))
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = s * 0.34f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        cv.drawText(initial(name), s / 2f, s / 2f - (p.descent() + p.ascent()) / 2f, p)
        return IconCompat.createWithAdaptiveBitmap(bmp)
    }

    /** Atalhos dinâmicos: as conversas mais recentes (também aparecem na partilha direta). */
    private fun updateShortcuts(c: Context) {
        if (!canRead(c)) return
        val arr = Messages.threads(c, MAX_SHORTCUTS)
        val sig = StringBuilder()
        val list = ArrayList<ShortcutInfoCompat>()
        for (i in 0 until arr.length()) {
            val t = arr.getJSONObject(i)
            val id = t.getLong("id")
            val name = t.optString("name").ifBlank { "Chats" }
            val seed = t.optJSONArray("addrs")?.optString(0)?.ifEmpty { null } ?: name
            sig.append(id).append(':').append(name).append(';')
            val intent = Intent(c, MainActivity::class.java)
                .setAction(Intent.ACTION_VIEW)
                .putExtra("thread", id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            list.add(
                ShortcutInfoCompat.Builder(c, "t$id")
                    .setShortLabel(name.take(24))
                    .setLongLabel(name.take(60))
                    .setIcon(avatarIcon(name, seed))
                    .setIntent(intent)
                    .setCategories(setOf(SHARE_CATEGORY))
                    .setLongLived(true)
                    .setRank(i)
                    .build()
            )
        }
        val s = sig.toString()
        if (s == shortcutSig) return
        shortcutSig = s
        ShortcutManagerCompat.setDynamicShortcuts(c, list)
    }
}
