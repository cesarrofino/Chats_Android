package app.chats.sms

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Atualizações pelos Releases do GitHub: procura a última versão, transfere o APK e abre o instalador. */
object Updater {
    /** Repositório GitHub com os Releases, no formato "dono/repositório". Altere para o seu. */
    const val REPO = "OWNER/REPO"

    private fun apkFile(c: Context) = File(File(c.cacheDir, "updates"), "Chats-update.apk")

    fun current(c: Context): String =
        try { c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: "0" } catch (e: Exception) { "0" }

    private fun parts(v: String): List<Int> =
        v.trim().removePrefix("v").removePrefix("V").split('-', '+')[0].split('.')
            .map { it.filter(Char::isDigit).toIntOrNull() ?: 0 }

    private fun newer(latest: String, cur: String): Boolean {
        val a = parts(latest)
        val b = parts(cur)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    private fun open(u: String): HttpURLConnection {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Chats-Android")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        return c
    }

    fun check(c: Context): JSONObject {
        if (REPO.startsWith("OWNER")) throw Exception("O repositório de atualizações ainda não está configurado.")
        val cur = current(c)
        try {
            val conn = open("https://api.github.com/repos/$REPO/releases/latest")
            val code = conn.responseCode
            if (code == 404) return JSONObject().put("current", cur).put("available", false).put("none", true)
            if (code != 200) throw Exception("O GitHub respondeu com o erro $code.")
            val j = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val tag = j.optString("tag_name", "").trim()
            val latest = tag.removePrefix("v").removePrefix("V")
            var url = ""
            var size = 0L
            val assets = j.optJSONArray("assets")
            if (assets != null) for (i in 0 until assets.length()) {
                val o = assets.getJSONObject(i)
                if (o.optString("name").endsWith(".apk", true)) {
                    url = o.optString("browser_download_url"); size = o.optLong("size"); break
                }
            }
            val isNew = latest.isNotEmpty() && newer(latest, cur)
            if (isNew && url.isEmpty()) throw Exception("A versão $latest não tem ficheiro APK nos Releases.")
            return JSONObject().put("current", cur).put("latest", latest).put("available", isNew)
                .put("notes", j.optString("body", "")).put("size", size).put("url", url)
        } catch (e: IOException) {
            throw Exception("Sem ligação à internet.")
        }
    }

    fun download(c: Context, url: String, onProgress: (Int) -> Unit) {
        val host = try { URL(url).host.lowercase() } catch (e: Exception) { "" }
        if (!url.startsWith("https://") || !(host == "github.com" || host.endsWith(".github.com") || host.endsWith(".githubusercontent.com")))
            throw Exception("Endereço de transferência inválido.")
        val dir = File(c.cacheDir, "updates")
        dir.mkdirs()
        dir.listFiles()?.forEach { it.delete() }
        val tmp = File(dir, "download.part")
        try {
            val conn = open(url)
            conn.setRequestProperty("Accept", "application/octet-stream")
            if (conn.responseCode != 200) throw Exception("Não foi possível transferir a atualização (${conn.responseCode}).")
            val total = conn.contentLengthLong
            var done = 0L
            var last = -1
            conn.inputStream.use { ins ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val p = (done * 100 / total).toInt()
                            if (p != last) { last = p; onProgress(p) }
                        }
                    }
                }
            }
        } catch (e: IOException) {
            tmp.delete()
            throw Exception("A transferência falhou. Verifique a ligação à internet.")
        }
        val f = apkFile(c)
        tmp.renameTo(f)
        val info = c.packageManager.getPackageArchiveInfo(f.path, 0)
        val code = if (info == null) -1L else if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
        val now = try {
            val p = c.packageManager.getPackageInfo(c.packageName, 0)
            if (Build.VERSION.SDK_INT >= 28) p.longVersionCode else p.versionCode.toLong()
        } catch (e: Exception) { 0L }
        if (info == null || info.packageName != c.packageName || code <= now) {
            f.delete()
            throw Exception("O ficheiro transferido não é uma atualização válida do Chats.")
        }
        onProgress(100)
    }

    /** Devolve "ok" quando abre o instalador, ou "perm" quando falta permitir instalar apps desconhecidas. */
    fun install(c: Context): String {
        val f = apkFile(c)
        if (!f.exists()) throw Exception("O ficheiro da atualização não foi encontrado.")
        if (Build.VERSION.SDK_INT >= 26 && !c.packageManager.canRequestPackageInstalls()) {
            c.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${c.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "perm"
        }
        val uri = FileProvider.getUriForFile(c, c.packageName + ".files", f)
        c.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return "ok"
    }
}
