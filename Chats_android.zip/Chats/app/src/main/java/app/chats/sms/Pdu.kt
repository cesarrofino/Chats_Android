package app.chats.sms

import java.io.ByteArrayOutputStream

/** Codificação e leitura mínima de PDUs MMS (OMA MMS 1.2) — m-send-req, m-notification-ind, m-retrieve-conf. */
object Pdu {
    class Part(val ct: String, val name: String, val data: ByteArray, val cid: String = "<$name>")
    class SendReq(val to: List<String>, val subject: String?, val parts: List<Part>)
    class Notif(val tid: String?, val location: String?, val size: Long, val from: String?, val subject: String?)
    class RPart(val ct: String, val name: String, val cid: String?, val data: ByteArray, val charset: String?)
    class Retr(val from: String?, val subject: String?, val date: Long, val parts: List<RPart>)

    // ---------------- Escrita ----------------
    private fun ByteArrayOutputStream.uintvar(v: Int) {
        var value = v
        val tmp = ArrayList<Int>()
        tmp.add(value and 0x7F)
        value = value ushr 7
        while (value > 0) {
            tmp.add((value and 0x7F) or 0x80)
            value = value ushr 7
        }
        for (i in tmp.indices.reversed()) write(tmp[i])
    }

    private fun ByteArrayOutputStream.str(s: String) {
        write(s.toByteArray(Charsets.UTF_8))
        write(0)
    }

    private fun ByteArrayOutputStream.valueLen(n: Int) {
        if (n < 31) write(n) else {
            write(31)
            uintvar(n)
        }
    }

    private fun encAddr(a: String): String {
        val t = a.trim()
        if (t.contains("@")) return t
        val clean = t.filter { it.isDigit() || it == '+' }
        return "$clean/TYPE=PLMN"
    }

    fun build(req: SendReq, smil: String?): ByteArray {
        val o = ByteArrayOutputStream()
        o.write(0x8C); o.write(0x80)                                  // m-send-req
        o.write(0x98); o.str("T" + java.lang.Long.toHexString(System.currentTimeMillis()))
        o.write(0x8D); o.write(0x92)                                  // MMS 1.2
        val now = System.currentTimeMillis() / 1000
        o.write(0x85); o.write(4)                                     // Date (long-integer)
        o.write(((now shr 24) and 0xFF).toInt()); o.write(((now shr 16) and 0xFF).toInt())
        o.write(((now shr 8) and 0xFF).toInt()); o.write((now and 0xFF).toInt())
        o.write(0x89); o.write(1); o.write(0x81)                      // From: insert-address-token
        for (t in req.to) {
            o.write(0x97); o.str(encAddr(t))
        }
        val subj = req.subject
        if (!subj.isNullOrEmpty()) {
            val sb = subj.toByteArray(Charsets.UTF_8)
            o.write(0x96); o.valueLen(sb.size + 2); o.write(0xEA); o.write(sb); o.write(0)
        }
        o.write(0x8A); o.write(0x80)                                  // class: personal
        o.write(0x8F); o.write(0x81)                                  // priority: normal
        o.write(0x90); o.write(0x81)                                  // read-reply: no
        o.write(0x86); o.write(0x81)                                  // delivery-report: no
        o.write(0x84); o.write(0xB3)                                  // multipart/related

        val parts = ArrayList<Part>()
        if (smil != null) parts.add(Part("application/smil", "smil.xml", smil.toByteArray(Charsets.UTF_8), "<smil>"))
        parts.addAll(req.parts)
        o.uintvar(parts.size)
        for (p in parts) {
            val h = ByteArrayOutputStream()
            val textual = p.ct.startsWith("text/") || p.ct == "application/smil"
            if (textual) {
                val ctb = ByteArrayOutputStream()
                ctb.str(p.ct); ctb.write(0x81); ctb.write(0xEA)       // charset=UTF-8
                h.valueLen(ctb.size()); h.write(ctb.toByteArray())
            } else {
                h.str(p.ct)
            }
            h.write(0x8E); h.str(p.name)                              // Content-Location
            h.write(0xC0); h.write(0x22); h.str(p.cid)                // Content-ID
            o.uintvar(h.size()); o.uintvar(p.data.size)
            o.write(h.toByteArray()); o.write(p.data)
        }
        return o.toByteArray()
    }

    // ---------------- Leitura ----------------
    private class Rd(val b: ByteArray) {
        var p = 0
        fun eof() = p >= b.size
        fun peek(): Int = b[p].toInt() and 0xFF
        fun u8(): Int = b[p++].toInt() and 0xFF
        fun uintvar(): Int {
            var v = 0
            while (true) {
                val x = u8()
                v = (v shl 7) or (x and 0x7F)
                if ((x and 0x80) == 0) return v
            }
        }

        fun text(): String {
            if (peek() == 0x7F || peek() == 0x22) p++
            val s = p
            while (p < b.size && b[p] != 0.toByte()) p++
            val r = String(b, s, p - s, Charsets.UTF_8)
            p++
            return r
        }

        fun valueLen(): Int {
            val x = u8()
            return if (x < 31) x else uintvar()
        }

        fun skipValue() {
            val x = peek()
            when {
                x < 31 -> { p++; p += x }
                x == 31 -> { p++; val n = uintvar(); p += n }
                x >= 128 -> p++
                else -> { while (p < b.size && b[p] != 0.toByte()) p++; p++ }
            }
        }

        fun intVal(): Long {
            val x = peek()
            if (x >= 128) { p++; return (x and 0x7F).toLong() }
            if (x in 1..30) {
                p++
                var v = 0L
                repeat(x) { v = (v shl 8) or u8().toLong() }
                return v
            }
            p++
            return 0
        }

        fun bytes(n: Int): ByteArray {
            val end = minOf(p + n, b.size)
            val r = b.copyOfRange(minOf(p, end), end)
            p += n
            return r
        }
    }

    private fun readFrom(r: Rd): String? {
        val n = r.valueLen()
        val end = r.p + n
        var res: String? = null
        if (n > 0 && r.peek() == 0x80) {
            r.p++
            res = r.text().substringBefore("/TYPE")
        }
        r.p = end
        return res
    }

    private fun readSubject(r: Rd): String? {
        if (r.peek() < 32) {
            val n = r.valueLen()
            val end = r.p + n
            if (n > 0 && r.peek() >= 0x80) r.p++
            val s = if (r.p < end) r.text() else ""
            r.p = end
            return s
        }
        return r.text()
    }

    private fun wk(code: Int): String = when (code) {
        0x03 -> "text/plain"
        0x06 -> "text/x-vCalendar"
        0x07 -> "text/x-vCard"
        0x1D -> "image/gif"
        0x1E -> "image/jpeg"
        0x20 -> "image/png"
        0x23 -> "application/vnd.wap.multipart.mixed"
        0x28 -> "text/xml"
        0x33 -> "application/vnd.wap.multipart.related"
        else -> "application/octet-stream"
    }

    private fun csName(code: Int): String? = when (code) {
        106 -> "UTF-8"
        4 -> "ISO-8859-1"
        3 -> "US-ASCII"
        else -> null
    }

    private fun ctBody(r: Rd, end: Int): Pair<String, String?> {
        val mime = if (r.peek() >= 128) wk(r.u8() and 0x7F) else r.text()
        var cs: String? = null
        try {
            while (r.p < end) {
                val code = r.u8()
                if (code == 0x81) {
                    val v = r.peek()
                    if (v >= 128) { r.p++; cs = csName(v and 0x7F) } else r.skipValue()
                } else r.skipValue()
            }
        } catch (_: Exception) {
        }
        r.p = end
        return Pair(mime, cs)
    }

    private fun readCt(r: Rd): Pair<String, String?> {
        val x = r.peek()
        if (x >= 128) { r.p++; return Pair(wk(x and 0x7F), null) }
        if (x < 31) { r.p++; return ctBody(r, r.p + x) }
        if (x == 31) { r.p++; val n = r.uintvar(); return ctBody(r, r.p + n) }
        return Pair(r.text(), null)
    }

    fun parseNotification(b: ByteArray): Notif? {
        val r = Rd(b)
        var type = 0
        var tid: String? = null
        var loc: String? = null
        var size = 0L
        var from: String? = null
        var subj: String? = null
        try {
            while (!r.eof()) {
                when (r.u8()) {
                    0x8C -> type = r.u8()
                    0x98 -> tid = r.text()
                    0x83 -> loc = r.text()
                    0x8E -> size = r.intVal()
                    0x89 -> from = readFrom(r)
                    0x96 -> subj = readSubject(r)
                    else -> r.skipValue()
                }
            }
        } catch (_: Exception) {
        }
        if (type != 0x82 || loc == null) return null
        return Notif(tid, loc, size, from, subj)
    }

    fun parseRetrieve(b: ByteArray): Retr? {
        val r = Rd(b)
        var type = 0
        var from: String? = null
        var subj: String? = null
        var date = 0L
        val parts = ArrayList<RPart>()
        try {
            loop@ while (!r.eof()) {
                when (r.u8()) {
                    0x8C -> type = r.u8()
                    0x85 -> date = r.intVal()
                    0x89 -> from = readFrom(r)
                    0x96 -> subj = readSubject(r)
                    0x84 -> { readCt(r); break@loop }
                    else -> r.skipValue()
                }
            }
            if (type != 0x84) return null
            val n = r.uintvar()
            for (i in 0 until n) {
                val hl = r.uintvar()
                val dl = r.uintvar()
                val hs = r.p
                val (mime, cs) = readCt(r)
                var name: String? = null
                var cid: String? = null
                try {
                    while (r.p < hs + hl) {
                        when (r.u8()) {
                            0x8E -> name = r.text()
                            0xC0 -> cid = r.text()
                            else -> r.skipValue()
                        }
                    }
                } catch (_: Exception) {
                }
                r.p = hs + hl
                val data = r.bytes(dl)
                val ext = when {
                    mime == "image/jpeg" -> ".jpg"
                    mime == "image/png" -> ".png"
                    mime == "image/gif" -> ".gif"
                    mime == "text/plain" -> ".txt"
                    mime.startsWith("video/") -> ".mp4"
                    mime.startsWith("audio/") -> ".amr"
                    else -> ""
                }
                parts.add(RPart(mime, name ?: ("anexo$i$ext"), cid, data, cs))
            }
        } catch (_: Exception) {
        }
        if (type != 0x84) return null
        return Retr(from, subj, date, parts)
    }
}
