package app.chats.sms

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Canal simples Kotlin -> JavaScript. */
object Events {
    @Volatile var sink: ((String, String) -> Unit)? = null
    @Volatile var pending: JSONObject? = null
    fun emit(name: String, data: String = "{}") {
        sink?.invoke(name, data)
    }
}

/** Preferências locais. As definições da interface são um único JSON gerido pelo JavaScript. */
object Store {
    private fun p(c: Context) = c.applicationContext.getSharedPreferences("chats", Context.MODE_PRIVATE)

    fun settings(c: Context): JSONObject = try {
        JSONObject(p(c).getString("settings", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    fun saveSettings(c: Context, json: String) {
        val o = JSONObject(json)
        p(c).edit().putString("settings", o.toString()).apply()
    }

    fun bool(c: Context, key: String, def: Boolean) = settings(c).optBoolean(key, def)
    fun str(c: Context, key: String, def: String) = settings(c).optString(key, def)

    fun isMuted(c: Context, threadId: Long): Boolean {
        val a = settings(c).optJSONArray("muted") ?: return false
        for (i in 0 until a.length()) if (a.optLong(i) == threadId) return true
        return false
    }

    fun scheduled(c: Context): JSONArray = try {
        JSONArray(p(c).getString("scheduled", "[]") ?: "[]")
    } catch (e: Exception) {
        JSONArray()
    }

    fun saveScheduled(c: Context, a: JSONArray) {
        p(c).edit().putString("scheduled", a.toString()).apply()
    }

    private fun failedSet(c: Context): MutableSet<String> =
        HashSet(p(c).getStringSet("dl_failed", emptySet()) ?: emptySet())

    fun dlFailed(c: Context): Set<String> = failedSet(c)
    fun setDlFailed(c: Context, id: Long, failed: Boolean) {
        val s = failedSet(c)
        if (failed) s.add(id.toString()) else s.remove(id.toString())
        p(c).edit().putStringSet("dl_failed", s).apply()
    }
}
