package app.chats.sms

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.Telephony
import org.json.JSONArray
import org.json.JSONObject

/** Leitura e gestão das conversas no armazenamento de mensagens do Android. */
object Messages {
    private val SMS: Uri = Telephony.Sms.CONTENT_URI
    private val MMS: Uri = Telephony.Mms.CONTENT_URI

    private fun str(cur: Cursor, n: String): String? {
        val i = cur.getColumnIndex(n)
        return if (i >= 0 && !cur.isNull(i)) cur.getString(i) else null
    }

    private fun lng(cur: Cursor, n: String, d: Long = 0L): Long {
        val i = cur.getColumnIndex(n)
        return if (i >= 0 && !cur.isNull(i)) cur.getLong(i) else d
    }

    private fun canonical(c: Context): Map<Long, String> {
        val m = HashMap<Long, String>()
        try {
            c.contentResolver.query(Uri.parse("content://mms-sms/canonical-addresses"), null, null, null, null)
                ?.use { cur ->
                    while (cur.moveToNext()) m[lng(cur, "_id")] = str(cur, "address") ?: ""
                }
        } catch (_: Exception) {
        }
        return m
    }

    private fun unreadCounts(c: Context): Map<Long, Int> {
        val m = HashMap<Long, Int>()
        fun q(uri: Uri, sel: String) {
            try {
                c.contentResolver.query(uri, arrayOf("thread_id"), sel, null, null)?.use { cur ->
                    while (cur.moveToNext()) {
                        val t = cur.getLong(0)
                        m[t] = (m[t] ?: 0) + 1
                    }
                }
            } catch (_: Exception) {
            }
        }
        q(SMS, "read=0 AND type=1")
        q(MMS, "read=0 AND msg_box=1")
        return m
    }

    /** Total de mensagens por abrir (conversas, desconhecidos e serviços). */
    fun totalUnread(c: Context): Int = unreadCounts(c).values.sum()

    /** Conversas cuja mensagem mais recente (enviada por nós) falhou, com a data da falha. */
    private fun failedLast(c: Context): Map<Long, Long> {
        val m = HashMap<Long, Long>()
        fun q(uri: Uri, sel: String, mul: Long) {
            try {
                c.contentResolver.query(uri, arrayOf("thread_id", "date"), sel, null, null)?.use { cur ->
                    while (cur.moveToNext()) {
                        val t = cur.getLong(0)
                        val d = cur.getLong(1) * mul
                        if (d > (m[t] ?: 0L)) m[t] = d
                    }
                }
            } catch (_: Exception) {
            }
        }
        q(SMS, "type=5", 1L)
        q(MMS, "msg_box=5", 1000L)
        return m
    }

    /** Últimas mensagens por abrir de uma conversa (para a notificação). */
    fun recentUnread(c: Context, thread: Long, limit: Int = 5): List<Triple<String, Long, String>> {
        val l = ArrayList<Triple<String, Long, String>>()
        try {
            c.contentResolver.query(
                SMS, arrayOf("body", "date", "address"), "thread_id=? AND type=1 AND read=0",
                arrayOf(thread.toString()), "date DESC LIMIT $limit"
            )?.use { cur ->
                while (cur.moveToNext()) l.add(Triple(cur.getString(0) ?: "", cur.getLong(1), cur.getString(2) ?: ""))
            }
        } catch (_: Exception) {
        }
        l.reverse()
        return l
    }

    @Volatile var lastUnread = 0

    fun threads(c: Context): JSONArray {
        Contacts.warm(c)
        val canon = canonical(c)
        val unread = unreadCounts(c)
        lastUnread = unread.values.sum()
        val failed = failedLast(c)
        val out = JSONArray()
        c.contentResolver.query(
            Uri.parse("content://mms-sms/conversations?simple=true"), null, null, null, "date DESC"
        )?.use { cur ->
            while (cur.moveToNext()) {
                val id = lng(cur, "_id")
                val count = lng(cur, "message_count")
                if (count <= 0L) continue
                val rids = (str(cur, "recipient_ids") ?: "").split(" ").filter { it.isNotBlank() }
                val addrs = rids.mapNotNull { canon[it.toLongOrNull() ?: -1L] }.filter { it.isNotEmpty() }
                val names = addrs.map { Contacts.name(c, it) ?: it }
                var snippet = str(cur, "snippet") ?: ""
                val hasAtt = lng(cur, "has_attachment") != 0L
                if (snippet.isBlank() && hasAtt) snippet = "\uD83D\uDCCE Multimédia"
                val o = JSONObject()
                o.put("id", id)
                o.put("addrs", JSONArray(addrs))
                o.put("name", if (names.isEmpty()) "Sem destinatário" else names.joinToString(", "))
                o.put("known", addrs.isNotEmpty() && addrs.all { Contacts.name(c, it) != null })
                o.put("snippet", snippet)
                o.put("date", lng(cur, "date"))
                o.put("read", lng(cur, "read", 1) != 0L)
                o.put("unread", unread[id] ?: 0)
                o.put("count", count)
                val tdate = lng(cur, "date")
                val fd = failed[id] ?: 0L
                // Só mostra "Falhou" se a mensagem mais recente da conversa é a que falhou.
                o.put("error", fd > 0L && fd + 2000L >= tdate)
                o.put("att", hasAtt)
                out.put(o)
            }
        }
        return out
    }

    fun threadIdFor(c: Context, addrs: List<String>): Long =
        Telephony.Threads.getOrCreateThreadId(c, addrs.toSet())

    fun messages(c: Context, thread: Long, limit: Int = 400): JSONArray {
        val list = ArrayList<JSONObject>()
        val failedDl = Store.dlFailed(c)
        // SMS
        c.contentResolver.query(SMS, null, "thread_id=?", arrayOf(thread.toString()), "date DESC LIMIT $limit")
            ?.use { cur ->
                while (cur.moveToNext()) {
                    val type = lng(cur, "type").toInt()
                    if (type == 3) continue // rascunho
                    val status = lng(cur, "status", -1).toInt()
                    val o = JSONObject()
                    o.put("k", "s")
                    o.put("id", lng(cur, "_id"))
                    o.put("addr", str(cur, "address") ?: "")
                    o.put("body", str(cur, "body") ?: "")
                    o.put("date", lng(cur, "date"))
                    o.put("dateSent", lng(cur, "date_sent"))
                    o.put("read", lng(cur, "read", 1) != 0L)
                    o.put("sub", lng(cur, "sub_id", -1))
                    o.put("dir", if (type == 1) "in" else "out")
                    o.put(
                        "st", when (type) {
                            1 -> "received"
                            4, 6 -> "sending"
                            5 -> "failed"
                            else -> when {
                                status == 0 -> "delivered"
                                status >= 64 -> "undelivered"
                                else -> "sent"
                            }
                        }
                    )
                    o.put("err", lng(cur, "error_code"))
                    list.add(o)
                }
            }
        // MMS
        try {
            c.contentResolver.query(MMS, null, "thread_id=?", arrayOf(thread.toString()), "date DESC LIMIT $limit")
                ?.use { cur ->
                    while (cur.moveToNext()) {
                        val box = lng(cur, "msg_box").toInt()
                        if (box == 3) continue
                        val id = lng(cur, "_id")
                        val mtype = lng(cur, "m_type").toInt()
                        val o = JSONObject()
                        o.put("k", "m")
                        o.put("id", id)
                        o.put("date", lng(cur, "date") * 1000)
                        o.put("dateSent", lng(cur, "date_sent") * 1000)
                        o.put("read", lng(cur, "read", 1) != 0L)
                        o.put("sub", lng(cur, "sub_id", -1))
                        o.put("subject", str(cur, "sub") ?: "")
                        o.put("size", lng(cur, "m_size"))
                        o.put("dir", if (box == 1) "in" else "out")
                        val pending = mtype == 130
                        o.put(
                            "st", when {
                                pending -> if (failedDl.contains(id.toString())) "dlfailed"
                                else if (Mms.downloading.contains(id)) "downloading" else "nodownload"
                                box == 1 -> "received"
                                box == 4 -> "sending"
                                box == 5 -> "failed"
                                else -> "sent"
                            }
                        )
                        o.put("addr", mmsSender(c, id))
                        val parts = JSONArray()
                        var body = StringBuilder()
                        if (!pending) {
                            c.contentResolver.query(
                                Uri.parse("content://mms/$id/part"),
                                arrayOf("_id", "ct", "name", "cl", "text"), null, null, null
                            )?.use { pc ->
                                while (pc.moveToNext()) {
                                    val ct = pc.getString(1) ?: continue
                                    if (ct == "application/smil") continue
                                    if (ct.startsWith("text/plain")) {
                                        if (body.isNotEmpty()) body.append("\n")
                                        body.append(pc.getString(4) ?: "")
                                    } else {
                                        parts.put(
                                            JSONObject().put("id", pc.getLong(0)).put("ct", ct)
                                                .put("name", pc.getString(2) ?: pc.getString(3) ?: "anexo")
                                        )
                                    }
                                }
                            }
                        }
                        o.put("body", body.toString())
                        o.put("parts", parts)
                        list.add(o)
                    }
                }
        } catch (_: Exception) {
        }
        list.sortBy { it.optLong("date") }
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        return arr
    }

    private fun mmsSender(c: Context, id: Long): String {
        try {
            c.contentResolver.query(Uri.parse("content://mms/$id/addr"), arrayOf("address", "type"), null, null, null)
                ?.use { cur ->
                    while (cur.moveToNext()) if (cur.getInt(1) == 137) return cur.getString(0) ?: ""
                }
        } catch (_: Exception) {
        }
        return ""
    }

    fun markRead(c: Context, thread: Long, read: Boolean): Boolean {
        val arg = arrayOf(thread.toString())
        try {
            if (read) {
                val v = ContentValues()
                v.put("read", 1)
                v.put("seen", 1)
                c.contentResolver.update(SMS, v, "thread_id=? AND read=0", arg)
                try {
                    c.contentResolver.update(MMS, v, "thread_id=? AND read=0", arg)
                } catch (_: Exception) {
                }
            } else {
                val v = ContentValues()
                v.put("read", 0)
                var done = false
                c.contentResolver.query(SMS, arrayOf("_id"), "thread_id=? AND type=1", arg, "date DESC LIMIT 1")
                    ?.use { cur ->
                        if (cur.moveToFirst()) {
                            c.contentResolver.update(Uri.parse("content://sms/${cur.getLong(0)}"), v, null, null)
                            done = true
                        }
                    }
                if (!done) {
                    c.contentResolver.query(MMS, arrayOf("_id"), "thread_id=? AND msg_box=1", arg, "date DESC LIMIT 1")
                        ?.use { cur ->
                            if (cur.moveToFirst()) {
                                c.contentResolver.update(Uri.parse("content://mms/${cur.getLong(0)}"), v, null, null)
                            }
                        }
                }
            }
            Notifier.badge(c)
            return true
        } catch (e: SecurityException) {
            return false
        } catch (e: Exception) {
            return false
        }
    }

    fun deleteThreads(c: Context, ids: List<Long>): Int {
        var n = 0
        for (id in ids) {
            n += c.contentResolver.delete(Uri.parse("content://mms-sms/conversations/$id"), null, null)
        }
        return n
    }

    fun deleteMessage(c: Context, kind: String, id: Long): Int {
        val u = if (kind == "m") Uri.parse("content://mms/$id") else Uri.parse("content://sms/$id")
        return c.contentResolver.delete(u, null, null)
    }

    fun search(c: Context, q: String): JSONArray {
        val out = JSONArray()
        val canon = canonical(c)
        val like = "%" + q.replace("%", "").replace("_", "") + "%"
        try {
            c.contentResolver.query(
                SMS, arrayOf("_id", "thread_id", "address", "body", "date", "type"),
                "body LIKE ?", arrayOf(like), "date DESC LIMIT 80"
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val addr = cur.getString(2) ?: ""
                    out.put(
                        JSONObject().put("k", "s").put("id", cur.getLong(0)).put("thread", cur.getLong(1))
                            .put("addr", addr).put("name", Contacts.name(c, addr) ?: addr)
                            .put("body", cur.getString(3) ?: "").put("date", cur.getLong(4))
                    )
                }
            }
        } catch (_: Exception) {
        }
        try {
            c.contentResolver.query(
                Uri.parse("content://mms/part"), arrayOf("mid", "text"),
                "ct='text/plain' AND text LIKE ?", arrayOf(like), "mid DESC LIMIT 40"
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val mid = cur.getLong(0)
                    c.contentResolver.query(
                        Uri.parse("content://mms/$mid"), arrayOf("thread_id", "date"), null, null, null
                    )?.use { mc ->
                        if (mc.moveToFirst()) {
                            val addr = mmsSender(c, mid)
                            out.put(
                                JSONObject().put("k", "m").put("id", mid).put("thread", mc.getLong(0))
                                    .put("addr", addr).put("name", Contacts.name(c, addr) ?: addr)
                                    .put("body", cur.getString(1) ?: "").put("date", mc.getLong(1) * 1000)
                            )
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun counts(c: Context): JSONObject {
        fun count(uri: Uri): Int = try {
            c.contentResolver.query(uri, arrayOf("_id"), null, null, null)?.use { it.count } ?: 0
        } catch (e: Exception) {
            0
        }
        return JSONObject().put("sms", count(SMS)).put("mms", count(MMS))
    }

    fun deleteOlderThan(c: Context, days: Int): Int {
        val cutoff = System.currentTimeMillis() - days * 86_400_000L
        var n = 0
        try { n += c.contentResolver.delete(SMS, "date < ?", arrayOf(cutoff.toString())) } catch (_: Exception) {}
        try { n += c.contentResolver.delete(MMS, "date < ?", arrayOf((cutoff / 1000).toString())) } catch (_: Exception) {}
        return n
    }
}
