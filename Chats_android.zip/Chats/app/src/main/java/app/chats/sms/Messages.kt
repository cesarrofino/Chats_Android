package app.chats.sms

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.Telephony
import org.json.JSONArray
import org.json.JSONObject

/** Leitura e gestão das conversas no armazenamento de mensagens do Android. */
object Messages {
    private val SMS: Uri = Telephony.Sms.CONTENT_URI
    private val MMS: Uri = Telephony.Mms.CONTENT_URI

    private fun str(cur: Cursor, n: String): String? {
        val i = cur.getColumnIndex(n)
        return if (i >= 0 && !cur.isNull(i)) cur.getString(i) else null
    }

    private fun lng(cur: Cursor, n: String, d: Long = 0L): Long {
        val i = cur.getColumnIndex(n)
        return if (i >= 0 && !cur.isNull(i)) cur.getLong(i) else d
    }

    private fun canonical(c: Context): Map<Long, String> {
        val m = HashMap<Long, String>()
        try {
            c.contentResolver.query(Uri.parse("content://mms-sms/canonical-addresses"), null, null, null, null)
                ?.use { cur ->
                    while (cur.moveToNext()) m[lng(cur, "_id")] = str(cur, "address") ?: ""
                }
        } catch (_: Exception) {
        }
        return m
    }

    private fun unreadCounts(c: Context): Map<Long, Int> {
        val m = HashMap<Long, Int>()
        fun q(uri: Uri, sel: String) {
            try {
                c.contentResolver.query(uri, arrayOf("thread_id"), sel, null, null)?.use { cur ->
                    while (cur.moveToNext()) {
                        val t = cur.getLong(0)
                        m[t] = (m[t] ?: 0) + 1
                    }
                }
            } catch (_: Exception) {
            }
        }
        q(SMS, "read=0 AND type=1")
        q(MMS, "read=0 AND msg_box=1")
        return m
    }

    /** Total de mensagens por abrir (conversas, desconhecidos e serviços). */
    fun totalUnread(c: Context): Int = unreadCounts(c).values.sum()

    /** Conversas cuja mensagem mais recente (enviada por nós) falhou, com a data da falha. */
    private fun failedLast(c: Context): Map<Long, Long> {
        val m = HashMap<Long, Long>()
        fun q(uri: Uri, sel: String, mul: Long) {
            try {
                c.contentResolver.query(uri, arrayOf("thread_id", "date"), sel, null, null)?.use { cur ->
                    while (cur.moveToNext()) {
                        val t = cur.getLong(0)
                        val d = cur.getLong(1) * mul
                        if (d > (m[t] ?: 0L)) m[t] = d
                    }
                }
            } catch (_: Exception) {
            }
        }
        q(SMS, "type=5", 1L)
        q(MMS, "msg_box=5", 1000L)
        return m
    }

    /** Últimas mensagens por abrir de uma conversa (para a notificação). */
    fun recentUnread(c: Context, thread: Long, limit: Int = 5): List<Triple<String, Long, String>> {
        val l = ArrayList<Triple<String, Long, String>>()
        try {
            c.contentResolver.query(
                SMS, arrayOf("body", "date", "address"), "thread_id=? AND type=1 AND read=0",
                arrayOf(thread.toString()), "date DESC LIMIT $limit"
            )?.use { cur ->
                while (cur.moveToNext()) l.add(Triple(cur.getString(0) ?: "", cur.getLong(1), cur.getString(2) ?: ""))
            }
        } catch (_: Exception) {
        }
        l.reverse()
        return l
    }

    /** Últimas mensagens SMS (recebidas e enviadas) de uma conversa, da mais antiga para a mais recente: (texto, data, enviada?). */
    fun recent(c: Context, thread: Long, limit: Int = 6): List<Triple<String, Long, Boolean>> {
        val l = ArrayList<Triple<String, Long, Boolean>>()
        try {
            c.contentResolver.query(
                SMS, arrayOf("body", "date", "type"), "thread_id=? AND type IN (1,2,4,5,6)",
                arrayOf(thread.toString()), "date DESC LIMIT $limit"
            )?.use { cur ->
                while (cur.moveToNext()) l.add(Triple(cur.getString(0) ?: "", cur.getLong(1), cur.getInt(2) != 1))
            }
        } catch (_: Exception) {
        }
        l.reverse()
        return l
    }

    class Rec(val id: Long, val body: String, val date: Long, val mine: Boolean, val failed: Boolean)

    /** Como [recent], mas com o id e o estado "falhou" (tipo 5) de cada SMS. */
    fun recentRecs(c: Context, thread: Long, limit: Int = 6): List<Rec> {
        val l = ArrayList<Rec>()
        try {
            c.contentResolver.query(
                SMS, arrayOf("_id", "body", "date", "type"), "thread_id=? AND type IN (1,2,4,5,6)",
                arrayOf(thread.toString()), "date DESC LIMIT $limit"
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val t = cur.getInt(3)
                    l.add(Rec(cur.getLong(0), cur.getString(1) ?: "", cur.getLong(2), t != 1, t == 5))
                }
            }
        } catch (_: Exception) {
        }
        l.reverse()
        return l
    }


    /** Texto da pré-visualização quando a última mensagem só tem anexos: diz o que foi enviado. */
    fun mediaLabel(c: Context, thread: Long): String {
        val cts = ArrayList<String>()
        try {
            var mid = -1L
            c.contentResolver.query(Uri.parse("content://mms"), arrayOf("_id"), "thread_id=?", arrayOf(thread.toString()), "date DESC LIMIT 1")
                ?.use { if (it.moveToFirst()) mid = it.getLong(0) }
            if (mid >= 0L) {
                c.contentResolver.query(Uri.parse("content://mms/part"), arrayOf("ct"), "mid=?", arrayOf(mid.toString()), "_id ASC")
                    ?.use { while (it.moveToNext()) cts.add((it.getString(0) ?: "").lowercase()) }
            }
        } catch (_: Exception) {
        }
        return labelFor(cts)
    }

    fun labelFor(all: List<String>): String {
        val l = all.filter { it.isNotEmpty() && it != "application/smil" && !it.startsWith("text/plain") }
        if (l.isEmpty()) return "\uD83D\uDCCE Anexo"
        fun kind(ct: String) = when {
            ct == "image/gif" -> "gif"
            ct.startsWith("image/") -> "foto"
            ct.startsWith("video/") -> "video"
            ct.startsWith("audio/") || ct == "application/ogg" -> "audio"
            ct.contains("vcard") -> "contacto"
            ct == "application/pdf" -> "pdf"
            else -> "ficheiro"
        }
        val kinds = l.map { kind(it) }
        val k = kinds.first()
        val n = kinds.size
        if (kinds.any { it != k }) return "\uD83D\uDCCE $n anexos"
        return when (k) {
            "foto" -> if (n == 1) "\uD83D\uDCF7 Foto" else "\uD83D\uDCF7 $n fotos"
            "gif" -> "\uD83D\uDDBC GIF"
            "video" -> if (n == 1) "\uD83C\uDFA5 Vídeo" else "\uD83C\uDFA5 $n vídeos"
            "audio" -> if (n == 1) "\uD83C\uDFA4 Áudio" else "\uD83C\uDFA4 $n áudios"
            "contacto" -> "\uD83D\uDC64 Contacto"
            "pdf" -> "\uD83D\uDCC4 PDF"
            else -> if (n == 1) "\uD83D\uDCCE Ficheiro" else "\uD83D\uDCCE $n ficheiros"
        }
    }

    @Volatile var lastUnread = 0

    fun threads(c: Context): JSONArray {
        Contacts.warm(c)
        val canon = canonical(c)
        val unread = unreadCounts(c)
        lastUnread = unread.values.sum()
        val failed = failedLast(c)
        val out = JSONArray()
        c.contentResolver.query(
            Uri.parse("content://mms-sms/conversations?simple=true"), null, null, null, "date DESC"
        )?.use { cur ->
            while (cur.moveToNext()) {
                val id = lng(cur, "_id")
                val count = lng(cur, "message_count")
                if (count <= 0L) continue
                val rids = (str(cur, "recipient_ids") ?: "").split(" ").filter { it.isNotBlank() }
                val addrs = rids.mapNotNull { canon[it.toLongOrNull() ?: -1L] }.filter { it.isNotEmpty() }
                val names = addrs.map { Contacts.name(c, it) ?: it }
                var snippet = str(cur, "snippet") ?: ""
                val hasAtt = lng(cur, "has_attachment") != 0L
                if (snippet.isBlank() && hasAtt) snippet = mediaLabel(c, id)
                val o = JSONObject()
                o.put("id", id)
                o.put("addrs", JSONArray(addrs))
                o.put("name", if (names.isEmpty()) "Sem destinatário" else names.joinToString(", "))
                o.put("known", addrs.isNotEmpty() && addrs.all { Contacts.name(c, it) != null })
                o.put("snippet", snippet)
                o.put("date", lng(cur, "date"))
                o.put("read", lng(cur, "read", 1) != 0L)
                o.put("unread", unread[id] ?: 0)
                o.put("count", count)
                val tdate = lng(cur, "date")
                val fd = failed[id] ?: 0L
                // Só mostra "Falhou" se a mensagem mais recente da conversa é a que falhou.
                o.put("error", fd > 0L && fd + 2000L >= tdate)
                o.put("att", hasAtt)
                out.put(o)
            }
        }
        return out
    }

    fun threadIdFor(c: Context, addrs: List<String>): Long =
        Telephony.Threads.getOrCreateThreadId(c, addrs.toSet())

    private val senderCache = java.util.concurrent.ConcurrentHashMap<Long, String>()

    fun messages(c: Context, thread: Long, limit: Int = 400): JSONArray {
        val list = ArrayList<JSONObject>()
        val failedDl = Store.dlFailed(c)
        val pendingIds = HashSet<Long>()
        // SMS
        c.contentResolver.query(SMS, null, "thread_id=?", arrayOf(thread.toString()), "date DESC LIMIT $limit")
            ?.use { cur ->
                while (cur.moveToNext()) {
                    val type = lng(cur, "type").toInt()
                    if (type == 3) continue // rascunho
                    val status = lng(cur, "status", -1).toInt()
                    val o = JSONObject()
                    o.put("k", "s")
                    o.put("id", lng(cur, "_id"))
                    o.put("addr", str(cur, "address") ?: "")
                    o.put("body", str(cur, "body") ?: "")
                    o.put("date", lng(cur, "date"))
                    o.put("dateSent", lng(cur, "date_sent"))
                    o.put("read", lng(cur, "read", 1) != 0L)
                    o.put("sub", lng(cur, "sub_id", -1))
                    o.put("dir", if (type == 1) "in" else "out")
                    o.put(
                        "st", when (type) {
                            1 -> "received"
                            4, 6 -> when {
                                status == 0 -> "delivered"
                                // sem aviso de envio ao fim de 30 s (mas sem falha): já não mostra "A enviar"
                                System.currentTimeMillis() - lng(cur, "date") > 30_000 -> "sent"
                                else -> "sending"
                            }
                            5 -> "failed"
                            else -> when {
                                status == 0 -> "delivered"
                                status >= 64 -> "undelivered"
                                else -> "sent"
                            }
                        }
                    )
                    o.put("err", lng(cur, "error_code"))
                    list.add(o)
                }
            }
        // MMS (só os dados da mensagem; partes e remetente são carregados depois, só para as que vão aparecer)
        try {
            c.contentResolver.query(MMS, null, "thread_id=?", arrayOf(thread.toString()), "date DESC LIMIT $limit")
                ?.use { cur ->
                    while (cur.moveToNext()) {
                        val box = lng(cur, "msg_box").toInt()
                        if (box == 3) continue
                        val id = lng(cur, "_id")
                        val mtype = lng(cur, "m_type").toInt()
                        val o = JSONObject()
                        o.put("k", "m")
                        o.put("id", id)
                        o.put("date", lng(cur, "date") * 1000)
                        o.put("dateSent", lng(cur, "date_sent") * 1000)
                        o.put("read", lng(cur, "read", 1) != 0L)
                        o.put("sub", lng(cur, "sub_id", -1))
                        o.put("subject", str(cur, "sub") ?: "")
                        o.put("size", lng(cur, "m_size"))
                        o.put("dir", if (box == 1) "in" else "out")
                        val pending = mtype == 130
                        if (pending) pendingIds.add(id)
                        o.put(
                            "st", when {
                                pending -> if (failedDl.contains(id.toString())) "dlfailed"
                                else if (Mms.downloading.contains(id)) "downloading" else "nodownload"
                                box == 1 -> "received"
                                box == 4 -> "sending"
                                box == 5 -> "failed"
                                else -> "sent"
                            }
                        )
                        o.put("addr", "")
                        o.put("body", "")
                        o.put("parts", JSONArray())
                        list.add(o)
                    }
                }
        } catch (_: Exception) {
        }
        list.sortBy { it.optLong("date") }
        // Só as mais recentes (antes podiam vir até 2x o limite)
        val shown: List<JSONObject> = if (list.size > limit) list.subList(list.size - limit, list.size) else list
        // Partes dos MMS visíveis: consultas em lote (em vez de uma por mensagem)
        val mmsList = shown.filter { it.optString("k") == "m" }
        val partIds = mmsList.filter { !pendingIds.contains(it.optLong("id")) }.map { it.optLong("id") }
        val partsBy = HashMap<Long, JSONArray>()
        val bodyBy = HashMap<Long, StringBuilder>()
        fun addPart(mid: Long, pc: Cursor) {
            val ct = pc.getString(pc.getColumnIndexOrThrow("ct")) ?: return
            if (ct == "application/smil") return
            if (ct.startsWith("text/plain")) {
                val sb = bodyBy.getOrPut(mid) { StringBuilder() }
                if (sb.isNotEmpty()) sb.append("\n")
                sb.append(pc.getString(pc.getColumnIndexOrThrow("text")) ?: "")
            } else {
                partsBy.getOrPut(mid) { JSONArray() }.put(
                    JSONObject().put("id", pc.getLong(pc.getColumnIndexOrThrow("_id"))).put("ct", ct)
                        .put("name", pc.getString(pc.getColumnIndexOrThrow("name")) ?: pc.getString(pc.getColumnIndexOrThrow("cl")) ?: "anexo")
                )
            }
        }
        var batchOk = true
        try {
            for (chunk in partIds.chunked(100)) {
                c.contentResolver.query(
                    Uri.parse("content://mms/part"), arrayOf("_id", "mid", "ct", "name", "cl", "text"),
                    "mid IN (" + chunk.joinToString(",") + ")", null, "_id ASC"
                )?.use { pc ->
                    val mi = pc.getColumnIndexOrThrow("mid")
                    while (pc.moveToNext()) addPart(pc.getLong(mi), pc)
                }
            }
        } catch (_: Exception) {
            batchOk = false
        }
        if (!batchOk) {
            // Alternativa (mais lenta) caso o fornecedor não aceite a consulta em lote
            partsBy.clear(); bodyBy.clear()
            for (id in partIds) {
                try {
                    c.contentResolver.query(
                        Uri.parse("content://mms/$id/part"), arrayOf("_id", "ct", "name", "cl", "text"), null, null, null
                    )?.use { pc ->
                        while (pc.moveToNext()) addPart(id, pc)
                    }
                } catch (_: Exception) {
                }
            }
        }
        for (o in mmsList) {
            val id = o.optLong("id")
            o.put("body", bodyBy[id]?.toString() ?: "")
            o.put("parts", partsBy[id] ?: JSONArray())
            if (o.optString("dir") == "in") o.put("addr", mmsSender(c, id))
        }
        val arr = JSONArray()
        shown.forEach { arr.put(it) }
        return arr
    }

    private fun mmsSender(c: Context, id: Long): String {
        senderCache[id]?.let { return it }
        try {
            c.contentResolver.query(Uri.parse("content://mms/$id/addr"), arrayOf("address", "type"), null, null, null)
                ?.use { cur ->
                    while (cur.moveToNext()) if (cur.getInt(1) == 137) {
                        val a = cur.getString(0) ?: ""
                        if (a.isNotEmpty()) senderCache[id] = a
                        return a
                    }
                }
        } catch (_: Exception) {
        }
        return ""
    }

    fun markRead(c: Context, thread: Long, read: Boolean): Boolean {
        val arg = arrayOf(thread.toString())
        try {
            if (read) {
                val v = ContentValues()
                v.put("read", 1)
                v.put("seen", 1)
                c.contentResolver.update(SMS, v, "thread_id=? AND read=0", arg)
                try {
                    c.contentResolver.update(MMS, v, "thread_id=? AND read=0", arg)
                } catch (_: Exception) {
                }
            } else {
                val v = ContentValues()
                v.put("read", 0)
                var done = false
                c.contentResolver.query(SMS, arrayOf("_id"), "thread_id=? AND type=1", arg, "date DESC LIMIT 1")
                    ?.use { cur ->
                        if (cur.moveToFirst()) {
                            c.contentResolver.update(Uri.parse("content://sms/${cur.getLong(0)}"), v, null, null)
                            done = true
                        }
                    }
                if (!done) {
                    c.contentResolver.query(MMS, arrayOf("_id"), "thread_id=? AND msg_box=1", arg, "date DESC LIMIT 1")
                        ?.use { cur ->
                            if (cur.moveToFirst()) {
                                c.contentResolver.update(Uri.parse("content://mms/${cur.getLong(0)}"), v, null, null)
                            }
                        }
                }
            }
            Notifier.badge(c)
            return true
        } catch (e: SecurityException) {
            return false
        } catch (e: Exception) {
            return false
        }
    }

    fun deleteThreads(c: Context, ids: List<Long>): Int {
        var n = 0
        val stamp = System.currentTimeMillis()
        for (id in ids) {
            Trash.captureThread(c, id, stamp)
            n += c.contentResolver.delete(Uri.parse("content://mms-sms/conversations/$id"), null, null)
        }
        if (n == 0) Trash.dropBatch(c, stamp)
        return n
    }

    fun deleteMessage(c: Context, kind: String, id: Long): Int {
        val stamp = System.currentTimeMillis()
        Trash.captureMessage(c, kind, id, stamp)
        val u = if (kind == "m") Uri.parse("content://mms/$id") else Uri.parse("content://sms/$id")
        val n = c.contentResolver.delete(u, null, null)
        if (n == 0) Trash.dropBatch(c, stamp)
        return n
    }

    fun search(c: Context, q: String): JSONArray {
        val out = JSONArray()
        val canon = canonical(c)
        val like = "%" + q.replace("%", "").replace("_", "") + "%"
        try {
            c.contentResolver.query(
                SMS, arrayOf("_id", "thread_id", "address", "body", "date", "type"),
                "body LIKE ?", arrayOf(like), "date DESC LIMIT 80"
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val addr = cur.getString(2) ?: ""
                    out.put(
                        JSONObject().put("k", "s").put("id", cur.getLong(0)).put("thread", cur.getLong(1))
                            .put("addr", addr).put("name", Contacts.name(c, addr) ?: addr)
                            .put("body", cur.getString(3) ?: "").put("date", cur.getLong(4))
                    )
                }
            }
        } catch (_: Exception) {
        }
        try {
            c.contentResolver.query(
                Uri.parse("content://mms/part"), arrayOf("mid", "text"),
                "ct='text/plain' AND text LIKE ?", arrayOf(like), "mid DESC LIMIT 40"
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val mid = cur.getLong(0)
                    c.contentResolver.query(
                        Uri.parse("content://mms/$mid"), arrayOf("thread_id", "date"), null, null, null
                    )?.use { mc ->
                        if (mc.moveToFirst()) {
                            val addr = mmsSender(c, mid)
                            out.put(
                                JSONObject().put("k", "m").put("id", mid).put("thread", mc.getLong(0))
                                    .put("addr", addr).put("name", Contacts.name(c, addr) ?: addr)
                                    .put("body", cur.getString(1) ?: "").put("date", mc.getLong(1) * 1000)
                            )
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun counts(c: Context): JSONObject {
        fun count(uri: Uri): Int = try {
            c.contentResolver.query(uri, arrayOf("_id"), null, null, null)?.use { it.count } ?: 0
        } catch (e: Exception) {
            0
        }
        return JSONObject().put("sms", count(SMS)).put("mms", count(MMS))
    }

    fun deleteOlderThan(c: Context, days: Int): Int {
        val cutoff = System.currentTimeMillis() - days * 86_400_000L
        var n = 0
        val stamp = System.currentTimeMillis()
        Trash.captureSms(c, "date < ?", arrayOf(cutoff.toString()), stamp)
        Trash.captureMms(c, "date < ?", arrayOf((cutoff / 1000).toString()), stamp)
        try { n += c.contentResolver.delete(SMS, "date < ?", arrayOf(cutoff.toString())) } catch (_: Exception) {}
        try { n += c.contentResolver.delete(MMS, "date < ?", arrayOf((cutoff / 1000).toString())) } catch (_: Exception) {}
        if (n == 0) Trash.dropBatch(c, stamp)
        return n
    }
}
