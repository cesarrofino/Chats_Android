package app.chats.sms

import android.animation.ValueAnimator
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import java.util.concurrent.Executors
import kotlin.math.hypot

/** Ponto de entrada do balão flutuante (chamado pelo Notifier, pelo MainActivity e pela resposta rápida). */
object Bubbles {
    /** true enquanto a interface principal está visível: nesse caso não há balão (já se vê a mensagem). */
    @Volatile var appVisible = false

    /** Precisa da permissão "Mostrar sobre outras aplicações". */
    fun canShow(c: Context): Boolean = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c)

    fun show(c: Context, thread: Long, address: String, name: String, body: String, hidden: Boolean) {
        if (!Store.bool(c, "bubble", true) || appVisible || !canShow(c)) return
        val app = c.applicationContext
        val s = BubbleService.inst
        if (s != null) {
            s.post { s.add(thread, address, name, body, hidden) }
            return
        }
        try {
            app.startService(
                Intent(app, BubbleService::class.java)
                    .putExtra("thread", thread).putExtra("addr", address).putExtra("name", name)
                    .putExtra("body", body).putExtra("hidden", hidden)
            )
        } catch (_: Throwable) {
            // O sistema não permitiu iniciar o serviço agora: fica só a notificação.
        }
    }

    fun remove(thread: Long) {
        val s = BubbleService.inst ?: return
        s.post { s.drop(thread) }
    }

    fun clearAll() {
        val s = BubbleService.inst ?: return
        s.post { s.dropAll() }
    }
}

/** Mantém os balões flutuantes (janelas sobrepostas). Pára sozinho quando já não há balões. */
class BubbleService : Service() {
    companion object {
        @Volatile var inst: BubbleService? = null
        private const val MAX = 5
    }

    private class Item(val thread: Long, val root: FrameLayout, val lp: WindowManager.LayoutParams) {
        var addr = ""
        var name = ""
        var body = ""
        var count = 0
        lateinit var badge: TextView
        lateinit var img: ImageView
    }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val items = LinkedHashMap<Long, Item>()
    private lateinit var wm: WindowManager
    private var zone: TextView? = null
    private var zoneHot = false

    private val dm get() = resources.displayMetrics
    private fun dp(v: Float) = (v * dm.density + 0.5f).toInt()
    private val size get() = dp(62f)
    private val box get() = dp(70f)

    fun post(r: Runnable) { main.post(r) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        inst = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null && intent.hasExtra("thread")) {
            val t = intent.getLongExtra("thread", -1L)
            val a = intent.getStringExtra("addr") ?: ""
            val n = intent.getStringExtra("name") ?: a
            val b = intent.getStringExtra("body") ?: ""
            val h = intent.getBooleanExtra("hidden", false)
            main.post { add(t, a, n, b, h) }
        } else if (items.isEmpty()) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        inst = null
        hideZone()
        for (it in items.values) try { wm.removeView(it.root) } catch (_: Throwable) {}
        items.clear()
        io.shutdownNow()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ ecrã
    private fun screenW() = dm.widthPixels
    private fun screenH() = dm.heightPixels
    private fun statusH(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(24f)
    }
    private fun navH(): Int {
        val id = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }
    private fun minY() = statusH()
    private fun maxY() = screenH() - navH() - box

    private fun prefs() = getSharedPreferences("bubbles", Context.MODE_PRIVATE)

    // ------------------------------------------------------------------ criar / atualizar
    fun add(thread: Long, addr: String, name: String, body: String, hidden: Boolean) {
        if (thread < 0) { stopIfEmpty(); return }
        val existing = items[thread]
        if (existing != null) {
            existing.addr = addr; existing.name = name; existing.body = body
            existing.count++
            refreshBadge(existing)
            existing.root.animate().cancel()
            existing.root.scaleX = 1f; existing.root.scaleY = 1f
            existing.root.animate().scaleX(1.18f).scaleY(1.18f).setDuration(110).withEndAction {
                existing.root.animate().scaleX(1f).scaleY(1f).setDuration(160).setInterpolator(OvershootInterpolator()).start()
            }.start()
            return
        }
        // Avatar fora da thread principal (consulta de contactos).
        io.execute {
            val bmp = try { Notifier.bubbleAvatar(applicationContext, addr, name, hidden) } catch (_: Throwable) { null }
            main.post { if (inst === this) create(thread, addr, name, body, bmp) }
        }
    }

    private fun create(thread: Long, addr: String, name: String, body: String, bmp: android.graphics.Bitmap?) {
        if (items.containsKey(thread)) { // outra mensagem chegou entretanto
            val e = items[thread]!!
            e.count++; refreshBadge(e); return
        }
        if (items.size >= MAX) items.keys.firstOrNull()?.let { drop(it, false) }

        val root = FrameLayout(this)
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        val ring = GradientDrawable()
        ring.shape = GradientDrawable.OVAL
        ring.setColor(Color.WHITE)
        ring.setStroke(dp(2.5f), Color.WHITE)
        val ivWrap = FrameLayout(this)
        ivWrap.background = ring
        ivWrap.setPadding(dp(2f), dp(2f), dp(2f), dp(2f))
        // Avatar circular (o bitmap já vem em círculo); sombra suave ao redor do aro.
        if (bmp != null) img.setImageBitmap(bmp) else img.setImageResource(R.mipmap.ic_launcher)
        ivWrap.addView(img, FrameLayout.LayoutParams(-1, -1))
        root.addView(ivWrap, FrameLayout.LayoutParams(size, size, Gravity.CENTER))

        val badge = TextView(this)
        badge.setTextColor(Color.WHITE)
        badge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        badge.typeface = Typeface.DEFAULT_BOLD
        badge.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.RECTANGLE
        bg.cornerRadius = dp(10f).toFloat()
        bg.setColor(0xFFE5392D.toInt())
        bg.setStroke(dp(1.5f), Color.WHITE)
        badge.background = bg
        badge.setPadding(dp(5f), 0, dp(5f), 0)
        root.addView(badge, FrameLayout.LayoutParams(-2, dp(20f), Gravity.TOP or Gravity.END).also {
            it.topMargin = dp(2f); it.rightMargin = dp(2f)
        })

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            box, box, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val p = prefs()
        val right = p.getBoolean("right", true)
        val yFrac = p.getFloat("y", 0.35f)
        lp.x = if (right) screenW() - box + dp(6f) else -dp(6f)
        lp.y = (yFrac * screenH()).toInt() + items.size * (box - dp(8f))
        lp.y = lp.y.coerceIn(minY(), maxOf(minY(), maxY()))

        val it = Item(thread, root, lp)
        it.addr = addr; it.name = name; it.body = body; it.count = 1
        it.badge = badge; it.img = img
        refreshBadge(it)
        attachTouch(it)
        try {
            wm.addView(root, lp)
        } catch (_: Throwable) {
            // Permissão revogada ou janela recusada: não há balão.
            stopIfEmpty()
            return
        }
        items[thread] = it
        root.scaleX = 0f; root.scaleY = 0f
        root.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(1.6f)).start()
    }

    private fun refreshBadge(it: Item) {
        it.badge.text = if (it.count > 99) "99+" else it.count.toString()
        it.badge.minWidth = dp(20f)
        it.badge.visibility = if (it.count > 1) View.VISIBLE else View.GONE
    }

    // ------------------------------------------------------------------ remover
    fun drop(thread: Long, stop: Boolean = true) {
        val it = items.remove(thread) ?: run { if (stop) stopIfEmpty(); return }
        it.root.animate().cancel()
        try { wm.removeView(it.root) } catch (_: Throwable) {}
        if (stop) stopIfEmpty()
    }

    fun dropAll() {
        for (k in items.keys.toList()) drop(k, false)
        stopIfEmpty()
    }

    private fun stopIfEmpty() {
        if (items.isEmpty()) stopSelf()
    }

    // ------------------------------------------------------------------ arrastar
    private fun showZone() {
        if (zone != null) return
        val z = TextView(this)
        z.text = "✕"
        z.setTextColor(Color.WHITE)
        z.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
        z.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(0xCC202124.toInt())
        bg.setStroke(dp(2f), 0x66FFFFFF)
        z.background = bg
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val d = dp(64f)
        val lp = WindowManager.LayoutParams(
            d, d, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (screenW() - d) / 2
        lp.y = screenH() - navH() - d - dp(40f)
        try { wm.addView(z, lp) } catch (_: Throwable) { return }
        zone = z
        zoneHot = false
        z.alpha = 0f
        z.animate().alpha(1f).setDuration(150).start()
    }

    private fun hideZone() {
        val z = zone ?: return
        zone = null
        zoneHot = false
        try { wm.removeView(z) } catch (_: Throwable) {}
    }

    /** Centro do alvo "remover" em píxeis de ecrã. */
    private fun zoneCx() = screenW() / 2
    private fun zoneCy() = screenH() - navH() - dp(40f) - dp(32f)

    private fun setHot(hot: Boolean) {
        val z = zone ?: return
        if (hot == zoneHot) return
        zoneHot = hot
        z.animate().scaleX(if (hot) 1.3f else 1f).scaleY(if (hot) 1.3f else 1f).setDuration(120).start()
    }

    @android.annotation.SuppressLint("ClickableViewAccessibility")
    private fun attachTouch(it: Item) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var dx = 0f; var dy = 0f
        var sx = 0; var sy = 0
        var drag = false
        it.root.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX; dy = e.rawY
                    sx = it.lp.x; sy = it.lp.y
                    drag = false
                    v.animate().cancel()
                    v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx
                    val my = e.rawY - dy
                    if (!drag && hypot(mx, my) > slop) {
                        drag = true
                        showZone()
                        v.animate().scaleX(1.08f).scaleY(1.08f).setDuration(80).start()
                    }
                    if (drag) {
                        it.lp.x = (sx + mx).toInt().coerceIn(-box / 3, screenW() - box + box / 3)
                        it.lp.y = (sy + my).toInt().coerceIn(minY(), maxOf(minY(), maxY()))
                        val cx = it.lp.x + box / 2
                        val cy = it.lp.y + box / 2
                        val near = hypot((cx - zoneCx()).toFloat(), (cy - zoneCy()).toFloat()) < dp(70f)
                        setHot(near)
                        if (near) { // "íman": cola ao alvo
                            it.lp.x = zoneCx() - box / 2
                            it.lp.y = zoneCy() - box / 2
                        }
                        try { wm.updateViewLayout(v, it.lp) } catch (_: Throwable) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    val hot = zoneHot
                    hideZone()
                    if (!drag) {
                        if (e.actionMasked == MotionEvent.ACTION_UP) openReply(it)
                    } else if (hot) {
                        drop(it.thread)
                    } else {
                        snap(it)
                    }
                    true
                }
                else -> false
            }
        }
    }

    /** Encosta o balão ao lado mais próximo e guarda a posição para os próximos. */
    private fun snap(it: Item) {
        val toRight = it.lp.x + box / 2 > screenW() / 2
        val target = if (toRight) screenW() - box + dp(6f) else -dp(6f)
        val from = it.lp.x
        val a = ValueAnimator.ofInt(from, target)
        a.duration = 220
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener { va ->
            if (!items.containsKey(it.thread)) { va.cancel(); return@addUpdateListener }
            it.lp.x = va.animatedValue as Int
            try { wm.updateViewLayout(it.root, it.lp) } catch (_: Throwable) {}
        }
        a.start()
        prefs().edit().putBoolean("right", toRight)
            .putFloat("y", (it.lp.y.toFloat() / screenH()).coerceIn(0f, 0.95f)).apply()
    }

    // ------------------------------------------------------------------ abrir resposta
    private fun openReply(it: Item) {
        val i = Intent(this, ReplyActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("thread", it.thread).putExtra("addr", it.addr).putExtra("name", it.name)
            .putExtra("body", it.body)
        try {
            startActivity(i)
            drop(it.thread)
        } catch (_: Throwable) {
            // Sem permissão para abrir por cima de outras apps: abre a conversa normal.
            try {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        .putExtra("thread", it.thread)
                )
                drop(it.thread)
            } catch (_: Throwable) {
            }
        }
    }
}
