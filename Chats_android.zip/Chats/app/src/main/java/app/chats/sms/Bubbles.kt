package app.chats.sms

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.hypot

/** Ponto de entrada do balão flutuante (chamado pelo Notifier, pelo MainActivity e pela resposta rápida). */
object Bubbles {
    /** Mantido por compatibilidade: o balão fica no ecrã mesmo com a app aberta (só sai ao arrastar para o ✕). */
    @Volatile var appVisible = false

    /** Precisa da permissão "Mostrar sobre outras aplicações". */
    fun canShow(c: Context): Boolean = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c)

    fun show(c: Context, thread: Long, address: String, name: String, body: String, hidden: Boolean) {
        if (!Store.bool(c, "bubble", true) || !canShow(c)) return
        val app = c.applicationContext
        val s = BubbleService.inst
        if (s != null) {
            s.post { s.add(thread, address, name, body, hidden) }
            return
        }
        try {
            app.startService(
                Intent(app, BubbleService::class.java)
                    .putExtra("thread", thread).putExtra("addr", address).putExtra("name", name)
                    .putExtra("body", body).putExtra("hidden", hidden)
            )
        } catch (_: Throwable) {
            // O sistema não permitiu iniciar o serviço agora: fica só a notificação.
        }
    }

    /** A mensagem foi vista (janela aberta, lida na app ou na notificação): apaga o ponto vermelho, mas o balão fica. */
    fun seen(thread: Long) {
        val s = BubbleService.inst ?: return
        s.post { s.markSeen(thread) }
    }

    /** Janela de resposta aberta: os balões sobem juntos para o topo (como separadores) e voltam à pilha quando ela fecha. */
    fun dock(thread: Long) {
        val s = BubbleService.inst ?: return
        s.post { s.dock(thread) }
    }

    fun undock(thread: Long) {
        val s = BubbleService.inst ?: return
        s.post { s.undock(thread) }
    }

    fun remove(thread: Long) {
        val s = BubbleService.inst ?: return
        s.post { s.drop(thread) }
    }

    fun clearAll() {
        val s = BubbleService.inst ?: return
        s.post { s.dropAll() }
    }
}

/**
 * Mantém os balões flutuantes numa só janela, em pilha: o balão da mensagem mais recente fica à frente e os
 * outros espreitam por trás. Ao tocar, a pilha sobe para o topo e cada balão passa a ser um separador para
 * navegar entre as conversas. A pilha só sai quando é arrastada para o ✕ (ou um separador é puxado para cima).
 */
class BubbleService : Service() {
    companion object {
        @Volatile var inst: BubbleService? = null
        private const val MAX = 6
        private const val PREVIEW_MS = 3800L
    }

    private class Item(val thread: Long, val cell: FrameLayout, val img: ImageView, val dot: TextView) {
        var addr = ""
        var name = ""
        var body = ""
        var hidden = false
        var count = 0
        var unread = false
        var pulse: ObjectAnimator? = null
    }

    private class T(val x: Float, val y: Float, val s: Float, val a: Float)

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val items = LinkedHashMap<Long, Item>()   // ordem de criação (ordem dos separadores no topo)
    private val order = ArrayList<Long>()              // 0 = mensagem mais recente (à frente da pilha)
    private lateinit var wm: WindowManager
    private var host: FrameLayout? = null
    private var hostLp: WindowManager.LayoutParams? = null
    private var underline: View? = null
    private var docked = false
    private var collapsing = false
    private var active = -1L
    private var savedX = 0
    private var savedY = 0
    private var anim: ValueAnimator? = null
    private var token = 0
    private var tx = 0
    private var ty = 0
    private var follow = false
    private var frame: android.view.Choreographer.FrameCallback? = null
    private var zone: FrameLayout? = null
    private var zoneCircle: View? = null
    private var zoneHot = false
    private var preview: View? = null
    private var previewRun: Runnable? = null
    private var tabDown: Item? = null
    private var tabX = 0f
    private var tabY = 0f

    private val dm get() = resources.displayMetrics
    private fun dp(v: Float) = (v * dm.density + 0.5f).toInt()
    private val size get() = dp(54f)           // diâmetro visível do balão
    private val box get() = dp(76f)            // janela: deixa espaço à sombra e às "folhas" da pilha
    private val inset get() = (box - size) / 2
    private val slop by lazy { ViewConfiguration.get(this).scaledTouchSlop }

    fun post(r: Runnable) { main.post(r) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        inst = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null && intent.hasExtra("thread")) {
            val t = intent.getLongExtra("thread", -1L)
            val a = intent.getStringExtra("addr") ?: ""
            val n = intent.getStringExtra("name") ?: a
            val b = intent.getStringExtra("body") ?: ""
            val h = intent.getBooleanExtra("hidden", false)
            main.post { add(t, a, n, b, h) }
        } else if (items.isEmpty()) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        inst = null
        for (v in items.values) { v.pulse?.cancel(); v.cell.animate().cancel() }
        removeHost()
        items.clear()
        order.clear()
        io.shutdownNow()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ ecrã
    private fun screenW() = dm.widthPixels
    private fun screenH() = dm.heightPixels
    private fun statusH(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(24f)
    }
    private fun navH(): Int {
        val id = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }
    private fun minY() = statusH() - inset
    private fun maxY() = screenH() - navH() - box + inset
    private fun minX() = -inset
    private fun maxX() = screenW() - box + inset
    private fun edgeX(right: Boolean) = if (right) maxX() - dp(6f) else minX() + dp(6f)
    private fun dockY() = statusH() + dp(4f) - inset

    private fun prefs() = getSharedPreferences("bubbles", Context.MODE_PRIVATE)

    private fun isDark(): Boolean = when (Store.str(this, "theme", "auto")) {
        "dark" -> true
        "light" -> false
        else -> (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
    }

    private fun overlayType() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    // ------------------------------------------------------------------ janela única
    private fun ensureHost(): Boolean {
        if (host != null) return true
        val h = FrameLayout(this)
        h.clipChildren = false
        h.clipToPadding = false

        // traço branco por baixo do separador ativo (janela de resposta aberta)
        val ul = View(this)
        val ubg = GradientDrawable()
        ubg.shape = GradientDrawable.RECTANGLE
        ubg.cornerRadius = dp(2f).toFloat()
        ubg.setColor(Color.WHITE)
        ul.background = ubg
        ul.visibility = View.GONE
        h.addView(ul, FrameLayout.LayoutParams(dp(24f), dp(3f), Gravity.TOP or Gravity.START))

        val lp = WindowManager.LayoutParams(
            box, box, overlayType(),
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val p = prefs()
        val right = p.getBoolean("right", true)
        val yFrac = p.getFloat("y", 0.35f)
        lp.x = edgeX(right)
        lp.y = (yFrac * screenH()).toInt().coerceIn(minY(), maxOf(minY(), maxY()))
        attachTouch(h)
        try {
            wm.addView(h, lp)
        } catch (_: Throwable) {
            return false // permissão revogada ou janela recusada
        }
        host = h
        hostLp = lp
        underline = ul
        return true
    }

    private fun removeHost() {
        anim?.cancel()
        anim = null
        token++
        stopFollow()
        hideZone()
        hidePreview()
        val h = host
        host = null
        hostLp = null
        underline = null
        docked = false
        collapsing = false
        active = -1L
        if (h != null) try { wm.removeView(h) } catch (_: Throwable) {}
    }

    // ------------------------------------------------------------------ criar / atualizar
    fun add(thread: Long, addr: String, name: String, body: String, hidden: Boolean) {
        if (thread < 0) { stopIfEmpty(); return }
        val e = items[thread]
        if (e != null) { receive(e, addr, name, body, hidden); return }
        // Avatar fora da thread principal (consulta de contactos).
        io.execute {
            val bmp = try { Notifier.bubbleAvatar(applicationContext, addr, name, hidden) } catch (_: Throwable) { null }
            main.post { if (inst === this) create(thread, addr, name, body, hidden, bmp) }
        }
    }

    /** Nova mensagem de uma conversa que já tem balão: sobe para a frente da pilha. */
    private fun receive(e: Item, addr: String, name: String, body: String, hidden: Boolean) {
        e.addr = addr; e.name = name; e.body = body; e.hidden = hidden
        val viewing = docked && active == e.thread
        if (!viewing) { e.count++; e.unread = true }
        if (!docked) {
            order.remove(e.thread)
            order.add(0, e.thread)
        }
        layoutCells(true)
        if (!docked && !collapsing) { bounce(); showPreview(e) }
    }

    private fun makeItem(thread: Long, bmp: Bitmap?): Item {
        val oval = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setOval(0, 0, v.width, v.height)
                o.setAlpha(1f)
            }
        }
        val cell = FrameLayout(this)
        cell.clipChildren = false
        cell.clipToPadding = false
        cell.elevation = dp(6f).toFloat()
        cell.outlineProvider = oval

        // Só o avatar: sem aros nem bordas coloridas.
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.outlineProvider = oval
        img.clipToOutline = true
        if (bmp != null) img.setImageBitmap(bmp) else img.setImageResource(R.mipmap.ic_launcher)
        cell.addView(img, FrameLayout.LayoutParams(-1, -1))

        // ponto vermelho de mensagem nova (com número quando há várias)
        val dot = TextView(this)
        dot.setTextColor(Color.WHITE)
        dot.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
        dot.typeface = Typeface.DEFAULT_BOLD
        dot.gravity = Gravity.CENTER
        val dbg = GradientDrawable()
        dbg.shape = GradientDrawable.RECTANGLE
        dbg.cornerRadius = dp(11f).toFloat()
        dbg.setColor(0xFFFF3B30.toInt())
        dbg.setStroke(dp(2f), Color.WHITE)
        dot.background = dbg
        dot.elevation = dp(4f).toFloat()
        val dlp = FrameLayout.LayoutParams(-2, dp(14f), Gravity.TOP or Gravity.END)
        dlp.topMargin = -dp(1f)
        dlp.rightMargin = -dp(2f)
        cell.addView(dot, dlp)
        dot.visibility = View.GONE
        return Item(thread, cell, img, dot)
    }

    private fun create(thread: Long, addr: String, name: String, body: String, hidden: Boolean, bmp: Bitmap?) {
        val ex = items[thread]
        if (ex != null) { receive(ex, addr, name, body, hidden); return } // outra mensagem chegou entretanto
        if (items.size >= MAX) order.lastOrNull()?.let { drop(it, false) }
        if (!ensureHost()) { stopIfEmpty(); return }
        val b = makeItem(thread, bmp)
        b.addr = addr; b.name = name; b.body = body; b.hidden = hidden
        b.count = 1; b.unread = true
        items[thread] = b
        order.add(0, thread)
        host!!.addView(b.cell, FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.START))
        val t = target(b, if (collapsing) savedX else 0)
        b.cell.translationX = t.x
        b.cell.translationY = t.y
        b.cell.scaleX = 0f
        b.cell.scaleY = 0f
        layoutCells(true)
        if (!docked) main.postDelayed({ if (items[thread] === b && !docked && !collapsing) showPreview(b) }, 380)
    }

    // ------------------------------------------------------------------ disposição
    /** Posição de cada balão: pilha (um à frente, dois a espreitar) ou fila de separadores no topo. */
    private fun target(b: Item, offX: Int): T {
        if (docked) {
            val n = items.size
            val idx = items.keys.indexOf(b.thread)
            val sp = if (n > 1) minOf(size + dp(12f), (screenW() - dp(32f) - size) / (n - 1)) else 0
            val total = size + (n - 1) * sp
            val start = (screenW() - total) / 2
            val act = b.thread == active
            return T((start + idx * sp).toFloat(), inset.toFloat(), if (act) 1f else 0.84f, if (act) 1f else 0.9f)
        }
        val k = order.indexOf(b.thread)
        val peek = floatArrayOf(0f, dp(6f).toFloat(), dp(11f).toFloat())
        val sc = floatArrayOf(1f, 0.92f, 0.84f)
        val x = offX + inset.toFloat()
        val y0 = inset - dp(4f).toFloat()
        return if (k in 0..2) T(x, y0 + peek[k], sc[k], 1f) else T(x, y0 + peek[2], 0.76f, 0f)
    }

    private fun layoutCells(animate: Boolean, offX0: Int = -1) {
        val h = host ?: return
        val offX = if (offX0 >= 0) offX0 else if (collapsing) savedX else 0
        val z = if (docked) items.values.toList() else order.mapNotNull { items[it] }.reversed()
        for (b in z) b.cell.bringToFront()
        for (b in items.values) {
            val t = target(b, offX)
            val rear = !docked && order.indexOf(b.thread) > 0
            if (rear) b.img.setColorFilter(PorterDuffColorFilter(0x59000000, PorterDuff.Mode.SRC_ATOP)) else b.img.clearColorFilter()
            if (animate) {
                b.cell.animate().translationX(t.x).translationY(t.y).scaleX(t.s).scaleY(t.s).alpha(t.a)
                    .setDuration(300).setInterpolator(OvershootInterpolator(0.9f)).start()
            } else {
                b.cell.animate().cancel()
                b.cell.translationX = t.x; b.cell.translationY = t.y
                b.cell.scaleX = t.s; b.cell.scaleY = t.s; b.cell.alpha = t.a
            }
        }
        val ul = underline
        val act = items[active]
        if (ul != null) {
            if (docked && act != null) {
                val t = target(act, 0)
                val ux = t.x + (size - dp(24f)) / 2f
                val uy = (inset + size + dp(3f)).toFloat()
                if (ul.visibility != View.VISIBLE || !animate) {
                    ul.animate().cancel()
                    ul.translationX = ux; ul.translationY = uy
                    ul.visibility = View.VISIBLE
                } else {
                    ul.animate().translationX(ux).translationY(uy).setDuration(260).start()
                }
            } else {
                ul.visibility = View.GONE
            }
        }
        refreshDots()
        h.requestLayout()
    }

    // ------------------------------------------------------------------ ponto vermelho
    private fun refreshDots() {
        val total = items.values.filter { it.unread }.sumOf { it.count }
        val front = if (docked) -1L else (order.firstOrNull() ?: -1L)
        for (b in items.values) {
            if (docked) setDot(b, b.unread, b.count)
            else setDot(b, b.thread == front && total > 0, total)
        }
    }

    private fun setDot(b: Item, show: Boolean, n: Int) {
        if (!show) {
            b.pulse?.cancel()
            b.pulse = null
            b.dot.scaleX = 1f; b.dot.scaleY = 1f
            b.dot.visibility = View.GONE
            return
        }
        b.dot.visibility = View.VISIBLE
        val many = n > 1
        b.dot.text = if (!many) "" else if (n > 99) "99+" else n.toString()
        b.dot.minWidth = dp(if (many) 20f else 14f)
        b.dot.setPadding(dp(if (many) 5f else 0f), 0, dp(if (many) 5f else 0f), 0)
        val lp = b.dot.layoutParams as FrameLayout.LayoutParams
        lp.height = dp(if (many) 20f else 14f)
        b.dot.layoutParams = lp
        if (b.pulse == null) {
            val a = ObjectAnimator.ofPropertyValuesHolder(
                b.dot,
                PropertyValuesHolder.ofFloat("scaleX", 1f, 1.22f),
                PropertyValuesHolder.ofFloat("scaleY", 1f, 1.22f)
            )
            a.duration = 800
            a.repeatMode = ValueAnimator.REVERSE
            a.repeatCount = ValueAnimator.INFINITE
            a.start()
            b.pulse = a
        }
    }

    fun markSeen(thread: Long) {
        val b = items[thread] ?: return
        b.count = 0
        b.unread = false
        refreshDots()
    }

    private fun moveTo(
        x: Int, y: Int, ms: Long,
        ip: android.view.animation.Interpolator = DecelerateInterpolator(1.6f),
        end: (() -> Unit)? = null
    ) {
        val h = host ?: return
        val lp = hostLp ?: return
        val my = ++token
        anim?.cancel()
        val fx = lp.x
        val fy = lp.y
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = ms
        a.interpolator = ip
        a.addUpdateListener { va ->
            if (host !== h) { va.cancel(); return@addUpdateListener }
            val f = va.animatedValue as Float
            lp.x = (fx + (x - fx) * f).toInt()
            lp.y = (fy + (y - fy) * f).toInt()
            try { wm.updateViewLayout(h, lp) } catch (_: Throwable) {}
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                if (token == my && host === h) end?.invoke()
            }
        })
        anim = a
        a.start()
    }

    /** Janela de resposta aberta: toda a pilha sobe para o topo e cada balão vira um separador. */
    fun dock(thread: Long) {
        val b = items[thread] ?: return
        val h = host ?: return
        val lp = hostLp ?: return
        active = thread
        b.count = 0
        b.unread = false
        if (docked) { layoutCells(true); return } // mudou de separador
        hidePreview()
        h.animate().cancel()
        h.scaleX = 1f; h.scaleY = 1f; h.alpha = 1f
        if (collapsing) {
            // Voltou a abrir antes de acabar de recolher: a janela já está na largura toda.
            collapsing = false
            docked = true
            layoutCells(true)
            moveTo(0, dockY(), 320)
            return
        }
        docked = true
        savedX = lp.x
        savedY = lp.y
        stopFollow()
        // Mantém a posição visual: as coordenadas da janela passam a ser as do ecrã.
        for (o in items.values) { o.cell.animate().cancel(); o.cell.translationX = o.cell.translationX + lp.x }
        lp.x = 0
        lp.width = screenW()
        try { wm.updateViewLayout(h, lp) } catch (_: Throwable) {}
        layoutCells(true)
        moveTo(0, dockY(), 320)
    }

    /** Janela de resposta fechada: os balões voltam juntos à pilha, onde estavam. */
    fun undock(thread: Long) {
        if (!docked) return
        val sx = savedX
        docked = false
        collapsing = true
        active = -1L
        layoutCells(true, sx)
        moveTo(0, savedY, 420, OvershootInterpolator(0.9f)) { finishCollapse(sx) }
    }

    private fun finishCollapse(sx: Int) {
        val h = host ?: return
        val lp = hostLp ?: return
        if (!collapsing) return
        collapsing = false
        lp.x = sx
        lp.y = savedY
        lp.width = box
        layoutCells(false)
        try { wm.updateViewLayout(h, lp) } catch (_: Throwable) {}
    }

    private fun bounce() {
        val h = host ?: return
        h.animate().cancel()
        h.scaleX = 1f; h.scaleY = 1f
        h.animate().scaleX(1.15f).scaleY(1.15f).setDuration(110).withEndAction {
            h.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator(2f)).start()
        }.start()
    }

    // ------------------------------------------------------------------ pré-visualização ao lado
    private fun hidePreview() {
        previewRun?.let { main.removeCallbacks(it) }
        previewRun = null
        val v = preview ?: return
        preview = null
        try { wm.removeView(v) } catch (_: Throwable) {}
    }

    private fun showPreview(b: Item) {
        val lpH = hostLp ?: return
        hidePreview()
        val dark = isDark()
        val pill = LinearLayout(this)
        pill.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.RECTANGLE
        bg.cornerRadius = dp(20f).toFloat()
        bg.setColor(if (dark) 0xF0262629.toInt() else 0xF5FFFFFF.toInt())
        pill.background = bg
        pill.setPadding(dp(14f), dp(9f), dp(14f), dp(10f))
        pill.elevation = dp(8f).toFloat()
        val n = TextView(this)
        n.text = if (b.hidden) "Chats" else b.name
        n.setTextColor(if (dark) Color.WHITE else 0xFF0F1419.toInt())
        n.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        n.typeface = Typeface.DEFAULT_BOLD
        n.maxLines = 1
        n.ellipsize = android.text.TextUtils.TruncateAt.END
        pill.addView(n)
        val t = TextView(this)
        t.text = if (b.hidden || b.body.isBlank()) "Nova mensagem" else b.body
        t.setTextColor(if (dark) 0xFFC7C7CC.toInt() else 0xFF4A5057.toInt())
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        t.maxLines = 2
        t.ellipsize = android.text.TextUtils.TruncateAt.END
        pill.addView(t)
        pill.measure(
            View.MeasureSpec.makeMeasureSpec(dp(230f), View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = pill.measuredWidth
        val h = pill.measuredHeight
        val onRight = lpH.x + box / 2 > screenW() / 2
        val x = if (onRight) lpH.x + inset - dp(8f) - w else lpH.x + inset + size + dp(8f)
        val lp = WindowManager.LayoutParams(
            w, h, overlayType(),
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = x.coerceIn(dp(8f), maxOf(dp(8f), screenW() - w - dp(8f)))
        lp.y = (lpH.y + box / 2 - h / 2).coerceIn(statusH(), maxOf(statusH(), screenH() - navH() - h))
        try { wm.addView(pill, lp) } catch (_: Throwable) { return }
        preview = pill
        pill.alpha = 0f
        pill.translationX = if (onRight) dp(12f).toFloat() else -dp(12f).toFloat()
        pill.animate().alpha(1f).translationX(0f).setDuration(220).setInterpolator(DecelerateInterpolator()).start()
        val r = Runnable {
            val v = preview
            if (v === pill) {
                v.animate().alpha(0f).setDuration(200).withEndAction { if (preview === pill) hidePreview() }.start()
            }
        }
        previewRun = r
        main.postDelayed(r, PREVIEW_MS)
    }

    // ------------------------------------------------------------------ remover
    fun drop(thread: Long, stop: Boolean = true) {
        val b = items.remove(thread) ?: run { if (stop) stopIfEmpty(); return }
        order.remove(thread)
        b.pulse?.cancel()
        b.cell.animate().cancel()
        hidePreview()
        host?.removeView(b.cell)
        if (items.isEmpty()) removeHost()
        else {
            if (active == thread) active = -1L
            layoutCells(true)
        }
        if (stop) stopIfEmpty()
    }

    fun dropAll() {
        for (k in items.keys.toList()) drop(k, false)
        stopIfEmpty()
    }

    private fun stopIfEmpty() {
        if (items.isEmpty()) stopSelf()
    }

    // ------------------------------------------------------------------ alvo "remover"
    private fun zoneH() = dp(230f) + navH()
    private fun zoneCx() = screenW() / 2
    private fun zoneCy() = screenH() - navH() - dp(40f) - dp(34f)

    private fun showZone() {
        if (zone != null) return
        val c = FrameLayout(this)
        val scrim = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x00000000, 0x66000000)
        )
        c.background = scrim
        val circle = FrameLayout(this)
        val cbg = GradientDrawable()
        cbg.shape = GradientDrawable.OVAL
        cbg.setColor(0xCC1B1C20.toInt())
        cbg.setStroke(dp(1.5f), 0x66FFFFFF)
        circle.background = cbg
        circle.elevation = dp(6f).toFloat()
        val x = ImageView(this)
        x.setImageResource(R.drawable.ic_l_close)
        x.setColorFilter(Color.WHITE)
        circle.addView(x, FrameLayout.LayoutParams(dp(26f), dp(26f), Gravity.CENTER))
        val clp = FrameLayout.LayoutParams(dp(68f), dp(68f), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        clp.bottomMargin = navH() + dp(40f)
        c.addView(circle, clp)
        val lp = WindowManager.LayoutParams(
            -1, zoneH(), overlayType(),
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = screenH() - zoneH()
        try { wm.addView(c, lp) } catch (_: Throwable) { return }
        zone = c
        zoneCircle = circle
        zoneHot = false
        c.alpha = 0f
        circle.translationY = dp(40f).toFloat()
        c.animate().alpha(1f).setDuration(180).start()
        circle.animate().translationY(0f).setDuration(240).setInterpolator(OvershootInterpolator(1.4f)).start()
    }

    private fun hideZone() {
        val z = zone ?: return
        zone = null
        zoneCircle = null
        zoneHot = false
        try { wm.removeView(z) } catch (_: Throwable) {}
    }

    private fun setHot(hot: Boolean, v: View) {
        val z = zoneCircle ?: return
        if (hot == zoneHot) return
        zoneHot = hot
        z.animate().scaleX(if (hot) 1.28f else 1f).scaleY(if (hot) 1.28f else 1f).setDuration(130).start()
        (z.background as? GradientDrawable)?.setColor(if (hot) 0xE6E5392D.toInt() else 0xCC1B1C20.toInt())
        if (hot) v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    // ------------------------------------------------------------------ toque
    @android.annotation.SuppressLint("ClickableViewAccessibility")
    private fun attachTouch(h: FrameLayout) {
        var dx = 0f; var dy = 0f
        var sx = 0; var sy = 0
        var drag = false
        h.setOnTouchListener { v, e ->
            val lp = hostLp ?: return@setOnTouchListener false
            if (docked) return@setOnTouchListener tabTouch(e)
            if (collapsing) return@setOnTouchListener true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX; dy = e.rawY
                    sx = lp.x; sy = lp.y
                    drag = false
                    anim?.cancel(); token++
                    stopFollow()
                    tx = lp.x; ty = lp.y
                    v.animate().cancel()
                    v.alpha = 1f
                    v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx
                    val my = e.rawY - dy
                    if (!drag && hypot(mx, my) > slop) {
                        drag = true
                        hidePreview()
                        showZone()
                        v.animate().scaleX(1.1f).scaleY(1.1f).setDuration(100).start()
                    }
                    if (drag) {
                        // A pilha segue o dedo com suavização (uma atualização por fotograma).
                        var nx = (sx + mx).toInt().coerceIn(minX(), maxX())
                        var ny = (sy + my).toInt().coerceIn(minY(), maxOf(minY(), maxY()))
                        val cx = nx + box / 2
                        val cy = ny + box / 2
                        val near = hypot((cx - zoneCx()).toFloat(), (cy - zoneCy()).toFloat()) < dp(76f)
                        setHot(near, v)
                        if (near) { // "íman": cola ao alvo e encolhe um pouco
                            nx = zoneCx() - box / 2
                            ny = zoneCy() - box / 2
                            v.animate().scaleX(0.82f).scaleY(0.82f).setDuration(120).start()
                        } else {
                            v.animate().scaleX(1.1f).scaleY(1.1f).setDuration(120).start()
                        }
                        tx = nx; ty = ny
                        startFollow()
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val hot = zoneHot
                    stopFollow()
                    hideZone()
                    if (!drag) {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(140).setInterpolator(OvershootInterpolator(2f)).start()
                        if (e.actionMasked == MotionEvent.ACTION_UP) order.firstOrNull()?.let { t -> items[t]?.let { b -> openReply(b) } }
                    } else if (hot) {
                        // Única forma de remover a pilha: largar sobre o ✕.
                        v.animate().scaleX(0f).scaleY(0f).alpha(0f).setDuration(160).withEndAction { dropAll() }.start()
                    } else {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(160).setInterpolator(OvershootInterpolator(1.6f)).start()
                        snap()
                    }
                    true
                }
                else -> false
            }
        }
    }

    /** Com a janela de resposta aberta: toque troca de conversa, puxar para cima remove o balão. */
    private fun tabAt(x: Float): Item? {
        var best: Item? = null
        var bd = Float.MAX_VALUE
        for (b in items.values) {
            val l = target(b, 0).x
            if (x >= l - dp(6f) && x <= l + size + dp(6f)) {
                val d = kotlin.math.abs(x - (l + size / 2f))
                if (d < bd) { bd = d; best = b }
            }
        }
        return best
    }

    private fun tabTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                tabX = e.rawX; tabY = e.rawY
                tabDown = tabAt(e.x)
            }
            MotionEvent.ACTION_MOVE -> {
                val b = tabDown ?: return true
                val up = minOf(0f, e.rawY - tabY)
                b.cell.animate().cancel()
                b.cell.translationY = target(b, 0).y + up
                b.cell.alpha = (1f + up / dp(90f)).coerceIn(0.3f, 1f)
            }
            MotionEvent.ACTION_UP -> {
                val b = tabDown
                tabDown = null
                if (b == null) {
                    ReplyActivity.live?.finish() // toque fora dos balões: fecha, como o fundo escuro
                    return true
                }
                val ddy = e.rawY - tabY
                val ddx = e.rawX - tabX
                if (ddy < -dp(48f)) {
                    removeTab(b)
                } else {
                    layoutCells(true)
                    if (hypot(ddx, ddy) < slop) switchTo(b)
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                tabDown = null
                layoutCells(true)
            }
        }
        return true
    }

    private fun switchTo(b: Item) {
        if (b.thread == active) return
        active = b.thread
        b.count = 0
        b.unread = false
        layoutCells(true)
        openReply(b)
    }

    private fun removeTab(b: Item) {
        val wasActive = b.thread == active
        b.cell.animate().alpha(0f).translationY(-dp(40f).toFloat()).setDuration(140).withEndAction {
            if (items[b.thread] !== b) return@withEndAction
            if (wasActive) active = -1L
            drop(b.thread, false)
            if (items.isEmpty()) {
                ReplyActivity.live?.finish()
                stopIfEmpty()
            } else if (wasActive) {
                switchTo(items.values.first())
            }
        }.start()
    }

    /** Encosta a pilha ao lado mais próximo e guarda a posição para os próximos. */
    private fun snap() {
        val lp = hostLp ?: return
        val toRight = lp.x + box / 2 > screenW() / 2
        val y = ty.coerceIn(minY(), maxOf(minY(), maxY()))
        moveTo(edgeX(toRight), y, 380, OvershootInterpolator(0.8f))
        prefs().edit().putBoolean("right", toRight)
            .putFloat("y", (y.toFloat() / screenH()).coerceIn(0f, 0.95f)).apply()
    }

    private val choreo by lazy { android.view.Choreographer.getInstance() }

    private fun startFollow() {
        if (follow) return
        follow = true
        val cb = object : android.view.Choreographer.FrameCallback {
            override fun doFrame(t: Long) {
                val h = host
                val lp = hostLp
                if (!follow || h == null || lp == null) return
                val ddx = tx - lp.x
                val ddy = ty - lp.y
                if (ddx != 0 || ddy != 0) {
                    lp.x += step(ddx)
                    lp.y += step(ddy)
                    try { wm.updateViewLayout(h, lp) } catch (_: Throwable) {}
                }
                choreo.postFrameCallback(this)
            }
        }
        frame = cb
        choreo.postFrameCallback(cb)
    }

    private fun step(d: Int): Int {
        val s = d * 0.38f
        return if (abs(s) < 1f) (if (d > 0) 1 else if (d < 0) -1 else 0) else s.toInt()
    }

    private fun stopFollow() {
        follow = false
        frame?.let { choreo.removeFrameCallback(it) }
        frame = null
    }

    // ------------------------------------------------------------------ abrir resposta
    private fun openReply(b: Item) {
        hidePreview()
        // Ver a mensagem apaga o ponto vermelho; os balões ficam no ecrã.
        markSeen(b.thread)
        val i = Intent(this, ReplyActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("thread", b.thread).putExtra("addr", b.addr).putExtra("name", b.name)
            .putExtra("body", b.body)
        try {
            startActivity(i)
        } catch (_: Throwable) {
            // Sem permissão para abrir por cima de outras apps: abre a conversa normal.
            try {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        .putExtra("thread", b.thread)
                )
            } catch (_: Throwable) {
            }
        }
    }
}
