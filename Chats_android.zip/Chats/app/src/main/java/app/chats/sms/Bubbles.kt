package app.chats.sms

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.Executors
import kotlin.math.hypot

/** Ponto de entrada do balão flutuante (chamado pelo Notifier, pelo MainActivity e pela resposta rápida). */
object Bubbles {
    /** Mantido por compatibilidade: o balão fica no ecrã mesmo com a app aberta (só sai ao arrastar para o ✕). */
    @Volatile var appVisible = false

    /** Precisa da permissão "Mostrar sobre outras aplicações". */
    fun canShow(c: Context): Boolean = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c)

    fun show(c: Context, thread: Long, address: String, name: String, body: String, hidden: Boolean) {
        if (!Store.bool(c, "bubble", true) || !canShow(c)) return
        val app = c.applicationContext
        val s = BubbleService.inst
        if (s != null) {
            s.post { s.add(thread, address, name, body, hidden) }
            return
        }
        try {
            app.startService(
                Intent(app, BubbleService::class.java)
                    .putExtra("thread", thread).putExtra("addr", address).putExtra("name", name)
                    .putExtra("body", body).putExtra("hidden", hidden)
            )
        } catch (_: Throwable) {
            // O sistema não permitiu iniciar o serviço agora: fica só a notificação.
        }
    }

    /** A mensagem foi vista (janela aberta, lida na app ou na notificação): apaga o ponto vermelho, mas o balão fica. */
    fun seen(thread: Long) {
        val s = BubbleService.inst ?: return
        s.post { s.markSeen(thread) }
    }

    /** Janela de resposta aberta: o balão sobe para o topo (por cima do cartão) e volta quando ela fecha. */
    fun dock(thread: Long) {
        val s = BubbleService.inst ?: return
        s.post { s.dock(thread) }
    }

    fun undock(thread: Long) {
        val s = BubbleService.inst ?: return
        s.post { s.undock(thread) }
    }

    fun remove(thread: Long) {
        val s = BubbleService.inst ?: return
        s.post { s.drop(thread) }
    }

    fun clearAll() {
        val s = BubbleService.inst ?: return
        s.post { s.dropAll() }
    }
}

/** Mantém os balões flutuantes (janelas sobrepostas). Só sai um balão quando é arrastado para o ✕. */
class BubbleService : Service() {
    companion object {
        @Volatile var inst: BubbleService? = null
        private const val MAX = 6
        private const val IDLE_MS = 3500L
        private const val PREVIEW_MS = 3800L
    }

    private class Item(val thread: Long, val root: FrameLayout, val lp: WindowManager.LayoutParams) {
        var addr = ""
        var name = ""
        var body = ""
        var hidden = false
        var count = 0
        var unread = false
        var docked = false
        var savedX = 0
        var savedY = 0
        lateinit var underline: View
        lateinit var ring: FrameLayout
        lateinit var dot: TextView
        var pulse: ObjectAnimator? = null
        var idleRun: Runnable? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val items = LinkedHashMap<Long, Item>()
    private lateinit var wm: WindowManager
    private var zone: FrameLayout? = null
    private var zoneCircle: View? = null
    private var zoneHot = false
    private var preview: View? = null
    private var previewRun: Runnable? = null

    private val dm get() = resources.displayMetrics
    private fun dp(v: Float) = (v * dm.density + 0.5f).toInt()
    private val size get() = dp(54f)           // diâmetro visível do balão
    private val box get() = dp(70f)            // janela: deixa espaço à sombra
    private val inset get() = (box - size) / 2

    fun post(r: Runnable) { main.post(r) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        inst = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null && intent.hasExtra("thread")) {
            val t = intent.getLongExtra("thread", -1L)
            val a = intent.getStringExtra("addr") ?: ""
            val n = intent.getStringExtra("name") ?: a
            val b = intent.getStringExtra("body") ?: ""
            val h = intent.getBooleanExtra("hidden", false)
            main.post { add(t, a, n, b, h) }
        } else if (items.isEmpty()) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        inst = null
        hideZone()
        hidePreview()
        for (v in items.values) {
            v.pulse?.cancel()
            v.idleRun?.let { main.removeCallbacks(it) }
            try { wm.removeView(v.root) } catch (_: Throwable) {}
        }
        items.clear()
        io.shutdownNow()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ ecrã
    private fun screenW() = dm.widthPixels
    private fun screenH() = dm.heightPixels
    private fun statusH(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(24f)
    }
    private fun navH(): Int {
        val id = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }
    private fun minY() = statusH() - inset
    private fun maxY() = screenH() - navH() - box + inset
    private fun minX() = -inset
    private fun maxX() = screenW() - box + inset
    private fun edgeX(right: Boolean) = if (right) maxX() - dp(6f) else minX() + dp(6f)

    private fun prefs() = getSharedPreferences("bubbles", Context.MODE_PRIVATE)

    private fun isDark(): Boolean = when (Store.str(this, "theme", "auto")) {
        "dark" -> true
        "light" -> false
        else -> (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
    }

    private fun overlayType() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    // ------------------------------------------------------------------ criar / atualizar
    fun add(thread: Long, addr: String, name: String, body: String, hidden: Boolean) {
        if (thread < 0) { stopIfEmpty(); return }
        val e = items[thread]
        if (e != null) {
            e.addr = addr; e.name = name; e.body = body; e.hidden = hidden
            if (!e.docked) { e.count++; e.unread = true }
            refreshState(e)
            bounce(e)
            if (!e.docked) { wake(e); showPreview(e) }
            return
        }
        // Avatar fora da thread principal (consulta de contactos).
        io.execute {
            val bmp = try { Notifier.bubbleAvatar(applicationContext, addr, name, hidden) } catch (_: Throwable) { null }
            main.post { if (inst === this) create(thread, addr, name, body, hidden, bmp) }
        }
    }

    private fun gradientRing(): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.gradientType = GradientDrawable.SWEEP_GRADIENT
        g.setGradientCenter(0.5f, 0.5f)
        g.colors = intArrayOf(0xFF4DA3F7.toInt(), 0xFF8E7BFF.toInt(), 0xFFFF7EB6.toInt(), 0xFF4FD6D0.toInt(), 0xFF4DA3F7.toInt())
        return g
    }

    private fun calmRing(): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(0xE6FFFFFF.toInt())
        return g
    }

    private fun create(thread: Long, addr: String, name: String, body: String, hidden: Boolean, bmp: Bitmap?) {
        val ex = items[thread]
        if (ex != null) { // outra mensagem chegou entretanto
            if (!ex.docked) { ex.count++; ex.unread = true; refreshState(ex); showPreview(ex) }
            return
        }
        if (items.size >= MAX) items.keys.firstOrNull()?.let { drop(it, false) }

        val root = FrameLayout(this)
        root.clipChildren = false
        root.clipToPadding = false

        // aro (gradiente quando há mensagens novas) + aro branco + avatar, com sombra suave
        val ring = FrameLayout(this)
        ring.setPadding(dp(3f), dp(3f), dp(3f), dp(3f))
        ring.elevation = dp(7f).toFloat()
        val white = FrameLayout(this)
        val wbg = GradientDrawable()
        wbg.shape = GradientDrawable.OVAL
        wbg.setColor(Color.WHITE)
        white.background = wbg
        white.setPadding(dp(2f), dp(2f), dp(2f), dp(2f))
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        if (bmp != null) img.setImageBitmap(bmp) else img.setImageResource(R.mipmap.ic_launcher)
        white.addView(img, FrameLayout.LayoutParams(-1, -1))
        ring.addView(white, FrameLayout.LayoutParams(-1, -1))
        root.addView(ring, FrameLayout.LayoutParams(size, size, Gravity.CENTER))

        // ponto vermelho de mensagem nova (com número quando há várias)
        val dot = TextView(this)
        dot.setTextColor(Color.WHITE)
        dot.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
        dot.typeface = Typeface.DEFAULT_BOLD
        dot.gravity = Gravity.CENTER
        val dbg = GradientDrawable()
        dbg.shape = GradientDrawable.RECTANGLE
        dbg.cornerRadius = dp(11f).toFloat()
        dbg.setColor(0xFFFF3B30.toInt())
        dbg.setStroke(dp(2f), Color.WHITE)
        dot.background = dbg
        dot.elevation = dp(9f).toFloat()
        val dlp = FrameLayout.LayoutParams(-2, dp(20f), Gravity.TOP or Gravity.END)
        dlp.topMargin = dp(8f)
        dlp.rightMargin = dp(7f)
        root.addView(dot, dlp)

        // traço branco por baixo quando o balão está "preso" ao topo (janela aberta)
        val ul = View(this)
        val ubg = GradientDrawable()
        ubg.shape = GradientDrawable.RECTANGLE
        ubg.cornerRadius = dp(2f).toFloat()
        ubg.setColor(Color.WHITE)
        ul.background = ubg
        ul.visibility = View.GONE
        val ulp = FrameLayout.LayoutParams(dp(24f), dp(3f), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        ulp.bottomMargin = dp(1f)
        root.addView(ul, ulp)

        val lp = WindowManager.LayoutParams(
            box, box, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val p = prefs()
        val right = p.getBoolean("right", true)
        val yFrac = p.getFloat("y", 0.35f)
        lp.x = edgeX(right)
        lp.y = ((yFrac * screenH()).toInt() + items.size * (size + dp(8f))).coerceIn(minY(), maxOf(minY(), maxY()))

        val it = Item(thread, root, lp)
        it.addr = addr; it.name = name; it.body = body; it.hidden = hidden
        it.count = 1; it.unread = true
        it.ring = ring; it.dot = dot; it.underline = ul
        refreshState(it)
        attachTouch(it)
        try {
            wm.addView(root, lp)
        } catch (_: Throwable) {
            // Permissão revogada ou janela recusada: não há balão.
            stopIfEmpty()
            return
        }
        items[thread] = it
        root.scaleX = 0f; root.scaleY = 0f
        root.animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(OvershootInterpolator(1.7f)).start()
        wake(it)
        main.postDelayed({ if (items[thread] === it) showPreview(it) }, 380)
    }

    /** Aro, ponto e pulsação conforme haja ou não mensagens por ver. */
    private fun refreshState(it: Item) {
        it.ring.background = if (it.unread) gradientRing() else calmRing()
        if (it.unread) {
            it.dot.visibility = View.VISIBLE
            val many = it.count > 1
            it.dot.text = if (!many) "" else if (it.count > 99) "99+" else it.count.toString()
            it.dot.minWidth = dp(if (many) 20f else 14f)
            it.dot.setPadding(dp(if (many) 5f else 0f), 0, dp(if (many) 5f else 0f), 0)
            val lp = it.dot.layoutParams as FrameLayout.LayoutParams
            lp.height = dp(if (many) 20f else 14f)
            it.dot.layoutParams = lp
            if (it.pulse == null) {
                val a = ObjectAnimator.ofPropertyValuesHolder(
                    it.dot,
                    PropertyValuesHolder.ofFloat("scaleX", 1f, 1.22f),
                    PropertyValuesHolder.ofFloat("scaleY", 1f, 1.22f)
                )
                a.duration = 800
                a.repeatMode = ValueAnimator.REVERSE
                a.repeatCount = ValueAnimator.INFINITE
                a.start()
                it.pulse = a
            }
        } else {
            it.pulse?.cancel()
            it.pulse = null
            it.dot.scaleX = 1f; it.dot.scaleY = 1f
            it.dot.visibility = View.GONE
        }
    }

    fun markSeen(thread: Long) {
        val it = items[thread] ?: return
        it.count = 0
        it.unread = false
        refreshState(it)
    }

    private fun moveTo(b: Item, x: Int, y: Int, ms: Long) {
        val fx = b.lp.x
        val fy = b.lp.y
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = ms
        a.interpolator = DecelerateInterpolator(1.6f)
        a.addUpdateListener { va ->
            if (items[b.thread] !== b) { va.cancel(); return@addUpdateListener }
            val f = va.animatedValue as Float
            b.lp.x = (fx + (x - fx) * f).toInt()
            b.lp.y = (fy + (y - fy) * f).toInt()
            try { wm.updateViewLayout(b.root, b.lp) } catch (_: Throwable) {}
        }
        a.start()
    }

    /** Sobe para o centro do topo, como "separador" ativo da janela de resposta. */
    fun dock(thread: Long) {
        val b = items[thread] ?: return
        if (b.docked) return
        hidePreview()
        for (o in items.values.toList()) if (o.docked && o !== b) undock(o.thread)
        b.docked = true
        b.savedX = b.lp.x
        b.savedY = b.lp.y
        b.idleRun?.let { r -> main.removeCallbacks(r) }
        b.root.animate().cancel()
        b.root.alpha = 1f
        b.root.scaleX = 1f; b.root.scaleY = 1f
        b.underline.visibility = View.VISIBLE
        for (o in items.values) if (o !== b) o.root.visibility = View.INVISIBLE
        markSeen(thread)
        moveTo(b, screenW() / 2 - box / 2, statusH() + dp(6f) - inset + dp(0f), 320)
    }

    /** Volta à posição onde estava antes de abrir a janela. */
    fun undock(thread: Long) {
        val b = items[thread] ?: return
        if (!b.docked) return
        b.docked = false
        b.underline.visibility = View.GONE
        for (o in items.values) o.root.visibility = View.VISIBLE
        moveTo(b, b.savedX, b.savedY, 300)
        wake(b)
    }

    private fun bounce(it: Item) {
        it.root.animate().cancel()
        it.root.scaleX = 1f; it.root.scaleY = 1f
        it.root.animate().scaleX(1.2f).scaleY(1.2f).setDuration(110).withEndAction {
            it.root.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator(2f)).start()
        }.start()
    }

    /** Fica totalmente visível e, passado um tempo parado, esbate-se um pouco. */
    private fun wake(it: Item) {
        it.idleRun?.let { r -> main.removeCallbacks(r) }
        it.root.animate().alpha(1f).setDuration(120).start()
        val r = Runnable { if (items[it.thread] === it) it.root.animate().alpha(0.78f).setDuration(400).start() }
        it.idleRun = r
        main.postDelayed(r, IDLE_MS)
    }

    // ------------------------------------------------------------------ pré-visualização ao lado
    private fun hidePreview() {
        previewRun?.let { main.removeCallbacks(it) }
        previewRun = null
        val v = preview ?: return
        preview = null
        try { wm.removeView(v) } catch (_: Throwable) {}
    }

    private fun showPreview(it: Item) {
        hidePreview()
        val dark = isDark()
        val pill = LinearLayout(this)
        pill.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.RECTANGLE
        bg.cornerRadius = dp(20f).toFloat()
        bg.setColor(if (dark) 0xF0262629.toInt() else 0xF5FFFFFF.toInt())
        pill.background = bg
        pill.setPadding(dp(14f), dp(9f), dp(14f), dp(10f))
        pill.elevation = dp(8f).toFloat()
        val n = TextView(this)
        n.text = if (it.hidden) "Chats" else it.name
        n.setTextColor(if (dark) Color.WHITE else 0xFF0F1419.toInt())
        n.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        n.typeface = Typeface.DEFAULT_BOLD
        n.maxLines = 1
        n.ellipsize = android.text.TextUtils.TruncateAt.END
        pill.addView(n)
        val t = TextView(this)
        t.text = if (it.hidden || it.body.isBlank()) "Nova mensagem" else it.body
        t.setTextColor(if (dark) 0xFFC7C7CC.toInt() else 0xFF4A5057.toInt())
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        t.maxLines = 2
        t.ellipsize = android.text.TextUtils.TruncateAt.END
        pill.addView(t)
        pill.measure(
            View.MeasureSpec.makeMeasureSpec(dp(230f), View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = pill.measuredWidth
        val h = pill.measuredHeight
        val onRight = it.lp.x + box / 2 > screenW() / 2
        val x = if (onRight) it.lp.x + inset - dp(8f) - w else it.lp.x + inset + size + dp(8f)
        val lp = WindowManager.LayoutParams(
            w, h, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = x.coerceIn(dp(8f), maxOf(dp(8f), screenW() - w - dp(8f)))
        lp.y = (it.lp.y + box / 2 - h / 2).coerceIn(statusH(), maxOf(statusH(), screenH() - navH() - h))
        try { wm.addView(pill, lp) } catch (_: Throwable) { return }
        preview = pill
        pill.alpha = 0f
        pill.translationX = if (onRight) dp(12f).toFloat() else -dp(12f).toFloat()
        pill.animate().alpha(1f).translationX(0f).setDuration(220).setInterpolator(DecelerateInterpolator()).start()
        val r = Runnable {
            val v = preview
            if (v === pill) {
                v.animate().alpha(0f).setDuration(200).withEndAction { if (preview === pill) hidePreview() }.start()
            }
        }
        previewRun = r
        main.postDelayed(r, PREVIEW_MS)
    }

    // ------------------------------------------------------------------ remover
    fun drop(thread: Long, stop: Boolean = true) {
        val it = items.remove(thread) ?: run { if (stop) stopIfEmpty(); return }
        it.pulse?.cancel()
        it.idleRun?.let { r -> main.removeCallbacks(r) }
        it.root.animate().cancel()
        hidePreview()
        try { wm.removeView(it.root) } catch (_: Throwable) {}
        if (stop) stopIfEmpty()
    }

    fun dropAll() {
        for (k in items.keys.toList()) drop(k, false)
        stopIfEmpty()
    }

    private fun stopIfEmpty() {
        if (items.isEmpty()) stopSelf()
    }

    // ------------------------------------------------------------------ alvo "remover"
    private fun zoneH() = dp(230f) + navH()
    private fun zoneCx() = screenW() / 2
    private fun zoneCy() = screenH() - navH() - dp(40f) - dp(34f)

    private fun showZone() {
        if (zone != null) return
        val c = FrameLayout(this)
        val scrim = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x00000000, 0x66000000)
        )
        c.background = scrim
        val circle = FrameLayout(this)
        val cbg = GradientDrawable()
        cbg.shape = GradientDrawable.OVAL
        cbg.setColor(0xCC1B1C20.toInt())
        cbg.setStroke(dp(1.5f), 0x66FFFFFF)
        circle.background = cbg
        circle.elevation = dp(6f).toFloat()
        val x = ImageView(this)
        x.setImageResource(R.drawable.ic_l_close)
        x.setColorFilter(Color.WHITE)
        circle.addView(x, FrameLayout.LayoutParams(dp(26f), dp(26f), Gravity.CENTER))
        val clp = FrameLayout.LayoutParams(dp(68f), dp(68f), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        clp.bottomMargin = navH() + dp(40f)
        c.addView(circle, clp)
        val lp = WindowManager.LayoutParams(
            -1, zoneH(), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = screenH() - zoneH()
        try { wm.addView(c, lp) } catch (_: Throwable) { return }
        zone = c
        zoneCircle = circle
        zoneHot = false
        c.alpha = 0f
        circle.translationY = dp(40f).toFloat()
        c.animate().alpha(1f).setDuration(180).start()
        circle.animate().translationY(0f).setDuration(240).setInterpolator(OvershootInterpolator(1.4f)).start()
    }

    private fun hideZone() {
        val z = zone ?: return
        zone = null
        zoneCircle = null
        zoneHot = false
        try { wm.removeView(z) } catch (_: Throwable) {}
    }

    private fun setHot(hot: Boolean, v: View) {
        val z = zoneCircle ?: return
        if (hot == zoneHot) return
        zoneHot = hot
        z.animate().scaleX(if (hot) 1.28f else 1f).scaleY(if (hot) 1.28f else 1f).setDuration(130).start()
        (z.background as? GradientDrawable)?.setColor(if (hot) 0xE6E5392D.toInt() else 0xCC1B1C20.toInt())
        if (hot) v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    // ------------------------------------------------------------------ arrastar
    @android.annotation.SuppressLint("ClickableViewAccessibility")
    private fun attachTouch(it: Item) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var dx = 0f; var dy = 0f
        var sx = 0; var sy = 0
        var drag = false
        it.root.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (it.docked) return@setOnTouchListener true // preso ao topo enquanto a janela está aberta
                    dx = e.rawX; dy = e.rawY
                    sx = it.lp.x; sy = it.lp.y
                    drag = false
                    it.idleRun?.let { r -> main.removeCallbacks(r) }
                    v.animate().cancel()
                    v.alpha = 1f
                    v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (it.docked) return@setOnTouchListener true
                    val mx = e.rawX - dx
                    val my = e.rawY - dy
                    if (!drag && hypot(mx, my) > slop) {
                        drag = true
                        hidePreview()
                        showZone()
                        v.animate().scaleX(1.1f).scaleY(1.1f).setDuration(100).start()
                    }
                    if (drag) {
                        it.lp.x = (sx + mx).toInt().coerceIn(minX(), maxX())
                        it.lp.y = (sy + my).toInt().coerceIn(minY(), maxOf(minY(), maxY()))
                        val cx = it.lp.x + box / 2
                        val cy = it.lp.y + box / 2
                        val near = hypot((cx - zoneCx()).toFloat(), (cy - zoneCy()).toFloat()) < dp(76f)
                        setHot(near, v)
                        if (near) { // "íman": cola ao alvo e encolhe um pouco
                            it.lp.x = zoneCx() - box / 2
                            it.lp.y = zoneCy() - box / 2
                            v.scaleX = 0.82f; v.scaleY = 0.82f
                        } else {
                            v.scaleX = 1.1f; v.scaleY = 1.1f
                        }
                        try { wm.updateViewLayout(v, it.lp) } catch (_: Throwable) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (it.docked) return@setOnTouchListener true
                    val hot = zoneHot
                    hideZone()
                    if (!drag) {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(140).setInterpolator(OvershootInterpolator(2f)).start()
                        if (e.actionMasked == MotionEvent.ACTION_UP) openReply(it)
                        wake(it)
                    } else if (hot) {
                        // Única forma de remover o balão: largar sobre o ✕.
                        v.animate().scaleX(0f).scaleY(0f).alpha(0f).setDuration(160).withEndAction { drop(it.thread) }.start()
                    } else {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(160).setInterpolator(OvershootInterpolator(1.6f)).start()
                        snap(it)
                        wake(it)
                    }
                    true
                }
                else -> false
            }
        }
    }

    /** Encosta o balão ao lado mais próximo e guarda a posição para os próximos. */
    private fun snap(it: Item) {
        val toRight = it.lp.x + box / 2 > screenW() / 2
        val target = edgeX(toRight)
        val a = ValueAnimator.ofInt(it.lp.x, target)
        a.duration = 260
        a.interpolator = OvershootInterpolator(0.9f)
        a.addUpdateListener { va ->
            if (items[it.thread] !== it) { va.cancel(); return@addUpdateListener }
            it.lp.x = va.animatedValue as Int
            try { wm.updateViewLayout(it.root, it.lp) } catch (_: Throwable) {}
        }
        a.start()
        prefs().edit().putBoolean("right", toRight)
            .putFloat("y", (it.lp.y.toFloat() / screenH()).coerceIn(0f, 0.95f)).apply()
    }

    // ------------------------------------------------------------------ abrir resposta
    private fun openReply(it: Item) {
        hidePreview()
        // Ver a mensagem apaga o ponto vermelho; o balão fica no ecrã.
        markSeen(it.thread)
        val i = Intent(this, ReplyActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("thread", it.thread).putExtra("addr", it.addr).putExtra("name", it.name)
            .putExtra("body", it.body)
        try {
            startActivity(i)
        } catch (_: Throwable) {
            // Sem permissão para abrir por cima de outras apps: abre a conversa normal.
            try {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        .putExtra("thread", it.thread)
                )
            } catch (_: Throwable) {
            }
        }
    }
}
