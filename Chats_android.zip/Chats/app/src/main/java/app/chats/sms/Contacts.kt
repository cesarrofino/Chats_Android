package app.chats.sms

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.ContactsContract
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

object Contacts {
    private val cache = ConcurrentHashMap<String, Array<String?>>()
    private val photoCache = ConcurrentHashMap<String, String>()

    fun has(c: Context) =
        c.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    fun clearCache() {
        cache.clear()
        photoCache.clear()
    }

    /** Devolve [nome, uriDaFoto] para um número (ou nulos). */
    fun lookup(c: Context, address: String): Array<String?> {
        cache[address]?.let { return it }
        var res: Array<String?> = arrayOf(null, null)
        if (has(c) && address.any { it.isDigit() }) {
            try {
                val uri = Uri.withAppendedPath(
                    ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address)
                )
                c.contentResolver.query(
                    uri,
                    arrayOf(
                        ContactsContract.PhoneLookup.DISPLAY_NAME,
                        ContactsContract.PhoneLookup.PHOTO_THUMBNAIL_URI
                    ),
                    null, null, null
                )?.use { cur ->
                    if (cur.moveToFirst()) res = arrayOf(cur.getString(0), cur.getString(1))
                }
            } catch (_: Exception) {
            }
        }
        cache[address] = res
        return res
    }

    fun name(c: Context, address: String): String? = lookup(c, address)[0]

    fun photo(c: Context, address: String): String? {
        photoCache[address]?.let { return if (it.isEmpty()) null else it }
        val u = lookup(c, address)[1]
        var out = ""
        if (u != null) {
            try {
                c.contentResolver.openInputStream(Uri.parse(u))?.use { ins ->
                    val bmp = BitmapFactory.decodeStream(ins)
                    if (bmp != null) out = "data:image/jpeg;base64," + Media.b64(Media.scale(bmp, 96), 80)
                }
            } catch (_: Exception) {
            }
        }
        photoCache[address] = out
        return if (out.isEmpty()) null else out
    }

    fun photos(c: Context, addrs: List<String>): JSONObject {
        val o = JSONObject()
        for (a in addrs) photo(c, a)?.let { o.put(a, it) }
        return o
    }

    fun list(c: Context): JSONArray {
        val arr = JSONArray()
        if (!has(c)) return arr
        val seen = HashSet<String>()
        try {
            c.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
            )?.use { cur ->
                while (cur.moveToNext() && arr.length() < 6000) {
                    val name = cur.getString(0) ?: continue
                    val num = cur.getString(1) ?: continue
                    val key = num.filter { it.isDigit() || it == '+' }
                    if (key.isEmpty() || !seen.add(name + key)) continue
                    arr.put(JSONObject().put("name", name).put("number", num))
                }
            }
        } catch (_: Exception) {
        }
        return arr
    }
}
