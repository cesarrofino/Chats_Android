package app.chats.sms

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.ContactsContract
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

object Contacts {
    private val cache = ConcurrentHashMap<String, Array<String?>>()
    private val photoCache = ConcurrentHashMap<String, String>()

    @Volatile private var map: Map<String, Array<String?>> = emptyMap()
    @Volatile private var loadedAt = 0L

    private fun key(a: String): String? {
        val d = a.filter { it.isDigit() }
        return if (d.length >= 7) d.takeLast(9) else null
    }

    /** Carrega todos os contactos numa só consulta (muito mais rápido do que uma consulta por número). */
    fun warm(c: Context) {
        if (!has(c)) return
        val now = System.currentTimeMillis()
        if (map.isNotEmpty() && now - loadedAt < 30_000) return
        val m = HashMap<String, Array<String?>>()
        try {
            c.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.PHOTO_THUMBNAIL_URI
                ), null, null, null
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val k = key(cur.getString(0) ?: continue) ?: continue
                    if (!m.containsKey(k)) m[k] = arrayOf(cur.getString(1), cur.getString(2))
                }
            }
        } catch (_: Exception) {
            return
        }
        map = m
        loadedAt = now
        cache.clear()
    }

    fun has(c: Context) =
        c.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    fun clearCache() {
        cache.clear()
        photoCache.clear()
    }

    /** Devolve [nome, uriDaFoto] para um número (ou nulos). */
    fun lookup(c: Context, address: String): Array<String?> {
        cache[address]?.let { return it }
        warm(c)
        val kk = key(address)
        if (map.isNotEmpty() && kk != null) {
            val r = map[kk] ?: arrayOf<String?>(null, null)
            cache[address] = r
            return r
        }
        var res: Array<String?> = arrayOf(null, null)
        if (has(c) && address.any { it.isDigit() }) {
            try {
                val uri = Uri.withAppendedPath(
                    ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address)
                )
                c.contentResolver.query(
                    uri,
                    arrayOf(
                        ContactsContract.PhoneLookup.DISPLAY_NAME,
                        ContactsContract.PhoneLookup.PHOTO_THUMBNAIL_URI
                    ),
                    null, null, null
                )?.use { cur ->
                    if (cur.moveToFirst()) res = arrayOf(cur.getString(0), cur.getString(1))
                }
            } catch (_: Exception) {
            }
        }
        cache[address] = res
        return res
    }

    fun name(c: Context, address: String): String? = lookup(c, address)[0]

    fun photo(c: Context, address: String): String? {
        photoCache[address]?.let { return if (it.isEmpty()) null else it }
        val u = lookup(c, address)[1]
        var out = ""
        if (u != null) {
            try {
                c.contentResolver.openInputStream(Uri.parse(u))?.use { ins ->
                    val bmp = BitmapFactory.decodeStream(ins)
                    if (bmp != null) out = "data:image/jpeg;base64," + Media.b64(Media.scale(bmp, 96), 80)
                }
            } catch (_: Exception) {
            }
        }
        photoCache[address] = out
        return if (out.isEmpty()) null else out
    }

    fun photos(c: Context, addrs: List<String>): JSONObject {
        val o = JSONObject()
        for (a in addrs) photo(c, a)?.let { o.put(a, it) }
        return o
    }

    fun list(c: Context): JSONArray {
        val arr = JSONArray()
        if (!has(c)) return arr
        val seen = HashSet<String>()
        try {
            c.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
            )?.use { cur ->
                while (cur.moveToNext() && arr.length() < 6000) {
                    val name = cur.getString(0) ?: continue
                    val num = cur.getString(1) ?: continue
                    val key = num.filter { it.isDigit() || it == '+' }
                    if (key.isEmpty() || !seen.add(name + key)) continue
                    arr.put(JSONObject().put("name", name).put("number", num))
                }
            }
        } catch (_: Exception) {
        }
        return arr
    }
}
