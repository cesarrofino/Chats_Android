package app.chats.sms

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.telephony.SubscriptionManager
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.Executors

/**
 * Janela de resposta rápida aberta pelo balão flutuante: mostra as últimas mensagens da conversa
 * e permite responder sem abrir a aplicação.
 */
class ReplyActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private var thread = -1L
    private var addr = ""
    private var name = ""
    private var svc = false
    private var dark = false
    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText

    // Cores
    private val brand = 0xFF1F7BFF.toInt()
    private val cCard get() = if (dark) 0xFF1C1C1E.toInt() else Color.WHITE
    private val cText get() = if (dark) Color.WHITE else 0xFF111114.toInt()
    private val cSub get() = if (dark) 0xFF9A9AA0.toInt() else 0xFF6B6B72.toInt()
    private val cIn get() = if (dark) 0xFF2C2C2E.toInt() else 0xFFEEF0F3.toInt()
    private val cField get() = if (dark) 0xFF2C2C2E.toInt() else 0xFFF0F2F5.toInt()

    private fun dp(v: Float) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun round(color: Int, r: Float, stroke: Int = 0, sc: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = dp(r).toFloat()
        g.setColor(color)
        if (stroke > 0) g.setStroke(stroke, sc)
        return g
    }

    private class MaxScroll(c: Context, private val maxH: Int) : ScrollView(c) {
        override fun onMeasure(w: Int, h: Int) {
            super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST))
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        build(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        build(intent)
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    private fun isDark(): Boolean = when (Store.str(this, "theme", "auto")) {
        "dark" -> true
        "light" -> false
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private fun build(i: Intent) {
        thread = i.getLongExtra("thread", -1L)
        addr = i.getStringExtra("addr") ?: ""
        name = i.getStringExtra("name")?.ifBlank { null } ?: addr
        val fallback = i.getStringExtra("body") ?: ""
        dark = isDark()
        svc = Notifier.isService(addr)

        val root = FrameLayout(this)
        root.setBackgroundColor(0x99000000.toInt())
        root.setOnClickListener { finish() }

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = round(cCard, 24f)
        card.isClickable = true // não fecha ao tocar dentro do cartão
        card.setPadding(dp(14f), dp(12f), dp(14f), dp(12f))
        val clp = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        clp.setMargins(dp(12f), dp(12f), dp(12f), dp(12f))
        root.addView(card, clp)

        // ---- cabeçalho
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val av = ImageView(this)
        av.scaleType = ImageView.ScaleType.CENTER_CROP
        head.addView(av, LinearLayout.LayoutParams(dp(44f), dp(44f)))
        io.execute {
            val bmp = try { Notifier.bubbleAvatar(applicationContext, addr, name, false) } catch (_: Throwable) { null }
            runOnUiThread { if (bmp != null && !isDestroyed) av.setImageBitmap(bmp) else av.setImageResource(R.mipmap.ic_launcher) }
        }
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        val t1 = TextView(this)
        t1.text = name.ifEmpty { "Mensagem" }
        t1.setTextColor(cText)
        t1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        t1.typeface = Typeface.DEFAULT_BOLD
        t1.maxLines = 1
        t1.ellipsize = android.text.TextUtils.TruncateAt.END
        titles.addView(t1)
        if (!svc && addr.isNotEmpty() && addr != name) {
            val t2 = TextView(this)
            t2.text = addr
            t2.setTextColor(cSub)
            t2.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            t2.maxLines = 1
            titles.addView(t2)
        }
        val tl = LinearLayout.LayoutParams(0, -2, 1f)
        tl.leftMargin = dp(10f)
        head.addView(titles, tl)
        head.addView(pill("Abrir") { openChat() })
        val x = TextView(this)
        x.text = "✕"
        x.gravity = Gravity.CENTER
        x.setTextColor(cSub)
        x.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        x.setOnClickListener { finish() }
        head.addView(x, LinearLayout.LayoutParams(dp(40f), dp(40f)))
        card.addView(head)

        // ---- mensagens
        val maxH = (resources.displayMetrics.heightPixels * 0.34f).toInt()
        scroll = MaxScroll(this, maxH)
        scroll.isVerticalScrollBarEnabled = false
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, dp(10f), 0, dp(4f))
        scroll.addView(list, FrameLayout.LayoutParams(-1, -2))
        card.addView(scroll, LinearLayout.LayoutParams(-1, -2))
        io.execute {
            val msgs = try { Messages.recent(applicationContext, thread, 6) } catch (_: Throwable) { emptyList() }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                list.removeAllViews()
                if (msgs.isEmpty()) {
                    if (fallback.isNotBlank()) addBubble(fallback, false, System.currentTimeMillis())
                } else {
                    msgs.forEach { addBubble(it.first, it.third, it.second) }
                }
                scrollDown()
            }
            // Ao ver a mensagem consideramos a conversa lida e retiramos a notificação.
            try {
                if (thread >= 0) {
                    Messages.markRead(applicationContext, thread, true)
                    Notifier.cancel(applicationContext, thread)
                    Events.emit("changed")
                }
            } catch (_: Throwable) {
            }
        }

        // ---- respostas rápidas
        val quick = try { Store.settings(this).optJSONArray("quick") } catch (_: Throwable) { null }
        if (!svc && quick != null && quick.length() > 0 && addr.isNotEmpty()) {
            val hs = HorizontalScrollView(this)
            hs.isHorizontalScrollBarEnabled = false
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until minOf(quick.length(), 8)) {
                val q = quick.optString(k).trim()
                if (q.isEmpty()) continue
                val chip = pill(if (q.length > 28) q.take(28) + "…" else q) { send(q) }
                val lp = LinearLayout.LayoutParams(-2, -2)
                lp.rightMargin = dp(8f)
                row.addView(chip, lp)
            }
            hs.addView(row)
            val hl = LinearLayout.LayoutParams(-1, -2)
            hl.topMargin = dp(6f)
            card.addView(hs, hl)
        }

        // ---- campo de resposta
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.BOTTOM
        input = EditText(this)
        input.hint = if (addr.isEmpty()) "Abra a conversa para responder" else "Responder…"
        input.setHintTextColor(cSub)
        input.setTextColor(cText)
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        input.maxLines = 4
        input.background = round(cField, 22f)
        input.setPadding(dp(16f), dp(10f), dp(16f), dp(10f))
        input.isEnabled = addr.isNotEmpty()
        val il = LinearLayout.LayoutParams(0, -2, 1f)
        bar.addView(input, il)
        val sendBtn = ImageView(this)
        sendBtn.setImageResource(R.drawable.ic_send)
        sendBtn.scaleType = ImageView.ScaleType.CENTER
        val sg = GradientDrawable()
        sg.shape = GradientDrawable.OVAL
        sg.setColor(brand)
        sendBtn.background = sg
        sendBtn.contentDescription = "Enviar"
        sendBtn.setOnClickListener { send(input.text.toString()) }
        val sl = LinearLayout.LayoutParams(dp(44f), dp(44f))
        sl.leftMargin = dp(8f)
        bar.addView(sendBtn, sl)
        val bl = LinearLayout.LayoutParams(-1, -2)
        bl.topMargin = dp(8f)
        if (!svc) card.addView(bar, bl) // serviços só recebem: sem campo de resposta

        setContentView(root)
        if (addr.isNotEmpty() && !svc) {
            input.requestFocus()
            input.postDelayed({
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            }, 150)
        }
    }

    private fun pill(text: String, click: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(brand)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.background = round(if (dark) 0x331F7BFF else 0x1A1F7BFF, 16f)
        t.setPadding(dp(14f), dp(7f), dp(14f), dp(7f))
        t.setOnClickListener { click() }
        return t
    }

    private fun addBubble(text: String, mine: Boolean, date: Long) {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = if (mine) Gravity.END else Gravity.START
        val tv = TextView(this)
        tv.text = text
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        tv.setTextColor(if (mine) Color.WHITE else cText)
        tv.background = round(if (mine) brand else cIn, 18f)
        tv.setPadding(dp(12f), dp(8f), dp(12f), dp(8f))
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.72f).toInt()
        tv.setTextIsSelectable(false)
        col.addView(tv)
        val tm = TextView(this)
        tm.text = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(date))
        tm.setTextColor(cSub)
        tm.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        tm.setPadding(dp(6f), dp(2f), dp(6f), 0)
        col.addView(tm)
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.gravity = if (mine) Gravity.END else Gravity.START
        lp.bottomMargin = dp(6f)
        list.addView(col, lp)
    }

    private fun scrollDown() {
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun openChat() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra("thread", thread)
            )
        } catch (_: Throwable) {
        }
        finish()
    }

    private fun send(text: String) {
        val body = text.trim()
        if (body.isEmpty() || addr.isEmpty()) return
        if (!Sender.isDefault(this)) {
            Toast.makeText(this, "Defina o Chats como aplicação SMS predefinida para enviar.", Toast.LENGTH_LONG).show()
            return
        }
        input.setText("")
        addBubble(body, true, System.currentTimeMillis())
        scrollDown()
        val app = applicationContext
        val a = addr
        val t = thread
        // Fora do ciclo de vida da janela: o envio não pode ser cancelado se a janela fechar.
        Thread {
            try {
                val chosen = Store.settings(app).optInt("sub", -1)
                val sub = if (chosen >= 0) chosen else SubscriptionManager.getDefaultSmsSubscriptionId()
                Sender.sendSms(app, listOf(a), body, sub, Store.bool(app, "deliveryReports", true))
                if (t >= 0) Messages.markRead(app, t, true)
                Notifier.cancel(app, t)
                Events.emit("changed")
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(app, e.message ?: "Não foi possível enviar.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}
