package app.chats.sms

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.telephony.SubscriptionManager
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.DateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Janela de resposta aberta pelo balão flutuante. Reproduz o ecrã de conversa da app: cabeçalho em
 * pílulas, balões iguais, fundo da conversa e barra de escrita com o enviar em círculo.
 * Mensagens antigas carregam ao subir até ao topo.
 */
class ReplyActivity : Activity() {
    companion object {
        @Volatile var live: ReplyActivity? = null
    }

    private val io = Executors.newSingleThreadExecutor()
    private var thread = -1L
    private var addr = ""
    private var name = ""
    private var svc = false
    private var dark = false
    private var fallback = ""
    private var limit = 60
    /** Enquanto estiver perto do fim, a janela mantém-se agarrada à última mensagem (teclado, painéis, carregamentos). */
    private var stick = true
    private var more = false
    private var loading = false
    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private var input: EditText? = null
    private var arrow: FrameLayout? = null
    private var arrowHide: Runnable? = null
    private var zoom = 1f
    private var cache: List<Messages.Rec> = emptyList()
    private var panel: LinearLayout? = null
    private var emoIcon: ImageView? = null
    private var emoOpen = false
    private var emoCat = 0
    private var emoData: List<Pair<String, List<String>>>? = null

    // Cores iguais às da app (tema claro / escuro)
    private var cSent = 0
    private var cRecv = 0
    private var fs = 16f
    private var rad = 18f
    private var wp = false
    private var bs = "classic"          // tipo de balão (igual ao da app)
    private var fscale = 1f             // "Tamanho da fonte do app"
    private var avBmp: android.graphics.Bitmap? = null
    private val avViews = ArrayList<ImageView>()
    private var lastMine: Boolean? = null
    private var fadeTop = 0             // altura do cabeçalho flutuante (px)
    private var fadeBot = 0             // altura da barra de escrita flutuante (px)
    private val cAcc get() = if (dark) 0xFF4DA3F7.toInt() else 0xFF3390EC.toInt()
    private val cInk get() = if (dark) 0xFFF2F2F2.toInt() else 0xFF0F1419.toInt()
    private val cMute get() = if (dark) 0xFF8E8E93.toInt() else 0xFF7E8791.toInt()
    private val cPill get() = if (dark) 0xFF1C1C1E.toInt() else Color.WHITE
    private val cChatBg get() = if (dark) Color.BLACK else 0xFFE4EBF2.toInt()

    private fun dp(v: Float) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun round(color: Int, r: Float): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = dp(r).toFloat()
        g.setColor(color)
        return g
    }

    private fun inkOn(bg: Int): Int {
        val l = (0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)) / 255.0
        return if (l > 0.62) 0xFF0F1419.toInt() else Color.WHITE
    }

    private fun icon(res: Int, tint: Int, sizeDp: Float): ImageView {
        val v = ImageView(this)
        v.setImageResource(res)
        v.setColorFilter(tint)
        v.scaleType = ImageView.ScaleType.FIT_CENTER
        v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return v
    }

    /** Pílula flutuante (como as do ecrã de conversa): fundo da app com sombra suave. */
    private fun floating(v: View, h: Float, fill: Int = cPill) {
        v.background = round(fill, h / 2f)
        v.elevation = dp(4f).toFloat()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        live = this
        build(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Troca de separador (outra conversa): os balões continuam no topo, só muda o ativo.
        setIntent(intent)
        build(intent)
    }

    /** O balão começa a voltar ao seu lugar logo que a janela começa a fechar (animação suave). */
    override fun finish() {
        Bubbles.undock(thread)
        super.finish()
    }

    /** Ao sair para outra app / ecrã inicial a janela fecha e o balão volta ao seu lugar. */
    override fun onStop() {
        if (!isChangingConfigurations && !isFinishing) finish()
        super.onStop()
    }

    override fun onDestroy() {
        if (live === this) live = null
        Bubbles.undock(thread)
        io.shutdownNow()
        super.onDestroy()
    }

    /** Chega uma mensagem da conversa que está aberta: atualiza logo, sem tocar no balão. */
    fun isShowing(t: Long) = t == thread

    fun onIncoming() {
        val app = applicationContext
        val t = thread
        runOnUiThread {
            if (isDestroyed) return@runOnUiThread
            if (loading) list.postDelayed({ if (!isDestroyed) load(true) }, 300) else load(true)
        }
        try {
            io.execute {
                try {
                    Messages.markRead(app, t, true)
                    Notifier.cancel(app, t)
                    Events.emit("changed")
                } catch (_: Throwable) {
                }
            }
        } catch (_: Throwable) {
        }
    }

    private fun isDark(): Boolean = when (Store.str(this, "theme", "auto")) {
        "dark" -> true
        "light" -> false
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private fun statusBarH(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(24f)
    }

    private fun parse(s: String?): Int? = try {
        if (s.isNullOrBlank()) null else Color.parseColor(s)
    } catch (_: Exception) {
        null
    }

    private fun wallpaper(): File? {
        val d = File(filesDir, "wallpapers")
        val f1 = File(d, "c$thread.jpg")
        if (f1.exists()) return f1
        val f2 = File(d, "global.jpg")
        return if (f2.exists()) f2 else null
    }

    private fun build(i: Intent) {
        thread = i.getLongExtra("thread", -1L)
        addr = i.getStringExtra("addr") ?: ""
        name = i.getStringExtra("name")?.ifBlank { null } ?: addr
        fallback = i.getStringExtra("body") ?: ""
        svc = Notifier.isService(addr)
        dark = isDark()
        zoom = Store.settings(this).optDouble("chatZoom", 1.0).toFloat().coerceIn(0.75f, 2.2f)
        limit = 60
        more = false
        loading = false
        stick = true

        val wpFile = try { wallpaper() } catch (_: Throwable) { null }
        val wpBmp = try { if (wpFile != null) BitmapFactory.decodeFile(wpFile.absolutePath) else null } catch (_: Throwable) { null }
        wp = wpBmp != null
        val bub = Store.settings(this).optJSONObject("bub")
        cSent = parse(bub?.optString("sent")) ?: (if (dark) 0xFF2B5278.toInt() else 0xFF3A8FE8.toInt())
        cRecv = parse(bub?.optString("recv")) ?: (if (dark) 0xFF1C1C1E.toInt() else Color.WHITE)
        rad = (bub?.optDouble("r", 18.0) ?: 18.0).toFloat().coerceIn(6f, 28f)
        fs = (bub?.optDouble("fs", 16.0) ?: 16.0).toFloat().coerceIn(13f, 22f)
        bs = bub?.optString("style", "classic")?.ifBlank { "classic" } ?: "classic"
        fscale = (Store.settings(this).optDouble("fontScale", 100.0) / 100.0).toFloat().coerceIn(0.8f, 1.5f)
        avViews.clear(); avBmp = null

        val root = FrameLayout(this)
        root.setBackgroundColor(0xB3000000.toInt())
        root.setOnClickListener { finish() }

        // ---- ecrã de conversa dentro de um cartão arredondado
        val card = FrameLayout(this)
        card.background = round(cChatBg, 26f)
        card.clipToOutline = true
        card.isClickable = true // não fecha ao tocar dentro do cartão
        val clp = FrameLayout.LayoutParams(-1, -1)
        clp.setMargins(dp(10f), statusBarH() + dp(66f), dp(10f), dp(10f))
        root.addView(card, clp)
        if (wpBmp != null) {
            // Mesma configuração do fundo da app: posição (x/y), zoom, escurecer e desfocar.
            val wps = Store.settings(this).optJSONObject("wp")
            val wcfg = wps?.optJSONObject("c$thread") ?: wps?.optJSONObject("global")
            val wx = (wcfg?.optDouble("x", 50.0) ?: 50.0).toFloat() / 100f
            val wy = (wcfg?.optDouble("y", 50.0) ?: 50.0).toFloat() / 100f
            val wz = (wcfg?.optDouble("z", 1.05) ?: 1.05).toFloat().coerceIn(1f, 3f)
            val wdim = (wcfg?.optDouble("dim", 0.25) ?: 0.25).toFloat().coerceIn(0f, 1f)
            val wblur = (wcfg?.optDouble("blur", 0.0) ?: 0.0).toFloat().coerceIn(0f, 40f)
            val bg = ImageView(this)
            bg.scaleType = ImageView.ScaleType.CENTER_CROP
            var shown: android.graphics.Bitmap = wpBmp
            if (wblur > 0f && android.os.Build.VERSION.SDK_INT >= 31) {
                val px = wblur * resources.displayMetrics.density
                bg.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(px, px, android.graphics.Shader.TileMode.CLAMP))
            } else if (wblur > 0f) {
                // Android < 12: desfoque aproximado (reduz e volta a ampliar com filtro).
                try {
                    val k = (1f / (1f + wblur / 3f)).coerceAtLeast(0.04f)
                    val sm = android.graphics.Bitmap.createScaledBitmap(wpBmp, (wpBmp.width * k).toInt().coerceAtLeast(2), (wpBmp.height * k).toInt().coerceAtLeast(2), true)
                    shown = sm
                } catch (_: Throwable) {}
            }
            bg.setImageBitmap(shown)
            // com desfoque a margem esbate-se: amplia um pouco para a esconder (a app faz o mesmo com o zoom)
            val z = wz * (1f + wblur / 120f)
            bg.scaleX = z; bg.scaleY = z
            bg.addOnLayoutChangeListener { v, l, t, r, b, _, _, _, _ -> v.pivotX = (r - l) * wx; v.pivotY = (b - t) * wy }
            card.addView(bg, FrameLayout.LayoutParams(-1, -1))
            val dimV = View(this)
            dimV.setBackgroundColor(cChatBg)
            dimV.alpha = wdim
            card.addView(dimV, FrameLayout.LayoutParams(-1, -1))
        }
        // Como na app: as mensagens ocupam todo o cartão e o cabeçalho e a barra flutuam por cima.
        val bottomCol = LinearLayout(this)
        bottomCol.orientation = LinearLayout.VERTICAL
        bottomCol.addOnLayoutChangeListener { _, _, t, _, b, _, _, _, _ -> fadeBot = b - t; if (::scroll.isInitialized) scroll.invalidate() }

        // ---- cabeçalho: círculo de fechar + pílula com foto e nome + pílula de ações
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(10f), dp(10f), dp(10f), dp(4f))
        head.clipChildren = false
        head.clipToPadding = false
        head.addOnLayoutChangeListener { _, _, t, _, b, _, _, _, _ -> fadeTop = b - t; if (::scroll.isInitialized) scroll.invalidate() }

        val closeC = FrameLayout(this)
        floating(closeC, 48f)
        closeC.setOnClickListener { finish() }
        closeC.contentDescription = "Fechar"
        val closeI = icon(R.drawable.ic_l_close, cInk, 22f)
        closeC.addView(closeI, FrameLayout.LayoutParams(dp(22f), dp(22f), Gravity.CENTER))
        head.addView(closeC, LinearLayout.LayoutParams(dp(48f), dp(48f)))

        val who = LinearLayout(this)
        who.orientation = LinearLayout.HORIZONTAL
        who.gravity = Gravity.CENTER_VERTICAL
        who.setPadding(dp(5f), 0, dp(16f), 0)
        floating(who, 48f)
        who.setOnClickListener { openChat() }
        val av = ImageView(this)
        av.scaleType = ImageView.ScaleType.CENTER_CROP
        who.addView(av, LinearLayout.LayoutParams(dp(38f), dp(38f)))
        io.execute {
            val bmp = try { Notifier.bubbleAvatar(applicationContext, addr, name, false) } catch (_: Throwable) { null }
            runOnUiThread {
                if (!isDestroyed) {
                    if (bmp != null) av.setImageBitmap(bmp) else av.setImageResource(R.mipmap.ic_launcher)
                    avBmp = bmp
                    for (v in avViews) if (bmp != null) v.setImageBitmap(bmp) else v.setImageResource(R.mipmap.ic_launcher)
                }
            }
        }
        val t1 = TextView(this)
        t1.text = name.ifEmpty { "Mensagem" }
        t1.setTextColor(cInk)
        t1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        t1.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t1.maxLines = 1
        t1.ellipsize = android.text.TextUtils.TruncateAt.END
        val tl = LinearLayout.LayoutParams(0, -2, 1f)
        tl.leftMargin = dp(10f)
        who.addView(t1, tl)
        val wl = LinearLayout.LayoutParams(0, dp(48f), 1f)
        wl.leftMargin = dp(10f)
        head.addView(who, wl)

        if (!svc && addr.isNotEmpty()) {
            val acts = FrameLayout(this)
            floating(acts, 48f)
            acts.contentDescription = "Ligar"
            acts.setOnClickListener {
                try { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(addr)))) } catch (_: Throwable) {}
            }
            acts.addView(icon(R.drawable.ic_l_phone, cInk, 22f), FrameLayout.LayoutParams(dp(22f), dp(22f), Gravity.CENTER))
            val al = LinearLayout.LayoutParams(dp(48f), dp(48f))
            al.leftMargin = dp(10f)
            head.addView(acts, al)
        }

        // ---- conversa
        scroll = ZoomScroll(this)
        scroll.isVerticalScrollBarEnabled = false
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(14f), dp(70f), dp(14f), dp(76f))
        scroll.addView(list, FrameLayout.LayoutParams(-1, -2))
        card.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        card.addView(head, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        // O espaço reservado em cima/baixo acompanha a altura do cabeçalho e da barra (+ painel de emojis).
        head.addOnLayoutChangeListener { _, _, t, _, b, _, _, _, _ ->
            val top = (b - t) + dp(6f)
            if (list.paddingTop != top) list.setPadding(list.paddingLeft, top, list.paddingRight, list.paddingBottom)
        }
        bottomCol.addOnLayoutChangeListener { _, _, t, _, b, _, _, _, _ ->
            val bot = (b - t) + dp(4f)
            if (list.paddingBottom != bot) {
                list.setPadding(list.paddingLeft, list.paddingTop, list.paddingRight, bot)
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
        }
        // Seta "ir para a última mensagem": aparece ao rolar para cima e some quando se pára de rolar.
        val arr = FrameLayout(this)
        val ag = GradientDrawable()
        ag.shape = GradientDrawable.OVAL
        ag.setColor(cPill)
        arr.background = ag
        arr.elevation = dp(6f).toFloat()
        arr.contentDescription = "Ir para a última mensagem"
        arr.addView(icon(R.drawable.ic_l_down, cInk, 22f), FrameLayout.LayoutParams(dp(22f), dp(22f), Gravity.CENTER))
        arr.alpha = 0f
        arr.visibility = View.GONE
        val arrLp = FrameLayout.LayoutParams(dp(42f), dp(42f), Gravity.BOTTOM or Gravity.END)
        arrLp.rightMargin = dp(14f)
        arrLp.bottomMargin = dp(16f)
        arrow = arr
        arrowHide?.let { arr.removeCallbacks(it) }
        val hideArrow = Runnable {
            arr.animate().alpha(0f).setDuration(200).withEndAction { arr.visibility = View.GONE }.start()
        }
        arrowHide = hideArrow
        arr.setOnClickListener {
            arr.removeCallbacks(hideArrow)
            arr.animate().alpha(0f).setDuration(150).withEndAction { arr.visibility = View.GONE }.start()
            scroll.smoothScrollTo(0, maxOf(0, list.height - scroll.height))
        }
        bottomCol.addOnLayoutChangeListener { _, _, t, _, b, _, _, _, _ ->
            val m = (b - t) + dp(10f)
            if (arrLp.bottomMargin != m && !svc) { arrLp.bottomMargin = m; arr.layoutParams = arrLp }
        }
        scroll.setOnScrollChangeListener { _, _, y, _, oldY ->
            // Ao chegar ao topo carrega mensagens mais antigas.
            if (y == 0 && more && !loading) {
                limit += 60
                load(false)
            }
            val away = list.height - y - scroll.height
            if (scroll.isPressed || y < oldY) stick = away <= dp(80f)
            else if (away <= dp(8f)) stick = true
            if (y < oldY && away > dp(120f)) {
                if (arr.visibility != View.VISIBLE) { arr.visibility = View.VISIBLE; arr.animate().alpha(1f).setDuration(160).start() }
                arr.removeCallbacks(hideArrow)
                arr.postDelayed(hideArrow, 1600)
            } else if (y > oldY || away <= dp(120f)) {
                if (arr.visibility == View.VISIBLE) { arr.removeCallbacks(hideArrow); arr.post(hideArrow) }
            }
        }
        scroll.addOnLayoutChangeListener { _, _, t, _, b, _, ot, _, ob ->
            if (stick && (b - t) != (ob - ot)) scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
        load(true)

        // ---- barra de escrita (só quando se pode responder)
        input = null
        if (!svc) {
            val bar = LinearLayout(this)
            bar.orientation = LinearLayout.HORIZONTAL
            bar.gravity = Gravity.CENTER_VERTICAL
            bar.setPadding(dp(12f), dp(4f), dp(12f), dp(12f))
            bar.clipChildren = false
            bar.clipToPadding = false

            // campo: emoji · texto · anexo · microfone
            val field = LinearLayout(this)
            field.orientation = LinearLayout.HORIZONTAL
            field.gravity = Gravity.CENTER_VERTICAL
            floating(field, 50f)
            field.setPadding(dp(8f), 0, dp(18f), 0)
            val emo = FrameLayout(this)
            emo.addView(icon(R.drawable.ic_l_smile, 0xFFA3ABB5.toInt(), 24f), FrameLayout.LayoutParams(dp(24f), dp(24f), Gravity.CENTER))
            field.addView(emo, LinearLayout.LayoutParams(dp(38f), dp(46f)))

            val et = EditText(this)
            et.hint = if (addr.isEmpty()) "Abra a conversa para responder" else "Escreva algo…"
            et.setHintTextColor(cMute)
            et.setTextColor(cInk)
            et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            et.maxLines = 4
            et.background = null
            et.setPadding(dp(2f), dp(12f), dp(2f), dp(12f))
            et.isEnabled = addr.isNotEmpty()
            input = et
            field.addView(et, LinearLayout.LayoutParams(0, -2, 1f))
            emoIcon = emo.getChildAt(0) as ImageView
            emo.contentDescription = "Emojis"
            emo.setOnClickListener { toggleEmoji() }
            et.setOnClickListener { if (emoOpen) { hideEmoji(); showKeyboard() } }

            bar.addView(field, LinearLayout.LayoutParams(0, -2, 1f))

            // enviar: círculo com a cor de destaque, como na app
            val sendC = FrameLayout(this)
            val sg = GradientDrawable()
            sg.shape = GradientDrawable.OVAL
            sg.setColor(cAcc)
            sendC.background = sg
            sendC.elevation = dp(4f).toFloat()
            sendC.contentDescription = "Enviar"
            sendC.addView(icon(R.drawable.ic_l_send, Color.WHITE, 22f), FrameLayout.LayoutParams(dp(22f), dp(22f), Gravity.CENTER))
            sendC.setOnClickListener { send(et.text.toString()) }
            val sl = LinearLayout.LayoutParams(dp(50f), dp(50f))
            sl.leftMargin = dp(10f)
            bar.addView(sendC, sl)
            bottomCol.addView(bar, LinearLayout.LayoutParams(-1, -2))
            panel = buildEmojiPanel()
            panel!!.visibility = View.GONE
            bottomCol.addView(panel, LinearLayout.LayoutParams(-1, dp(270f)))
            card.addView(bottomCol, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        }

        if (svc) list.setPadding(list.paddingLeft, list.paddingTop, list.paddingRight, dp(16f))
        card.addView(arr, arrLp)
        setContentView(root)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        Bubbles.dock(thread) // o balão sobe para o topo enquanto a janela está aberta
        input?.let { et ->
            if (addr.isNotEmpty()) {
                et.requestFocus()
                et.postDelayed({
                    (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                        .showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
                }, 150)
            }
        }

        // Ao ver a mensagem consideramos a conversa lida e retiramos a notificação.
        io.execute {
            try {
                if (thread >= 0) {
                    Messages.markRead(applicationContext, thread, true)
                    Notifier.cancel(applicationContext, thread)
                    Events.emit("changed")
                }
            } catch (_: Throwable) {
            }
        }
    }

    // ------------------------------------------------------------------ mensagens
    private fun load(first: Boolean) {
        if (loading) return
        loading = true
        val lim = limit
        val t = thread
        val app = applicationContext
        io.execute {
            val msgs = try { Messages.recentRecs(app, t, lim) } catch (_: Throwable) { emptyList() }
            runOnUiThread {
                loading = false
                if (isDestroyed || t != thread) return@runOnUiThread
                more = msgs.size >= lim
                val oldH = list.height
                val oldY = scroll.scrollY
                cache = msgs
                renderMsgs()
                // Depois do desenho: no início vai para o fim; ao carregar antigas mantém a posição.
                val vto = list.viewTreeObserver
                vto.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
                    override fun onPreDraw(): Boolean {
                        list.viewTreeObserver.removeOnPreDrawListener(this)
                        if (first) {
                            stick = true
                            scroll.scrollTo(0, 1_000_000)
                            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
                        }
                        else scroll.scrollTo(0, oldY + (list.height - oldH))
                        return true
                    }
                })
            }
        }
    }

    private fun renderMsgs() {
        list.removeAllViews()
        avViews.clear()
        lastMine = null
        val msgs = cache
        if (msgs.isEmpty()) {
            if (fallback.isNotBlank()) addBubble(fallback, false, System.currentTimeMillis())
        } else {
            var lastDay = -1
            val cal = Calendar.getInstance()
            for (m in msgs) {
                cal.timeInMillis = m.date
                val day = cal.get(Calendar.YEAR) * 400 + cal.get(Calendar.DAY_OF_YEAR)
                if (day != lastDay) { addDay(m.date); lastDay = day }
                addBubble(m.body, m.mine, m.date, m.id, m.failed)
            }
        }
    }

    /** Uma mensagem falhou nesta conversa: volta a desenhar para mostrar o círculo de erro. */
    fun onRefresh() {
        runOnUiThread { if (!isDestroyed && !loading) load(true) }
    }

    private fun retry(id: Long) {
        val app = applicationContext
        if (!Sender.isDefault(this)) {
            Toast.makeText(this, "Defina o Chats como aplicação SMS predefinida para enviar.", Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, "A reenviar…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                Sender.retrySms(app, id, Store.bool(app, "deliveryReports", true))
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(app, e.message ?: "Não foi possível enviar.", Toast.LENGTH_LONG).show() }
            }
            Events.emit("changed")
            runOnUiThread { list.postDelayed({ if (!isDestroyed) load(true) }, 600) }
        }.start()
    }

    // ------------------------------------------------------------------ zoom com dois dedos (como na app)
    private fun applyZoom(factor: Float) {
        val z = (zoom * factor).coerceIn(0.75f, 2.2f)
        if (kotlin.math.abs(z - zoom) < 0.015f) return
        zoom = z
        val mid = (scroll.scrollY + scroll.height / 2f) / maxOf(1, list.height)
        renderMsgs()
        list.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                list.viewTreeObserver.removeOnPreDrawListener(this)
                scroll.scrollTo(0, (mid * list.height - scroll.height / 2f).toInt())
                return true
            }
        })
    }

    /** Guarda o zoom nas definições da app (o mesmo valor que a app usa nas conversas). */
    private fun saveZoom() {
        val app = applicationContext
        val z = zoom.toDouble()
        try {
            io.execute {
                try {
                    val o = Store.settings(app)
                    o.put("chatZoom", Math.round(z * 1000) / 1000.0)
                    Store.saveSettings(app, o.toString())
                } catch (_: Throwable) {
                }
            }
        } catch (_: Throwable) {
        }
    }

    private inner class ZoomScroll(c: Context) : ScrollView(c) {
        private var zooming = false
        private val det = android.view.ScaleGestureDetector(c, object : android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(d: android.view.ScaleGestureDetector): Boolean { zooming = true; return true }
            override fun onScale(d: android.view.ScaleGestureDetector): Boolean { applyZoom(d.scaleFactor); return true }
            override fun onScaleEnd(d: android.view.ScaleGestureDetector) { zooming = false; saveZoom() }
        })

        private val fp = android.graphics.Paint().apply { xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.DST_OUT) }

        /** As mensagens esbatem-se ao chegar ao cabeçalho e à barra de escrita, que continuam flutuantes. */
        override fun dispatchDraw(c: android.graphics.Canvas) {
            if (fadeTop <= 0 && fadeBot <= 0) { super.dispatchDraw(c); return }
            val y = scrollY.toFloat()
            val w = width.toFloat()
            val h = height.toFloat()
            val n = c.saveLayer(0f, y, w, y + h, null)
            super.dispatchDraw(c)
            val z = dp(26f).toFloat()
            val solid = dp(2f).toFloat()
            val k = Color.BLACK
            val none = Color.TRANSPARENT
            if (fadeTop > 0) {
                val a = (fadeTop - solid).coerceAtLeast(0f)
                fp.shader = android.graphics.LinearGradient(0f, y + a, 0f, y + a + z, k, none, android.graphics.Shader.TileMode.CLAMP)
                c.drawRect(0f, y, w, y + a + z, fp)
            }
            if (fadeBot > 0) {
                val a = (h - fadeBot + solid).coerceAtMost(h)
                fp.shader = android.graphics.LinearGradient(0f, y + a, 0f, y + a - z, k, none, android.graphics.Shader.TileMode.CLAMP)
                c.drawRect(0f, y + a - z, w, y + h, fp)
            }
            fp.shader = null
            c.restoreToCount(n)
        }

        override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
            val wasZooming = zooming
            det.onTouchEvent(ev)
            if (zooming) {
                if (!wasZooming) { // cancela o deslocamento em curso quando começa o gesto de zoom
                    val c = android.view.MotionEvent.obtain(ev)
                    c.action = android.view.MotionEvent.ACTION_CANCEL
                    super.dispatchTouchEvent(c)
                    c.recycle()
                }
                return true
            }
            return super.dispatchTouchEvent(ev)
        }
    }

    /** Separador de dia numa pílula, legível sobre qualquer fundo. */
    private fun addDay(date: Long) {
        val t = TextView(this)
        t.text = dayLabel(date)
        t.setTextColor(cMute)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.gravity = Gravity.CENTER
        t.background = round(if (wp) cPill else 0x00000000, 12f)
        t.setPadding(dp(12f), dp(4f), dp(12f), dp(4f))
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.gravity = Gravity.CENTER_HORIZONTAL
        lp.topMargin = dp(6f)
        lp.bottomMargin = dp(8f)
        list.addView(t, lp)
    }


    // ------------------------------------------------------------------ formatação igual à app
    private fun hhmm(ms: Long): String =
        java.text.SimpleDateFormat("HH:mm", Locale.ROOT).format(Date(ms))

    private fun dayLabel(ms: Long): String {
        val loc = try { Locale.forLanguageTag(Store.str(this, "lang", "pt-PT")) } catch (_: Throwable) { Locale("pt", "PT") }
        val d = Calendar.getInstance().apply { timeInMillis = ms }
        val n = Calendar.getInstance()
        fun mid(c: Calendar) = Calendar.getInstance().apply { set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH), 0, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        val diff = Math.round((mid(n) - mid(d)) / 86_400_000.0).toInt()
        if (diff == 0) return "Hoje"
        if (diff == 1) return "Ontem"
        val sameYear = d.get(Calendar.YEAR) == n.get(Calendar.YEAR)
        val pat = (if (diff in 2..6) "EEEE, " else "") + "d 'de' MMMM" + (if (sameYear) "" else " 'de' yyyy")
        return java.text.SimpleDateFormat(pat, loc).format(Date(ms))
    }

    private fun mix(a: Int, b: Int, t: Float): Int {
        fun ch(x: Int, y: Int) = (x + (y - x) * t).toInt().coerceIn(0, 255)
        return Color.argb(ch(Color.alpha(a), Color.alpha(b)), ch(Color.red(a), Color.red(b)), ch(Color.green(a), Color.green(b)), ch(Color.blue(a), Color.blue(b)))
    }

    /** Desenha o balão conforme o "Tipo de balão" das definições. Devolve o fundo e a cor do texto. */
    private fun bubbleLook(mine: Boolean): Pair<GradientDrawable, Int> {
        val base = if (mine) cSent else cRecv
        var ink = if (mine) inkOn(base) else (if (inkOn(base) == Color.WHITE) Color.WHITE else cInk)
        var r = dp(rad).toFloat()
        val s = dp(6f).toFloat()
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        var fill = base
        var grad: IntArray? = null
        var stroke = 0
        var strokeW = 0f
        when (bs) {
            "round" -> r = dp(rad + 6f).toFloat()
            "tail" -> {}
            "flat" -> r = dp(4f).toFloat()
            "grad" -> grad = intArrayOf(mix(base, Color.WHITE, if (mine) .18f else .06f), mix(base, Color.BLACK, if (mine) .22f else .10f))
            "line" -> { fill = 0; stroke = if (mine) cSent else mix(cRecv, cMute, .6f); strokeW = 1.6f; ink = cInk }
            "glass" -> {
                fill = if (mine) mix(cSent, if (dark) 0x0AFFFFFF else 0x4DFFFFFF, if (dark) .55f else .64f)
                       else (if (dark) 0x1AFFFFFF else 0x6BFFFFFF)
                stroke = if (dark) 0x2EFFFFFF else 0x99FFFFFF.toInt(); strokeW = 1f; ink = cInk
            }
            "frost" -> {
                grad = if (mine) intArrayOf(mix(cSent, 0x73FFFFFF, .32f), mix(cSent, 0x1AFFFFFF, .64f))
                       else if (dark) intArrayOf(0x2EFFFFFF, 0x0DFFFFFF) else intArrayOf(0xA8FFFFFF.toInt(), 0x38FFFFFF)
                stroke = if (dark) 0x29FFFFFF else 0x80FFFFFF.toInt(); strokeW = 1f; ink = cInk
            }
            "aurora" -> if (mine) { grad = intArrayOf(cSent, mix(cSent, 0xFFB56BFF.toInt(), .55f), mix(cSent, 0xFFFF7AB8.toInt(), .7f)); ink = Color.WHITE }
                        else { grad = if (dark) intArrayOf(0x24FFFFFF, 0x0AFFFFFF) else intArrayOf(0xB3FFFFFF.toInt(), 0x4DFFFFFF); stroke = if (dark) 0x73AA8CFF else 0x40FFFFFF; strokeW = 1.4f; ink = cInk }
            "elegant" -> if (mine) { grad = intArrayOf(0xFF26345A.toInt(), 0xFF0F1626.toInt()); stroke = 0xBFD6B25E.toInt(); strokeW = 1f; ink = 0xFFF4EAD3.toInt() }
                         else { grad = if (dark) intArrayOf(0xFF2D2921.toInt(), 0xFF1C1914.toInt()) else intArrayOf(0xFFFDFAF2.toInt(), 0xFFEFE6D2.toInt()); stroke = if (dark) 0x80D6B25E.toInt() else 0x8CBE9646.toInt(); strokeW = 1f; ink = if (dark) 0xFFEFE4CB.toInt() else 0xFF2B2418.toInt() }
            "silk" -> { r = dp(rad + 4f).toFloat(); grad = intArrayOf(mix(base, Color.WHITE, .18f), base) }
            "neon" -> { fill = 0xCC0A0E18.toInt(); stroke = if (mine) cAcc else 0xFFB57BFF.toInt(); strokeW = 1.4f; ink = 0xFFEAF6FF.toInt() }
        }
        if (grad != null) { g.colors = grad; g.orientation = GradientDrawable.Orientation.TL_BR } else g.setColor(fill)
        if (strokeW > 0f) g.setStroke(dp(strokeW).coerceAtLeast(1), stroke)
        val sq = if (bs == "flat") r else s
        // ordem: topo-esq, topo-dir, baixo-dir, baixo-esq
        g.cornerRadii = if (mine) floatArrayOf(r, r, r, r, sq, sq, r, r) else floatArrayOf(r, r, r, r, r, r, sq, sq)
        return g to ink
    }

    /** Balão igual ao da app: raio das definições, canto da "cauda" a 6 e hora dentro do balão. */
    private fun addBubble(text: String, mine: Boolean, date: Long, id: Long = -1L, failed: Boolean = false) {
        val (g, ink) = bubbleLook(mine)

        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        b.background = g
        b.setPadding(dp(14f * zoom), dp(9f * zoom), dp(14f * zoom), dp(7f * zoom))
        val tv = TextView(this)
        tv.text = text
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, fs * zoom * fscale)
        tv.setTextColor(ink)
        tv.setLineSpacing(0f, 1.1f)
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.74f).toInt()
        b.addView(tv, LinearLayout.LayoutParams(-2, -2))
        val tm = TextView(this)
        tm.text = hhmm(date)
        tm.setTextColor(ink)
        tm.alpha = 0.55f
        tm.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f * fscale)
        val tlp = LinearLayout.LayoutParams(-2, -2)
        tlp.gravity = Gravity.END
        tlp.topMargin = dp(2f)
        b.addView(tm, tlp)

        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.gravity = if (mine) Gravity.END else Gravity.START
        lp.bottomMargin = dp(6f)
        if (mine && failed && id >= 0) {
            // Falhou: círculo vermelho com "!" à esquerda do balão (como na app); tocar tenta de novo.
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val x = TextView(this)
            x.text = "!"
            x.setTextColor(Color.WHITE)
            x.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            x.typeface = Typeface.DEFAULT_BOLD
            x.gravity = Gravity.CENTER
            val xg = GradientDrawable()
            xg.shape = GradientDrawable.OVAL
            xg.setColor(0xFFE5392D.toInt())
            x.background = xg
            x.elevation = dp(2f).toFloat()
            x.contentDescription = "Falhou. Tocar para tentar novamente"
            x.setOnClickListener { retry(id) }
            val xl = LinearLayout.LayoutParams(dp(26f), dp(26f))
            xl.rightMargin = dp(6f)
            row.addView(x, xl)
            row.addView(b, LinearLayout.LayoutParams(-2, -2))
            list.addView(row, lp)
        } else if (!mine) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.BOTTOM
            val col = FrameLayout(this)
            if (lastMine != false) {
                val a = ImageView(this)
                a.scaleType = ImageView.ScaleType.CENTER_CROP
                a.background = round(cPill, 14f)
                a.clipToOutline = true
                if (avBmp != null) a.setImageBitmap(avBmp) else a.setImageResource(R.mipmap.ic_launcher)
                avViews.add(a)
                col.addView(a, FrameLayout.LayoutParams(dp(24f), dp(24f), Gravity.BOTTOM))
            }
            row.addView(col, LinearLayout.LayoutParams(dp(30f), -2))
            row.addView(b, LinearLayout.LayoutParams(-2, -2))
            list.addView(row, lp)
        } else {
            list.addView(b, lp)
        }
        lastMine = mine
    }

    // ------------------------------------------------------------------ emojis
    private fun emojis(): List<Pair<String, List<String>>> {
        emoData?.let { return it }
        val l = ArrayList<Pair<String, List<String>>>()
        try {
            resources.openRawResource(R.raw.emoji).bufferedReader(Charsets.UTF_8).useLines { seq ->
                for (line in seq) {
                    val i = line.indexOf('|')
                    if (i > 0) l.add(line.substring(0, i) to line.substring(i + 1).split(' ').filter { it.isNotBlank() })
                }
            }
        } catch (_: Throwable) {
        }
        emoData = l
        return l
    }

    private fun showKeyboard() {
        val et = input ?: return
        et.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideKeyboard() {
        val et = input ?: return
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(et.windowToken, 0)
    }

    private fun toggleEmoji() {
        if (emoOpen) { hideEmoji(); showKeyboard() } else { hideKeyboard(); showEmoji() }
    }

    private fun showEmoji() {
        val p = panel ?: return
        drawEmoji()
        p.visibility = View.VISIBLE
        emoOpen = true
        emoIcon?.setColorFilter(cAcc)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun hideEmoji() {
        panel?.visibility = View.GONE
        emoOpen = false
        emoIcon?.setColorFilter(0xFFA3ABB5.toInt())
    }

    private fun buildEmojiPanel(): LinearLayout {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.setBackgroundColor(cPill)
        return p
    }

    /** Separadores de categorias + grelha de emojis + apagar (mesma lista da app). */
    private fun drawEmoji() {
        val p = panel ?: return
        p.removeAllViews()
        val data = emojis()
        if (data.isEmpty()) return
        if (emoCat >= data.size) emoCat = 0

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.gravity = Gravity.CENTER_VERTICAL
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        data.forEachIndexed { idx, c ->
            val t = TextView(this)
            t.text = c.first
            t.gravity = Gravity.CENTER
            t.setTextColor(cInk) // opaco: o tema Material deixa o texto a 54 % e isso esbate os emojis
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            if (idx == emoCat) t.background = round(if (dark) 0x331F7BFF else 0x1A3390EC, 14f)
            t.setOnClickListener { emoCat = idx; drawEmoji() }
            row.addView(t, LinearLayout.LayoutParams(dp(44f), dp(40f)))
        }
        hs.addView(row)
        tabs.addView(hs, LinearLayout.LayoutParams(0, -2, 1f))
        val bs = TextView(this)
        bs.text = "⌫"
        bs.gravity = Gravity.CENTER
        bs.setTextColor(cInk)
        bs.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        bs.contentDescription = "Apagar"
        bs.setOnClickListener {
            val et = input ?: return@setOnClickListener
            et.dispatchKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_DEL))
            et.dispatchKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_DEL))
        }
        tabs.addView(bs, LinearLayout.LayoutParams(dp(48f), dp(40f)))
        p.addView(tabs, LinearLayout.LayoutParams(-1, dp(44f)))

        val sv = ScrollView(this)
        val grid = android.widget.GridLayout(this)
        val cols = 8
        grid.columnCount = cols
        val cell = (resources.displayMetrics.widthPixels - dp(20f)) / cols
        for (e in data[emoCat].second) {
            val t = TextView(this)
            t.text = e
            t.gravity = Gravity.CENTER
            t.setTextColor(cInk)
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
            t.setOnClickListener {
                val et = input ?: return@setOnClickListener
                val st = et.selectionStart.coerceAtLeast(0)
                val en = et.selectionEnd.coerceAtLeast(0)
                et.text.replace(minOf(st, en), maxOf(st, en), e)
            }
            grid.addView(t, android.widget.GridLayout.LayoutParams().also { lp -> lp.width = cell; lp.height = dp(46f) })
        }
        sv.addView(grid)
        p.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun openChat() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra("thread", thread)
            )
        } catch (_: Throwable) {
        }
        finish()
    }

    private fun send(text: String) {
        val body = text.trim()
        val et = input ?: return
        if (body.isEmpty() || addr.isEmpty()) return
        if (!Sender.isDefault(this)) {
            Toast.makeText(this, "Defina o Chats como aplicação SMS predefinida para enviar.", Toast.LENGTH_LONG).show()
            return
        }
        et.setText("")
        addBubble(body, true, System.currentTimeMillis())
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        val app = applicationContext
        val a = addr
        val t = thread
        // Fora do ciclo de vida da janela: o envio não pode ser cancelado se a janela fechar.
        Thread {
            try {
                val chosen = Store.settings(app).optInt("sub", -1)
                val sub = if (chosen >= 0) chosen else SubscriptionManager.getDefaultSmsSubscriptionId()
                Sender.sendSms(app, listOf(a), body, sub, Store.bool(app, "deliveryReports", true))
                if (t >= 0) Messages.markRead(app, t, true)
                Notifier.cancel(app, t)
                Events.emit("changed")
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(app, e.message ?: "Não foi possível enviar.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}
