package app.chats.sms

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.telephony.SubscriptionManager
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.DateFormat
import java.util.Calendar
import java.util.Date
import java.util.concurrent.Executors

/**
 * Janela de resposta aberta pelo balão flutuante. Reproduz o ecrã de conversa da app: cabeçalho em
 * pílulas, balões iguais, fundo da conversa e barra de escrita com o enviar em círculo.
 * Mensagens antigas carregam ao subir até ao topo.
 */
class ReplyActivity : Activity() {
    companion object {
        @Volatile var live: ReplyActivity? = null
    }

    private val io = Executors.newSingleThreadExecutor()
    private var thread = -1L
    private var addr = ""
    private var name = ""
    private var svc = false
    private var dark = false
    private var fallback = ""
    private var limit = 60
    private var more = false
    private var loading = false
    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private var input: EditText? = null
    private var zoom = 1f
    private var cache: List<Triple<String, Long, Boolean>> = emptyList()
    private var panel: LinearLayout? = null
    private var emoIcon: ImageView? = null
    private var emoOpen = false
    private var emoCat = 0
    private var emoData: List<Pair<String, List<String>>>? = null

    // Cores iguais às da app (tema claro / escuro)
    private var cSent = 0
    private var cRecv = 0
    private var fs = 16f
    private var rad = 18f
    private var wp = false
    private val cAcc get() = if (dark) 0xFF4DA3F7.toInt() else 0xFF3390EC.toInt()
    private val cInk get() = if (dark) 0xFFF2F2F2.toInt() else 0xFF0F1419.toInt()
    private val cMute get() = if (dark) 0xFF8E8E93.toInt() else 0xFF7E8791.toInt()
    private val cPill get() = if (dark) 0xFF1C1C1E.toInt() else Color.WHITE
    private val cChatBg get() = if (dark) Color.BLACK else 0xFFE4EBF2.toInt()

    private fun dp(v: Float) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun round(color: Int, r: Float): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = dp(r).toFloat()
        g.setColor(color)
        return g
    }

    private fun inkOn(bg: Int): Int {
        val l = (0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)) / 255.0
        return if (l > 0.62) 0xFF0F1419.toInt() else Color.WHITE
    }

    private fun icon(res: Int, tint: Int, sizeDp: Float): ImageView {
        val v = ImageView(this)
        v.setImageResource(res)
        v.setColorFilter(tint)
        v.scaleType = ImageView.ScaleType.FIT_CENTER
        v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return v
    }

    /** Pílula flutuante (como as do ecrã de conversa): fundo da app com sombra suave. */
    private fun floating(v: View, h: Float, fill: Int = cPill) {
        v.background = round(fill, h / 2f)
        v.elevation = dp(4f).toFloat()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        live = this
        build(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        Bubbles.undock(thread)
        setIntent(intent)
        build(intent)
    }

    /** O balão começa a voltar ao seu lugar logo que a janela começa a fechar (animação suave). */
    override fun finish() {
        Bubbles.undock(thread)
        super.finish()
    }

    /** Ao sair para outra app / ecrã inicial a janela fecha e o balão volta ao seu lugar. */
    override fun onStop() {
        if (!isChangingConfigurations && !isFinishing) finish()
        super.onStop()
    }

    override fun onDestroy() {
        if (live === this) live = null
        Bubbles.undock(thread)
        io.shutdownNow()
        super.onDestroy()
    }

    /** Chega uma mensagem da conversa que está aberta: atualiza logo, sem tocar no balão. */
    fun isShowing(t: Long) = t == thread

    fun onIncoming() {
        val app = applicationContext
        val t = thread
        runOnUiThread {
            if (isDestroyed) return@runOnUiThread
            if (loading) list.postDelayed({ if (!isDestroyed) load(true) }, 300) else load(true)
        }
        try {
            io.execute {
                try {
                    Messages.markRead(app, t, true)
                    Notifier.cancel(app, t)
                    Events.emit("changed")
                } catch (_: Throwable) {
                }
            }
        } catch (_: Throwable) {
        }
    }

    private fun isDark(): Boolean = when (Store.str(this, "theme", "auto")) {
        "dark" -> true
        "light" -> false
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private fun statusBarH(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(24f)
    }

    private fun parse(s: String?): Int? = try {
        if (s.isNullOrBlank()) null else Color.parseColor(s)
    } catch (_: Exception) {
        null
    }

    private fun wallpaper(): File? {
        val d = File(filesDir, "wallpapers")
        val f1 = File(d, "c$thread.jpg")
        if (f1.exists()) return f1
        val f2 = File(d, "global.jpg")
        return if (f2.exists()) f2 else null
    }

    private fun build(i: Intent) {
        thread = i.getLongExtra("thread", -1L)
        addr = i.getStringExtra("addr") ?: ""
        name = i.getStringExtra("name")?.ifBlank { null } ?: addr
        fallback = i.getStringExtra("body") ?: ""
        svc = Notifier.isService(addr)
        dark = isDark()
        zoom = Store.settings(this).optDouble("chatZoom", 1.0).toFloat().coerceIn(0.75f, 2.2f)
        limit = 60
        more = false
        loading = false

        val wpFile = try { wallpaper() } catch (_: Throwable) { null }
        val wpBmp = try { if (wpFile != null) BitmapFactory.decodeFile(wpFile.absolutePath) else null } catch (_: Throwable) { null }
        wp = wpBmp != null
        val bub = Store.settings(this).optJSONObject("bub")
        cSent = parse(bub?.optString("sent")) ?: (if (dark) 0xFF2B5278.toInt() else 0xFF3A8FE8.toInt())
        cRecv = parse(bub?.optString("recv")) ?: (if (dark) 0xFF1C1C1E.toInt() else Color.WHITE)
        rad = (bub?.optDouble("r", 18.0) ?: 18.0).toFloat().coerceIn(6f, 28f)
        fs = (bub?.optDouble("fs", 16.0) ?: 16.0).toFloat().coerceIn(13f, 22f)

        val root = FrameLayout(this)
        root.setBackgroundColor(0xB3000000.toInt())
        root.setOnClickListener { finish() }

        // ---- ecrã de conversa dentro de um cartão arredondado
        val card = FrameLayout(this)
        card.background = round(cChatBg, 26f)
        card.clipToOutline = true
        card.isClickable = true // não fecha ao tocar dentro do cartão
        val clp = FrameLayout.LayoutParams(-1, -1)
        clp.setMargins(dp(10f), statusBarH() + dp(66f), dp(10f), dp(10f))
        root.addView(card, clp)
        if (wpBmp != null) {
            val bg = ImageView(this)
            bg.scaleType = ImageView.ScaleType.CENTER_CROP
            bg.setImageBitmap(wpBmp)
            card.addView(bg, FrameLayout.LayoutParams(-1, -1))
        }
        // Como na app: as mensagens ocupam todo o cartão e o cabeçalho e a barra flutuam por cima.
        val bottomCol = LinearLayout(this)
        bottomCol.orientation = LinearLayout.VERTICAL

        // ---- cabeçalho: círculo de fechar + pílula com foto e nome + pílula de ações
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(10f), dp(10f), dp(10f), dp(4f))
        head.clipChildren = false
        head.clipToPadding = false

        val closeC = FrameLayout(this)
        floating(closeC, 48f)
        closeC.setOnClickListener { finish() }
        closeC.contentDescription = "Fechar"
        val closeI = icon(R.drawable.ic_l_close, cInk, 22f)
        closeC.addView(closeI, FrameLayout.LayoutParams(dp(22f), dp(22f), Gravity.CENTER))
        head.addView(closeC, LinearLayout.LayoutParams(dp(48f), dp(48f)))

        val who = LinearLayout(this)
        who.orientation = LinearLayout.HORIZONTAL
        who.gravity = Gravity.CENTER_VERTICAL
        who.setPadding(dp(5f), 0, dp(16f), 0)
        floating(who, 48f)
        who.setOnClickListener { openChat() }
        val av = ImageView(this)
        av.scaleType = ImageView.ScaleType.CENTER_CROP
        who.addView(av, LinearLayout.LayoutParams(dp(38f), dp(38f)))
        io.execute {
            val bmp = try { Notifier.bubbleAvatar(applicationContext, addr, name, false) } catch (_: Throwable) { null }
            runOnUiThread {
                if (!isDestroyed) { if (bmp != null) av.setImageBitmap(bmp) else av.setImageResource(R.mipmap.ic_launcher) }
            }
        }
        val t1 = TextView(this)
        t1.text = name.ifEmpty { "Mensagem" }
        t1.setTextColor(cInk)
        t1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        t1.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t1.maxLines = 1
        t1.ellipsize = android.text.TextUtils.TruncateAt.END
        val tl = LinearLayout.LayoutParams(0, -2, 1f)
        tl.leftMargin = dp(10f)
        who.addView(t1, tl)
        val wl = LinearLayout.LayoutParams(0, dp(48f), 1f)
        wl.leftMargin = dp(10f)
        head.addView(who, wl)

        if (!svc && addr.isNotEmpty()) {
            val acts = FrameLayout(this)
            floating(acts, 48f)
            acts.contentDescription = "Ligar"
            acts.setOnClickListener {
                try { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(addr)))) } catch (_: Throwable) {}
            }
            acts.addView(icon(R.drawable.ic_l_phone, cInk, 22f), FrameLayout.LayoutParams(dp(22f), dp(22f), Gravity.CENTER))
            val al = LinearLayout.LayoutParams(dp(48f), dp(48f))
            al.leftMargin = dp(10f)
            head.addView(acts, al)
        }

        // ---- conversa
        scroll = ZoomScroll(this)
        scroll.isVerticalScrollBarEnabled = false
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(14f), dp(70f), dp(14f), dp(76f))
        scroll.addView(list, FrameLayout.LayoutParams(-1, -2))
        card.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        card.addView(head, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        // O espaço reservado em cima/baixo acompanha a altura do cabeçalho e da barra (+ painel de emojis).
        head.addOnLayoutChangeListener { _, _, t, _, b, _, _, _, _ ->
            val top = (b - t) + dp(6f)
            if (list.paddingTop != top) list.setPadding(list.paddingLeft, top, list.paddingRight, list.paddingBottom)
        }
        bottomCol.addOnLayoutChangeListener { _, _, t, _, b, _, _, _, _ ->
            val bot = (b - t) + dp(4f)
            if (list.paddingBottom != bot) {
                list.setPadding(list.paddingLeft, list.paddingTop, list.paddingRight, bot)
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
        }
        scroll.setOnScrollChangeListener { _, _, y, _, _ ->
            // Ao chegar ao topo carrega mensagens mais antigas.
            if (y == 0 && more && !loading) {
                limit += 60
                load(false)
            }
        }
        load(true)

        // ---- barra de escrita (só quando se pode responder)
        input = null
        if (!svc) {
            val bar = LinearLayout(this)
            bar.orientation = LinearLayout.HORIZONTAL
            bar.gravity = Gravity.CENTER_VERTICAL
            bar.setPadding(dp(12f), dp(4f), dp(12f), dp(12f))
            bar.clipChildren = false
            bar.clipToPadding = false

            // campo: emoji · texto · anexo · microfone
            val field = LinearLayout(this)
            field.orientation = LinearLayout.HORIZONTAL
            field.gravity = Gravity.CENTER_VERTICAL
            floating(field, 50f)
            field.setPadding(dp(8f), 0, dp(18f), 0)
            val emo = FrameLayout(this)
            emo.addView(icon(R.drawable.ic_l_smile, 0xFFA3ABB5.toInt(), 24f), FrameLayout.LayoutParams(dp(24f), dp(24f), Gravity.CENTER))
            field.addView(emo, LinearLayout.LayoutParams(dp(38f), dp(46f)))

            val et = EditText(this)
            et.hint = if (addr.isEmpty()) "Abra a conversa para responder" else "Escreva algo…"
            et.setHintTextColor(cMute)
            et.setTextColor(cInk)
            et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            et.maxLines = 4
            et.background = null
            et.setPadding(dp(2f), dp(12f), dp(2f), dp(12f))
            et.isEnabled = addr.isNotEmpty()
            input = et
            field.addView(et, LinearLayout.LayoutParams(0, -2, 1f))
            emoIcon = emo.getChildAt(0) as ImageView
            emo.contentDescription = "Emojis"
            emo.setOnClickListener { toggleEmoji() }
            et.setOnClickListener { if (emoOpen) { hideEmoji(); showKeyboard() } }

            bar.addView(field, LinearLayout.LayoutParams(0, -2, 1f))

            // enviar: círculo com a cor de destaque, como na app
            val sendC = FrameLayout(this)
            val sg = GradientDrawable()
            sg.shape = GradientDrawable.OVAL
            sg.setColor(cAcc)
            sendC.background = sg
            sendC.elevation = dp(4f).toFloat()
            sendC.contentDescription = "Enviar"
            sendC.addView(icon(R.drawable.ic_l_send, Color.WHITE, 22f), FrameLayout.LayoutParams(dp(22f), dp(22f), Gravity.CENTER))
            sendC.setOnClickListener { send(et.text.toString()) }
            val sl = LinearLayout.LayoutParams(dp(50f), dp(50f))
            sl.leftMargin = dp(10f)
            bar.addView(sendC, sl)
            bottomCol.addView(bar, LinearLayout.LayoutParams(-1, -2))
            panel = buildEmojiPanel()
            panel!!.visibility = View.GONE
            bottomCol.addView(panel, LinearLayout.LayoutParams(-1, dp(270f)))
            card.addView(bottomCol, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        }

        if (svc) list.setPadding(list.paddingLeft, list.paddingTop, list.paddingRight, dp(16f))
        setContentView(root)
        Bubbles.dock(thread) // o balão sobe para o topo enquanto a janela está aberta
        input?.let { et ->
            if (addr.isNotEmpty()) {
                et.requestFocus()
                et.postDelayed({
                    (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                        .showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
                }, 150)
            }
        }

        // Ao ver a mensagem consideramos a conversa lida e retiramos a notificação.
        io.execute {
            try {
                if (thread >= 0) {
                    Messages.markRead(applicationContext, thread, true)
                    Notifier.cancel(applicationContext, thread)
                    Events.emit("changed")
                }
            } catch (_: Throwable) {
            }
        }
    }

    // ------------------------------------------------------------------ mensagens
    private fun load(first: Boolean) {
        if (loading) return
        loading = true
        val lim = limit
        val t = thread
        val app = applicationContext
        io.execute {
            val msgs = try { Messages.recent(app, t, lim) } catch (_: Throwable) { emptyList() }
            runOnUiThread {
                loading = false
                if (isDestroyed || t != thread) return@runOnUiThread
                more = msgs.size >= lim
                val oldH = list.height
                val oldY = scroll.scrollY
                cache = msgs
                renderMsgs()
                // Depois do desenho: no início vai para o fim; ao carregar antigas mantém a posição.
                val vto = list.viewTreeObserver
                vto.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
                    override fun onPreDraw(): Boolean {
                        list.viewTreeObserver.removeOnPreDrawListener(this)
                        if (first) scroll.scrollTo(0, 1_000_000)
                        else scroll.scrollTo(0, oldY + (list.height - oldH))
                        return true
                    }
                })
            }
        }
    }

    private fun renderMsgs() {
        list.removeAllViews()
        val msgs = cache
        if (msgs.isEmpty()) {
            if (fallback.isNotBlank()) addBubble(fallback, false, System.currentTimeMillis())
        } else {
            var lastDay = -1
            val cal = Calendar.getInstance()
            for (m in msgs) {
                cal.timeInMillis = m.second
                val day = cal.get(Calendar.YEAR) * 400 + cal.get(Calendar.DAY_OF_YEAR)
                if (day != lastDay) { addDay(m.second); lastDay = day }
                addBubble(m.first, m.third, m.second)
            }
        }
    }

    // ------------------------------------------------------------------ zoom com dois dedos (como na app)
    private fun applyZoom(factor: Float) {
        val z = (zoom * factor).coerceIn(0.75f, 2.2f)
        if (kotlin.math.abs(z - zoom) < 0.015f) return
        zoom = z
        val mid = (scroll.scrollY + scroll.height / 2f) / maxOf(1, list.height)
        renderMsgs()
        list.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                list.viewTreeObserver.removeOnPreDrawListener(this)
                scroll.scrollTo(0, (mid * list.height - scroll.height / 2f).toInt())
                return true
            }
        })
    }

    /** Guarda o zoom nas definições da app (o mesmo valor que a app usa nas conversas). */
    private fun saveZoom() {
        val app = applicationContext
        val z = zoom.toDouble()
        try {
            io.execute {
                try {
                    val o = Store.settings(app)
                    o.put("chatZoom", Math.round(z * 1000) / 1000.0)
                    Store.saveSettings(app, o.toString())
                } catch (_: Throwable) {
                }
            }
        } catch (_: Throwable) {
        }
    }

    private inner class ZoomScroll(c: Context) : ScrollView(c) {
        private var zooming = false
        private val det = android.view.ScaleGestureDetector(c, object : android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(d: android.view.ScaleGestureDetector): Boolean { zooming = true; return true }
            override fun onScale(d: android.view.ScaleGestureDetector): Boolean { applyZoom(d.scaleFactor); return true }
            override fun onScaleEnd(d: android.view.ScaleGestureDetector) { zooming = false; saveZoom() }
        })

        override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
            val wasZooming = zooming
            det.onTouchEvent(ev)
            if (zooming) {
                if (!wasZooming) { // cancela o deslocamento em curso quando começa o gesto de zoom
                    val c = android.view.MotionEvent.obtain(ev)
                    c.action = android.view.MotionEvent.ACTION_CANCEL
                    super.dispatchTouchEvent(c)
                    c.recycle()
                }
                return true
            }
            return super.dispatchTouchEvent(ev)
        }
    }

    /** Separador de dia numa pílula, legível sobre qualquer fundo. */
    private fun addDay(date: Long) {
        val t = TextView(this)
        t.text = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(date))
        t.setTextColor(cMute)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.gravity = Gravity.CENTER
        t.background = round(if (wp) cPill else 0x00000000, 12f)
        t.setPadding(dp(12f), dp(4f), dp(12f), dp(4f))
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.gravity = Gravity.CENTER_HORIZONTAL
        lp.topMargin = dp(6f)
        lp.bottomMargin = dp(8f)
        list.addView(t, lp)
    }

    /** Balão igual ao da app: raio das definições, canto da "cauda" a 6 e hora dentro do balão. */
    private fun addBubble(text: String, mine: Boolean, date: Long) {
        val bg = if (mine) cSent else cRecv
        val ink = if (mine) inkOn(bg) else (if (inkOn(bg) == Color.WHITE) Color.WHITE else cInk)
        val r = dp(rad).toFloat()
        val s = dp(6f).toFloat()
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.setColor(bg)
        // ordem: topo-esq, topo-dir, baixo-dir, baixo-esq
        g.cornerRadii = if (mine) floatArrayOf(r, r, r, r, s, s, r, r) else floatArrayOf(r, r, r, r, r, r, s, s)

        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        b.background = g
        b.setPadding(dp(14f * zoom), dp(9f * zoom), dp(14f * zoom), dp(7f * zoom))
        val tv = TextView(this)
        tv.text = text
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, fs * zoom)
        tv.setTextColor(ink)
        tv.setLineSpacing(0f, 1.1f)
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.74f).toInt()
        b.addView(tv, LinearLayout.LayoutParams(-2, -2))
        val tm = TextView(this)
        tm.text = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(date))
        tm.setTextColor(ink)
        tm.alpha = 0.55f
        tm.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        val tlp = LinearLayout.LayoutParams(-2, -2)
        tlp.gravity = Gravity.END
        tlp.topMargin = dp(2f)
        b.addView(tm, tlp)

        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.gravity = if (mine) Gravity.END else Gravity.START
        lp.bottomMargin = dp(6f)
        list.addView(b, lp)
    }

    // ------------------------------------------------------------------ emojis
    private fun emojis(): List<Pair<String, List<String>>> {
        emoData?.let { return it }
        val l = ArrayList<Pair<String, List<String>>>()
        try {
            resources.openRawResource(R.raw.emoji).bufferedReader(Charsets.UTF_8).useLines { seq ->
                for (line in seq) {
                    val i = line.indexOf('|')
                    if (i > 0) l.add(line.substring(0, i) to line.substring(i + 1).split(' ').filter { it.isNotBlank() })
                }
            }
        } catch (_: Throwable) {
        }
        emoData = l
        return l
    }

    private fun showKeyboard() {
        val et = input ?: return
        et.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideKeyboard() {
        val et = input ?: return
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(et.windowToken, 0)
    }

    private fun toggleEmoji() {
        if (emoOpen) { hideEmoji(); showKeyboard() } else { hideKeyboard(); showEmoji() }
    }

    private fun showEmoji() {
        val p = panel ?: return
        drawEmoji()
        p.visibility = View.VISIBLE
        emoOpen = true
        emoIcon?.setColorFilter(cAcc)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun hideEmoji() {
        panel?.visibility = View.GONE
        emoOpen = false
        emoIcon?.setColorFilter(0xFFA3ABB5.toInt())
    }

    private fun buildEmojiPanel(): LinearLayout {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.setBackgroundColor(cPill)
        return p
    }

    /** Separadores de categorias + grelha de emojis + apagar (mesma lista da app). */
    private fun drawEmoji() {
        val p = panel ?: return
        p.removeAllViews()
        val data = emojis()
        if (data.isEmpty()) return
        if (emoCat >= data.size) emoCat = 0

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.gravity = Gravity.CENTER_VERTICAL
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        data.forEachIndexed { idx, c ->
            val t = TextView(this)
            t.text = c.first
            t.gravity = Gravity.CENTER
            t.setTextColor(cInk) // opaco: o tema Material deixa o texto a 54 % e isso esbate os emojis
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            if (idx == emoCat) t.background = round(if (dark) 0x331F7BFF else 0x1A3390EC, 14f)
            t.setOnClickListener { emoCat = idx; drawEmoji() }
            row.addView(t, LinearLayout.LayoutParams(dp(44f), dp(40f)))
        }
        hs.addView(row)
        tabs.addView(hs, LinearLayout.LayoutParams(0, -2, 1f))
        val bs = TextView(this)
        bs.text = "⌫"
        bs.gravity = Gravity.CENTER
        bs.setTextColor(cInk)
        bs.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        bs.contentDescription = "Apagar"
        bs.setOnClickListener {
            val et = input ?: return@setOnClickListener
            et.dispatchKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_DEL))
            et.dispatchKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_DEL))
        }
        tabs.addView(bs, LinearLayout.LayoutParams(dp(48f), dp(40f)))
        p.addView(tabs, LinearLayout.LayoutParams(-1, dp(44f)))

        val sv = ScrollView(this)
        val grid = android.widget.GridLayout(this)
        val cols = 8
        grid.columnCount = cols
        val cell = (resources.displayMetrics.widthPixels - dp(20f)) / cols
        for (e in data[emoCat].second) {
            val t = TextView(this)
            t.text = e
            t.gravity = Gravity.CENTER
            t.setTextColor(cInk)
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
            t.setOnClickListener {
                val et = input ?: return@setOnClickListener
                val st = et.selectionStart.coerceAtLeast(0)
                val en = et.selectionEnd.coerceAtLeast(0)
                et.text.replace(minOf(st, en), maxOf(st, en), e)
            }
            grid.addView(t, android.widget.GridLayout.LayoutParams().also { lp -> lp.width = cell; lp.height = dp(46f) })
        }
        sv.addView(grid)
        p.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun openChat() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra("thread", thread)
            )
        } catch (_: Throwable) {
        }
        finish()
    }

    private fun send(text: String) {
        val body = text.trim()
        val et = input ?: return
        if (body.isEmpty() || addr.isEmpty()) return
        if (!Sender.isDefault(this)) {
            Toast.makeText(this, "Defina o Chats como aplicação SMS predefinida para enviar.", Toast.LENGTH_LONG).show()
            return
        }
        et.setText("")
        addBubble(body, true, System.currentTimeMillis())
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        val app = applicationContext
        val a = addr
        val t = thread
        // Fora do ciclo de vida da janela: o envio não pode ser cancelado se a janela fechar.
        Thread {
            try {
                val chosen = Store.settings(app).optInt("sub", -1)
                val sub = if (chosen >= 0) chosen else SubscriptionManager.getDefaultSmsSubscriptionId()
                Sender.sendSms(app, listOf(a), body, sub, Store.bool(app, "deliveryReports", true))
                if (t >= 0) Messages.markRead(app, t, true)
                Notifier.cancel(app, t)
                Events.emit("changed")
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(app, e.message ?: "Não foi possível enviar.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}
