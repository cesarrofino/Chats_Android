package app.chats.sms

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.telephony.SubscriptionManager
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.DateFormat
import java.util.Calendar
import java.util.Date
import java.util.concurrent.Executors

/**
 * Janela de resposta aberta pelo balão flutuante, já expandida: cabeçalho com foto e nome, conversa
 * com mensagens antigas (carregam mais ao subir), fundo da conversa e campo de resposta em baixo.
 */
class ReplyActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private var thread = -1L
    private var addr = ""
    private var name = ""
    private var svc = false
    private var dark = false
    private var wp = false
    private var fallback = ""
    private var limit = 60
    private var more = false
    private var loading = false
    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private var input: EditText? = null

    private val brand = 0xFF1F7BFF.toInt()
    private var cSent = brand
    private var cRecv = 0
    private val cCard get() = if (dark) 0xFF1C1C1E.toInt() else Color.WHITE
    private val cText get() = if (wp || dark) Color.WHITE else 0xFF111114.toInt()
    private val cSub get() = if (wp) 0xFFE6E6EA.toInt() else if (dark) 0xFF9A9AA0.toInt() else 0xFF6B6B72.toInt()
    private val cField get() = if (dark) 0xFF2C2C2E.toInt() else Color.WHITE

    private fun dp(v: Float) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun round(color: Int, r: Float): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = dp(r).toFloat()
        g.setColor(color)
        return g
    }

    private fun inkOn(bg: Int): Int {
        val l = (0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)) / 255.0
        return if (l > 0.62) 0xFF111114.toInt() else Color.WHITE
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        build(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        build(intent)
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    private fun isDark(): Boolean = when (Store.str(this, "theme", "auto")) {
        "dark" -> true
        "light" -> false
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private fun parse(s: String?): Int? = try {
        if (s.isNullOrBlank()) null else Color.parseColor(s)
    } catch (_: Exception) {
        null
    }

    private fun wallpaper(): File? {
        val d = File(filesDir, "wallpapers")
        val f1 = File(d, "c$thread.jpg")
        if (f1.exists()) return f1
        val f2 = File(d, "global.jpg")
        return if (f2.exists()) f2 else null
    }

    private fun build(i: Intent) {
        thread = i.getLongExtra("thread", -1L)
        addr = i.getStringExtra("addr") ?: ""
        name = i.getStringExtra("name")?.ifBlank { null } ?: addr
        fallback = i.getStringExtra("body") ?: ""
        svc = Notifier.isService(addr)
        dark = isDark()
        limit = 60
        more = false
        loading = false

        val wpFile = try { wallpaper() } catch (_: Throwable) { null }
        val wpBmp = try { if (wpFile != null) BitmapFactory.decodeFile(wpFile.absolutePath) else null } catch (_: Throwable) { null }
        wp = wpBmp != null
        val bub = Store.settings(this).optJSONObject("bub")
        cSent = parse(bub?.optString("sent")) ?: brand
        cRecv = parse(bub?.optString("recv")) ?: (if (wp) 0xE62C2C2E.toInt() else if (dark) 0xFF2C2C2E.toInt() else 0xFFEEF0F3.toInt())

        val root = FrameLayout(this)
        root.setBackgroundColor(0xB3000000.toInt())
        root.setOnClickListener { finish() }

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14f), dp(52f), dp(14f), dp(12f))
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        // ---- cartão expandido (fundo + cabeçalho + conversa)
        val card = FrameLayout(this)
        card.background = round(cCard, 26f)
        card.clipToOutline = true
        card.isClickable = true // não fecha ao tocar dentro do cartão
        if (wpBmp != null) {
            val bg = ImageView(this)
            bg.scaleType = ImageView.ScaleType.CENTER_CROP
            bg.setImageBitmap(wpBmp)
            card.addView(bg, FrameLayout.LayoutParams(-1, -1))
            val scrim = View(this)
            scrim.setBackgroundColor(0x33000000)
            card.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        }
        val inner = LinearLayout(this)
        inner.orientation = LinearLayout.VERTICAL
        card.addView(inner, FrameLayout.LayoutParams(-1, -1))
        col.addView(card, LinearLayout.LayoutParams(-1, 0, 1f))

        // cabeçalho
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(16f), dp(16f), dp(12f), dp(8f))
        val av = ImageView(this)
        av.scaleType = ImageView.ScaleType.CENTER_CROP
        head.addView(av, LinearLayout.LayoutParams(dp(46f), dp(46f)))
        io.execute {
            val bmp = try { Notifier.bubbleAvatar(applicationContext, addr, name, false) } catch (_: Throwable) { null }
            runOnUiThread { if (bmp != null && !isDestroyed) av.setImageBitmap(bmp) else if (!isDestroyed) av.setImageResource(R.mipmap.ic_launcher) }
        }
        val t1 = TextView(this)
        t1.text = name.ifEmpty { "Mensagem" }
        t1.setTextColor(cText)
        t1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
        t1.typeface = Typeface.DEFAULT_BOLD
        t1.maxLines = 1
        t1.ellipsize = android.text.TextUtils.TruncateAt.END
        if (wp) t1.setShadowLayer(6f, 0f, 1f, 0x99000000.toInt())
        val tl = LinearLayout.LayoutParams(0, -2, 1f)
        tl.leftMargin = dp(12f)
        head.addView(t1, tl)
        if (!svc && addr.isNotEmpty()) {
            head.addView(iconBtn("📞", "Ligar") {
                try { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(addr)))) } catch (_: Throwable) {}
            })
        }
        head.addView(iconBtn("✕", "Fechar") { finish() })
        inner.addView(head)

        // conversa
        scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(14f), dp(6f), dp(14f), dp(10f))
        scroll.addView(list, FrameLayout.LayoutParams(-1, -2))
        inner.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        scroll.setOnScrollChangeListener { _, _, y, _, _ ->
            // Ao chegar ao topo carrega mensagens mais antigas.
            if (y == 0 && more && !loading) {
                limit += 60
                load(false)
            }
        }
        load(true)

        // ---- respostas rápidas + campo (só quando se pode responder)
        input = null
        if (!svc) {
            val quick = try { Store.settings(this).optJSONArray("quick") } catch (_: Throwable) { null }
            if (quick != null && quick.length() > 0 && addr.isNotEmpty()) {
                val hs = HorizontalScrollView(this)
                hs.isHorizontalScrollBarEnabled = false
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                for (k in 0 until minOf(quick.length(), 8)) {
                    val q = quick.optString(k).trim()
                    if (q.isEmpty()) continue
                    val chip = pill(if (q.length > 28) q.take(28) + "…" else q) { send(q) }
                    val lp = LinearLayout.LayoutParams(-2, -2)
                    lp.rightMargin = dp(8f)
                    row.addView(chip, lp)
                }
                hs.addView(row)
                val hl = LinearLayout.LayoutParams(-1, -2)
                hl.topMargin = dp(8f)
                col.addView(hs, hl)
            }

            val bar = LinearLayout(this)
            bar.orientation = LinearLayout.HORIZONTAL
            bar.gravity = Gravity.CENTER_VERTICAL
            val open = TextView(this)
            open.text = "›"
            open.gravity = Gravity.CENTER
            open.setTextColor(Color.WHITE)
            open.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f)
            open.contentDescription = "Abrir conversa"
            open.setOnClickListener { openChat() }
            bar.addView(open, LinearLayout.LayoutParams(dp(36f), dp(48f)))

            val et = EditText(this)
            et.hint = if (addr.isEmpty()) "Abra a conversa para responder" else "Introduzir mensagem"
            et.setHintTextColor(cSub)
            et.setTextColor(if (dark) Color.WHITE else 0xFF111114.toInt())
            et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            et.maxLines = 4
            et.background = round(cField, 24f)
            et.setPadding(dp(18f), dp(12f), dp(18f), dp(12f))
            et.isEnabled = addr.isNotEmpty()
            input = et
            val il = LinearLayout.LayoutParams(0, -2, 1f)
            il.leftMargin = dp(4f)
            bar.addView(et, il)

            val sendBtn = TextView(this)
            sendBtn.text = "➤"
            sendBtn.gravity = Gravity.CENTER
            sendBtn.setTextColor(Color.WHITE)
            sendBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            val sg = GradientDrawable()
            sg.shape = GradientDrawable.OVAL
            sg.setColor(0xFF1E9E8F.toInt())
            sendBtn.background = sg
            sendBtn.contentDescription = "Enviar"
            sendBtn.setOnClickListener { send(et.text.toString()) }
            val sl = LinearLayout.LayoutParams(dp(50f), dp(50f))
            sl.leftMargin = dp(8f)
            bar.addView(sendBtn, sl)
            val bl = LinearLayout.LayoutParams(-1, -2)
            bl.topMargin = dp(10f)
            col.addView(bar, bl)
        }

        setContentView(root)
        input?.let { et ->
            if (addr.isNotEmpty()) {
                et.requestFocus()
                et.postDelayed({
                    (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                        .showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
                }, 150)
            }
        }

        // Ao ver a mensagem consideramos a conversa lida e retiramos a notificação.
        io.execute {
            try {
                if (thread >= 0) {
                    Messages.markRead(applicationContext, thread, true)
                    Notifier.cancel(applicationContext, thread)
                    Events.emit("changed")
                }
            } catch (_: Throwable) {
            }
        }
    }

    private fun iconBtn(glyph: String, desc: String, click: () -> Unit): TextView {
        val t = TextView(this)
        t.text = glyph
        t.gravity = Gravity.CENTER
        t.setTextColor(if (wp || dark) Color.WHITE else 0xFF111114.toInt())
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        t.contentDescription = desc
        t.setOnClickListener { click() }
        t.layoutParams = LinearLayout.LayoutParams(dp(44f), dp(44f))
        return t
    }

    private fun pill(text: String, click: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.background = round(0x40FFFFFF, 18f)
        t.setPadding(dp(14f), dp(8f), dp(14f), dp(8f))
        t.setOnClickListener { click() }
        return t
    }

    // ------------------------------------------------------------------ mensagens
    private fun load(first: Boolean) {
        if (loading) return
        loading = true
        val lim = limit
        val t = thread
        val app = applicationContext
        io.execute {
            val msgs = try { Messages.recent(app, t, lim) } catch (_: Throwable) { emptyList() }
            runOnUiThread {
                loading = false
                if (isDestroyed || t != thread) return@runOnUiThread
                more = msgs.size >= lim
                val oldH = list.height
                val oldY = scroll.scrollY
                list.removeAllViews()
                if (msgs.isEmpty()) {
                    if (fallback.isNotBlank()) addBubble(fallback, false, System.currentTimeMillis())
                } else {
                    var lastDay = -1
                    val cal = Calendar.getInstance()
                    for (m in msgs) {
                        cal.timeInMillis = m.second
                        val day = cal.get(Calendar.YEAR) * 400 + cal.get(Calendar.DAY_OF_YEAR)
                        if (day != lastDay) { addDay(m.second); lastDay = day }
                        addBubble(m.first, m.third, m.second)
                    }
                }
                // Depois do desenho: no início vai para o fim; ao carregar antigas mantém a posição.
                val vto = list.viewTreeObserver
                vto.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
                    override fun onPreDraw(): Boolean {
                        list.viewTreeObserver.removeOnPreDrawListener(this)
                        if (first) scroll.scrollTo(0, 1_000_000)
                        else scroll.scrollTo(0, oldY + (list.height - oldH))
                        return true
                    }
                })
            }
        }
    }

    private fun addDay(date: Long) {
        val t = TextView(this)
        t.text = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(date))
        t.setTextColor(if (wp) Color.WHITE else cSub)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.setPadding(0, dp(8f), 0, dp(8f))
        if (wp) t.setShadowLayer(4f, 0f, 1f, 0x99000000.toInt())
        list.addView(t, LinearLayout.LayoutParams(-1, -2))
    }

    private fun addBubble(text: String, mine: Boolean, date: Long) {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = if (mine) Gravity.END else Gravity.START
        val bg = if (mine) cSent else cRecv
        val tv = TextView(this)
        tv.text = text
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        tv.setTextColor(if (mine) inkOn(bg) else if (wp || dark) Color.WHITE else inkOn(bg))
        tv.background = round(bg, 20f)
        tv.setPadding(dp(14f), dp(9f), dp(14f), dp(9f))
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.74f).toInt()
        col.addView(tv)
        val tm = TextView(this)
        tm.text = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(date))
        tm.setTextColor(if (wp) Color.WHITE else cSub)
        tm.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        tm.setPadding(dp(6f), dp(2f), dp(6f), 0)
        if (wp) tm.setShadowLayer(4f, 0f, 1f, 0x99000000.toInt())
        col.addView(tm)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(8f)
        list.addView(col, lp)
    }

    private fun openChat() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra("thread", thread)
            )
        } catch (_: Throwable) {
        }
        finish()
    }

    private fun send(text: String) {
        val body = text.trim()
        val et = input ?: return
        if (body.isEmpty() || addr.isEmpty()) return
        if (!Sender.isDefault(this)) {
            Toast.makeText(this, "Defina o Chats como aplicação SMS predefinida para enviar.", Toast.LENGTH_LONG).show()
            return
        }
        et.setText("")
        addBubble(body, true, System.currentTimeMillis())
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        val app = applicationContext
        val a = addr
        val t = thread
        // Fora do ciclo de vida da janela: o envio não pode ser cancelado se a janela fechar.
        Thread {
            try {
                val chosen = Store.settings(app).optInt("sub", -1)
                val sub = if (chosen >= 0) chosen else SubscriptionManager.getDefaultSmsSubscriptionId()
                Sender.sendSms(app, listOf(a), body, sub, Store.bool(app, "deliveryReports", true))
                if (t >= 0) Messages.markRead(app, t, true)
                Notifier.cancel(app, t)
                Events.emit("changed")
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(app, e.message ?: "Não foi possível enviar.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}
