package app.chats.sms

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.telephony.SubscriptionManager
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.DateFormat
import java.util.Calendar
import java.util.Date
import java.util.concurrent.Executors

/**
 * Janela de resposta aberta pelo balão flutuante. Reproduz o ecrã de conversa da app: cabeçalho em
 * pílulas, balões iguais, fundo da conversa e barra de escrita com o enviar em círculo.
 * Mensagens antigas carregam ao subir até ao topo.
 */
class ReplyActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private var thread = -1L
    private var addr = ""
    private var name = ""
    private var svc = false
    private var dark = false
    private var fallback = ""
    private var limit = 60
    private var more = false
    private var loading = false
    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private var input: EditText? = null

    // Cores iguais às da app (tema claro / escuro)
    private var cSent = 0
    private var cRecv = 0
    private var fs = 16f
    private var rad = 18f
    private var wp = false
    private val cAcc get() = if (dark) 0xFF4DA3F7.toInt() else 0xFF3390EC.toInt()
    private val cInk get() = if (dark) 0xFFF2F2F2.toInt() else 0xFF0F1419.toInt()
    private val cMute get() = if (dark) 0xFF8E8E93.toInt() else 0xFF7E8791.toInt()
    private val cPill get() = if (dark) 0xFF1C1C1E.toInt() else Color.WHITE
    private val cChatBg get() = if (dark) Color.BLACK else 0xFFE4EBF2.toInt()

    private fun dp(v: Float) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun round(color: Int, r: Float): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = dp(r).toFloat()
        g.setColor(color)
        return g
    }

    private fun inkOn(bg: Int): Int {
        val l = (0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)) / 255.0
        return if (l > 0.62) 0xFF0F1419.toInt() else Color.WHITE
    }

    private fun icon(res: Int, tint: Int, sizeDp: Float): ImageView {
        val v = ImageView(this)
        v.setImageResource(res)
        v.setColorFilter(tint)
        v.scaleType = ImageView.ScaleType.FIT_CENTER
        v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return v
    }

    /** Pílula flutuante (como as do ecrã de conversa): fundo da app com sombra suave. */
    private fun floating(v: View, h: Float, fill: Int = cPill) {
        v.background = round(fill, h / 2f)
        v.elevation = dp(4f).toFloat()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        build(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        build(intent)
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    private fun isDark(): Boolean = when (Store.str(this, "theme", "auto")) {
        "dark" -> true
        "light" -> false
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private fun parse(s: String?): Int? = try {
        if (s.isNullOrBlank()) null else Color.parseColor(s)
    } catch (_: Exception) {
        null
    }

    private fun wallpaper(): File? {
        val d = File(filesDir, "wallpapers")
        val f1 = File(d, "c$thread.jpg")
        if (f1.exists()) return f1
        val f2 = File(d, "global.jpg")
        return if (f2.exists()) f2 else null
    }

    private fun build(i: Intent) {
        thread = i.getLongExtra("thread", -1L)
        addr = i.getStringExtra("addr") ?: ""
        name = i.getStringExtra("name")?.ifBlank { null } ?: addr
        fallback = i.getStringExtra("body") ?: ""
        svc = Notifier.isService(addr)
        dark = isDark()
        limit = 60
        more = false
        loading = false

        val wpFile = try { wallpaper() } catch (_: Throwable) { null }
        val wpBmp = try { if (wpFile != null) BitmapFactory.decodeFile(wpFile.absolutePath) else null } catch (_: Throwable) { null }
        wp = wpBmp != null
        val bub = Store.settings(this).optJSONObject("bub")
        cSent = parse(bub?.optString("sent")) ?: (if (dark) 0xFF2B5278.toInt() else 0xFF3A8FE8.toInt())
        cRecv = parse(bub?.optString("recv")) ?: (if (dark) 0xFF1C1C1E.toInt() else Color.WHITE)
        rad = (bub?.optDouble("r", 18.0) ?: 18.0).toFloat().coerceIn(6f, 28f)
        fs = (bub?.optDouble("fs", 16.0) ?: 16.0).toFloat().coerceIn(13f, 22f)

        val root = FrameLayout(this)
        root.setBackgroundColor(0xB3000000.toInt())
        root.setOnClickListener { finish() }

        // ---- ecrã de conversa dentro de um cartão arredondado
        val card = FrameLayout(this)
        card.background = round(cChatBg, 26f)
        card.clipToOutline = true
        card.isClickable = true // não fecha ao tocar dentro do cartão
        val clp = FrameLayout.LayoutParams(-1, -1)
        clp.setMargins(dp(10f), dp(36f), dp(10f), dp(10f))
        root.addView(card, clp)
        if (wpBmp != null) {
            val bg = ImageView(this)
            bg.scaleType = ImageView.ScaleType.CENTER_CROP
            bg.setImageBitmap(wpBmp)
            card.addView(bg, FrameLayout.LayoutParams(-1, -1))
        }
        val inner = LinearLayout(this)
        inner.orientation = LinearLayout.VERTICAL
        card.addView(inner, FrameLayout.LayoutParams(-1, -1))

        // ---- cabeçalho: círculo de fechar + pílula com foto e nome + pílula de ações
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(10f), dp(10f), dp(10f), dp(4f))
        head.clipChildren = false
        head.clipToPadding = false

        val closeC = FrameLayout(this)
        floating(closeC, 48f)
        closeC.setOnClickListener { finish() }
        closeC.contentDescription = "Fechar"
        val closeI = icon(R.drawable.ic_l_close, cInk, 22f)
        closeC.addView(closeI, FrameLayout.LayoutParams(dp(22f), dp(22f), Gravity.CENTER))
        head.addView(closeC, LinearLayout.LayoutParams(dp(48f), dp(48f)))

        val who = LinearLayout(this)
        who.orientation = LinearLayout.HORIZONTAL
        who.gravity = Gravity.CENTER_VERTICAL
        who.setPadding(dp(5f), 0, dp(16f), 0)
        floating(who, 48f)
        who.setOnClickListener { openChat() }
        val av = ImageView(this)
        av.scaleType = ImageView.ScaleType.CENTER_CROP
        who.addView(av, LinearLayout.LayoutParams(dp(38f), dp(38f)))
        io.execute {
            val bmp = try { Notifier.bubbleAvatar(applicationContext, addr, name, false) } catch (_: Throwable) { null }
            runOnUiThread {
                if (!isDestroyed) { if (bmp != null) av.setImageBitmap(bmp) else av.setImageResource(R.mipmap.ic_launcher) }
            }
        }
        val t1 = TextView(this)
        t1.text = name.ifEmpty { "Mensagem" }
        t1.setTextColor(cInk)
        t1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        t1.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t1.maxLines = 1
        t1.ellipsize = android.text.TextUtils.TruncateAt.END
        val tl = LinearLayout.LayoutParams(0, -2, 1f)
        tl.leftMargin = dp(10f)
        who.addView(t1, tl)
        val wl = LinearLayout.LayoutParams(0, dp(48f), 1f)
        wl.leftMargin = dp(10f)
        head.addView(who, wl)

        if (!svc && addr.isNotEmpty()) {
            val acts = FrameLayout(this)
            floating(acts, 48f)
            acts.contentDescription = "Ligar"
            acts.setOnClickListener {
                try { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(addr)))) } catch (_: Throwable) {}
            }
            acts.addView(icon(R.drawable.ic_l_phone, cInk, 22f), FrameLayout.LayoutParams(dp(22f), dp(22f), Gravity.CENTER))
            val al = LinearLayout.LayoutParams(dp(48f), dp(48f))
            al.leftMargin = dp(10f)
            head.addView(acts, al)
        }
        inner.addView(head, LinearLayout.LayoutParams(-1, -2))

        // ---- conversa
        scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(14f), dp(8f), dp(14f), dp(12f))
        scroll.addView(list, FrameLayout.LayoutParams(-1, -2))
        inner.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        scroll.setOnScrollChangeListener { _, _, y, _, _ ->
            // Ao chegar ao topo carrega mensagens mais antigas.
            if (y == 0 && more && !loading) {
                limit += 60
                load(false)
            }
        }
        load(true)

        // ---- respostas rápidas + barra de escrita (só quando se pode responder)
        input = null
        if (!svc) {
            val quick = try { Store.settings(this).optJSONArray("quick") } catch (_: Throwable) { null }
            if (quick != null && quick.length() > 0 && addr.isNotEmpty()) {
                val hs = HorizontalScrollView(this)
                hs.isHorizontalScrollBarEnabled = false
                hs.clipChildren = false
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.setPadding(dp(12f), dp(4f), dp(12f), dp(6f))
                for (k in 0 until minOf(quick.length(), 8)) {
                    val q = quick.optString(k).trim()
                    if (q.isEmpty()) continue
                    val chip = TextView(this)
                    chip.text = if (q.length > 28) q.take(28) + "…" else q
                    chip.setTextColor(cInk)
                    chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                    chip.gravity = Gravity.CENTER
                    chip.maxLines = 1
                    floating(chip, 36f)
                    chip.setPadding(dp(14f), 0, dp(14f), 0)
                    chip.setOnClickListener { send(q) }
                    val lp = LinearLayout.LayoutParams(-2, dp(36f))
                    lp.rightMargin = dp(8f)
                    row.addView(chip, lp)
                }
                hs.addView(row)
                inner.addView(hs, LinearLayout.LayoutParams(-1, -2))
            }

            val bar = LinearLayout(this)
            bar.orientation = LinearLayout.HORIZONTAL
            bar.gravity = Gravity.CENTER_VERTICAL
            bar.setPadding(dp(12f), dp(4f), dp(12f), dp(12f))
            bar.clipChildren = false
            bar.clipToPadding = false

            // campo: emoji · texto · anexo · microfone
            val field = LinearLayout(this)
            field.orientation = LinearLayout.HORIZONTAL
            field.gravity = Gravity.CENTER_VERTICAL
            floating(field, 50f)
            field.setPadding(dp(8f), 0, dp(8f), 0)
            val emo = FrameLayout(this)
            emo.addView(icon(R.drawable.ic_l_smile, 0xFFA3ABB5.toInt(), 24f), FrameLayout.LayoutParams(dp(24f), dp(24f), Gravity.CENTER))
            field.addView(emo, LinearLayout.LayoutParams(dp(38f), dp(46f)))

            val et = EditText(this)
            et.hint = if (addr.isEmpty()) "Abra a conversa para responder" else "Escreva algo…"
            et.setHintTextColor(cMute)
            et.setTextColor(cInk)
            et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            et.maxLines = 4
            et.background = null
            et.setPadding(dp(2f), dp(12f), dp(2f), dp(12f))
            et.isEnabled = addr.isNotEmpty()
            input = et
            field.addView(et, LinearLayout.LayoutParams(0, -2, 1f))
            emo.setOnClickListener {
                et.requestFocus()
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
            }

            val clip = FrameLayout(this)
            clip.addView(icon(R.drawable.ic_l_clip, 0xFFA3ABB5.toInt(), 20f), FrameLayout.LayoutParams(dp(20f), dp(20f), Gravity.CENTER))
            clip.contentDescription = "Anexos (abre a conversa)"
            clip.setOnClickListener { openChat() }
            field.addView(clip, LinearLayout.LayoutParams(dp(34f), dp(46f)))
            val mic = FrameLayout(this)
            mic.addView(icon(R.drawable.ic_l_mic, cAcc, 20f), FrameLayout.LayoutParams(dp(20f), dp(20f), Gravity.CENTER))
            mic.contentDescription = "Mensagem de voz (abre a conversa)"
            mic.setOnClickListener { openChat() }
            field.addView(mic, LinearLayout.LayoutParams(dp(34f), dp(46f)))
            bar.addView(field, LinearLayout.LayoutParams(0, -2, 1f))

            // enviar: círculo com a cor de destaque, como na app
            val sendC = FrameLayout(this)
            val sg = GradientDrawable()
            sg.shape = GradientDrawable.OVAL
            sg.setColor(cAcc)
            sendC.background = sg
            sendC.elevation = dp(4f).toFloat()
            sendC.contentDescription = "Enviar"
            sendC.addView(icon(R.drawable.ic_l_send, Color.WHITE, 22f), FrameLayout.LayoutParams(dp(22f), dp(22f), Gravity.CENTER))
            sendC.setOnClickListener { send(et.text.toString()) }
            val sl = LinearLayout.LayoutParams(dp(50f), dp(50f))
            sl.leftMargin = dp(10f)
            bar.addView(sendC, sl)
            inner.addView(bar, LinearLayout.LayoutParams(-1, -2))
        }

        setContentView(root)
        input?.let { et ->
            if (addr.isNotEmpty()) {
                et.requestFocus()
                et.postDelayed({
                    (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                        .showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
                }, 150)
            }
        }

        // Ao ver a mensagem consideramos a conversa lida e retiramos a notificação.
        io.execute {
            try {
                if (thread >= 0) {
                    Messages.markRead(applicationContext, thread, true)
                    Notifier.cancel(applicationContext, thread)
                    Events.emit("changed")
                }
            } catch (_: Throwable) {
            }
        }
    }

    // ------------------------------------------------------------------ mensagens
    private fun load(first: Boolean) {
        if (loading) return
        loading = true
        val lim = limit
        val t = thread
        val app = applicationContext
        io.execute {
            val msgs = try { Messages.recent(app, t, lim) } catch (_: Throwable) { emptyList() }
            runOnUiThread {
                loading = false
                if (isDestroyed || t != thread) return@runOnUiThread
                more = msgs.size >= lim
                val oldH = list.height
                val oldY = scroll.scrollY
                list.removeAllViews()
                if (msgs.isEmpty()) {
                    if (fallback.isNotBlank()) addBubble(fallback, false, System.currentTimeMillis())
                } else {
                    var lastDay = -1
                    val cal = Calendar.getInstance()
                    for (m in msgs) {
                        cal.timeInMillis = m.second
                        val day = cal.get(Calendar.YEAR) * 400 + cal.get(Calendar.DAY_OF_YEAR)
                        if (day != lastDay) { addDay(m.second); lastDay = day }
                        addBubble(m.first, m.third, m.second)
                    }
                }
                // Depois do desenho: no início vai para o fim; ao carregar antigas mantém a posição.
                val vto = list.viewTreeObserver
                vto.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
                    override fun onPreDraw(): Boolean {
                        list.viewTreeObserver.removeOnPreDrawListener(this)
                        if (first) scroll.scrollTo(0, 1_000_000)
                        else scroll.scrollTo(0, oldY + (list.height - oldH))
                        return true
                    }
                })
            }
        }
    }

    /** Separador de dia numa pílula, legível sobre qualquer fundo. */
    private fun addDay(date: Long) {
        val t = TextView(this)
        t.text = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(date))
        t.setTextColor(cMute)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.gravity = Gravity.CENTER
        t.background = round(if (wp) cPill else 0x00000000, 12f)
        t.setPadding(dp(12f), dp(4f), dp(12f), dp(4f))
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.gravity = Gravity.CENTER_HORIZONTAL
        lp.topMargin = dp(6f)
        lp.bottomMargin = dp(8f)
        list.addView(t, lp)
    }

    /** Balão igual ao da app: raio das definições, canto da "cauda" a 6 e hora dentro do balão. */
    private fun addBubble(text: String, mine: Boolean, date: Long) {
        val bg = if (mine) cSent else cRecv
        val ink = if (mine) inkOn(bg) else (if (inkOn(bg) == Color.WHITE) Color.WHITE else cInk)
        val r = dp(rad).toFloat()
        val s = dp(6f).toFloat()
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.setColor(bg)
        // ordem: topo-esq, topo-dir, baixo-dir, baixo-esq
        g.cornerRadii = if (mine) floatArrayOf(r, r, r, r, s, s, r, r) else floatArrayOf(r, r, r, r, r, r, s, s)

        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        b.background = g
        b.setPadding(dp(14f), dp(9f), dp(14f), dp(7f))
        val tv = TextView(this)
        tv.text = text
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, fs)
        tv.setTextColor(ink)
        tv.setLineSpacing(0f, 1.1f)
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.74f).toInt()
        b.addView(tv, LinearLayout.LayoutParams(-2, -2))
        val tm = TextView(this)
        tm.text = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(date))
        tm.setTextColor(ink)
        tm.alpha = 0.55f
        tm.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        val tlp = LinearLayout.LayoutParams(-2, -2)
        tlp.gravity = Gravity.END
        tlp.topMargin = dp(2f)
        b.addView(tm, tlp)

        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.gravity = if (mine) Gravity.END else Gravity.START
        lp.bottomMargin = dp(6f)
        list.addView(b, lp)
    }

    private fun openChat() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra("thread", thread)
            )
        } catch (_: Throwable) {
        }
        finish()
    }

    private fun send(text: String) {
        val body = text.trim()
        val et = input ?: return
        if (body.isEmpty() || addr.isEmpty()) return
        if (!Sender.isDefault(this)) {
            Toast.makeText(this, "Defina o Chats como aplicação SMS predefinida para enviar.", Toast.LENGTH_LONG).show()
            return
        }
        et.setText("")
        addBubble(body, true, System.currentTimeMillis())
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        val app = applicationContext
        val a = addr
        val t = thread
        // Fora do ciclo de vida da janela: o envio não pode ser cancelado se a janela fechar.
        Thread {
            try {
                val chosen = Store.settings(app).optInt("sub", -1)
                val sub = if (chosen >= 0) chosen else SubscriptionManager.getDefaultSmsSubscriptionId()
                Sender.sendSms(app, listOf(a), body, sub, Store.bool(app, "deliveryReports", true))
                if (t >= 0) Messages.markRead(app, t, true)
                Notifier.cancel(app, t)
                Events.emit("changed")
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(app, e.message ?: "Não foi possível enviar.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}
