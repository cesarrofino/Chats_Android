package app.chats.sms

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import android.provider.Telephony
import android.telephony.SubscriptionManager
import android.util.Base64
import android.webkit.JavascriptInterface
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.function.Consumer

/**
 * Única ponte entre a WebView e o código nativo. Expõe apenas call(id, método, argumentosJSON).
 * Todos os métodos são de uma lista fechada e todos os argumentos são validados.
 */
class Bridge(private val act: MainActivity) {
    private val ctx: Context = act.applicationContext
    private val pool = Executors.newFixedThreadPool(4)
    // Envio tem fila própria: nunca espera atrás de carregamentos pesados (conversas, contactos, pesquisa).
    private val sendPool = Executors.newSingleThreadExecutor()

    private object Deferred

    @JavascriptInterface
    fun call(id: String, method: String, args: String) {
        val ex = if (method == "sendSms" || method == "sendMms" || method == "retry") sendPool else pool
        ex.execute {
            try {
                val a = if (args.isEmpty()) JSONObject() else JSONObject(args)
                val r = handle(id, method, a)
                if (r !== Deferred) reply(id, true, encode(r))
            } catch (e: Exception) {
                reply(id, false, e.message ?: "Erro desconhecido")
            }
        }
    }

    private fun encode(r: Any?): String = when (r) {
        null -> "null"
        is String -> JSONObject.quote(r)
        is JSONObject, is JSONArray, is Boolean, is Number -> r.toString()
        else -> JSONObject.quote(r.toString())
    }

    private fun reply(id: String, ok: Boolean, payload: String) {
        val js = "window.__cb(${JSONObject.quote(id)},$ok,${JSONObject.quote(payload)})"
        act.runOnUiThread { act.web.evaluateJavascript(js, null) }
    }

    // ------------------------------------------------------------ utilitários
    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun permState(): JSONObject = JSONObject()
        .put("sms", has(Manifest.permission.READ_SMS) && has(Manifest.permission.SEND_SMS) && has(Manifest.permission.RECEIVE_SMS))
        .put("contacts", has(Manifest.permission.READ_CONTACTS))
        .put("phone", has(Manifest.permission.READ_PHONE_STATE))
        .put("notif", Build.VERSION.SDK_INT < 33 || has(Manifest.permission.POST_NOTIFICATIONS))

    private fun sims(): JSONArray {
        val arr = JSONArray()
        if (!has(Manifest.permission.READ_PHONE_STATE)) return arr
        try {
            val sm = ctx.getSystemService(SubscriptionManager::class.java)
            val l = sm.activeSubscriptionInfoList ?: return arr
            for (s in l) {
                arr.put(
                    JSONObject().put("sub", s.subscriptionId).put("slot", s.simSlotIndex + 1)
                        .put("name", (s.displayName ?: "SIM").toString())
                        .put("carrier", (s.carrierName ?: "").toString())
                )
            }
        } catch (_: Exception) {
        }
        return arr
    }

    private fun validAddr(s: String) = s.length in 1..64 && Regex("^[+0-9A-Za-z .()*#@_-]+$").matches(s)

    private fun addrs(a: JSONObject): List<String> {
        val arr = a.optJSONArray("addrs") ?: throw Exception("Sem destinatários.")
        if (arr.length() == 0 || arr.length() > 20) throw Exception("Indique entre 1 e 20 destinatários.")
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val s = arr.getString(i).trim()
            if (!validAddr(s)) throw Exception("Destinatário inválido: $s")
            out.add(s)
        }
        return out
    }

    private fun requireDefault() {
        if (!Sender.isDefault(ctx)) {
            throw Exception("Defina o Chats como aplicação SMS predefinida para enviar e receber mensagens.")
        }
    }

    private fun ensure(perms: Array<String>, then: (Boolean) -> Unit) {
        val missing = perms.filter { !has(it) }
        if (missing.isEmpty()) {
            then(true)
        } else {
            act.askPerms(missing.toTypedArray()) { _ -> then(perms.any { has(it) }) }
        }
    }

    private fun launch(i: Intent) {
        act.runOnUiThread {
            try {
                act.startActivity(i)
            } catch (_: Exception) {
            }
        }
    }

    fun openExternal(url: String) {
        val u = Uri.parse(url)
        val ok = setOf("http", "https", "geo", "mailto", "tel")
        if (u.scheme?.lowercase() in ok) launch(Intent(Intent.ACTION_VIEW, u))
    }

    private fun key(s: String) = s.lowercase().replace(Regex("[^a-z0-9_]"), "_").take(40).ifEmpty { "global" }
    private fun wpFile(k: String): File {
        val d = File(ctx.filesDir, "wallpapers")
        d.mkdirs()
        return File(d, key(k) + ".jpg")
    }

    private fun dataUrl(f: File): String? =
        if (f.exists()) "data:image/jpeg;base64," + Base64.encodeToString(f.readBytes(), Base64.NO_WRAP) else null

    private fun getLocation(): JSONObject {
        val lm = ctx.getSystemService(LocationManager::class.java)
        var best: Location? = null
        try {
            for (p in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(p)
                val b = best
                if (l != null && (b == null || l.time > b.time)) best = l
            }
        } catch (e: SecurityException) {
            throw Exception("Sem permissão de localização.")
        }
        val old = best
        if ((old == null || System.currentTimeMillis() - old.time > 120_000) && Build.VERSION.SDK_INT >= 30) {
            val prov = when {
                lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                else -> null
            }
            if (prov != null) {
                val latch = CountDownLatch(1)
                var got: Location? = null
                try {
                    lm.getCurrentLocation(prov, null, ctx.mainExecutor, Consumer<Location?> { l ->
                        got = l
                        latch.countDown()
                    })
                    latch.await(12, TimeUnit.SECONDS)
                } catch (_: SecurityException) {
                }
                val g = got
                if (g != null) best = g
            }
        }
        val r = best ?: throw Exception("Não foi possível obter a localização. Ative o GPS e tente novamente.")
        return JSONObject().put("lat", r.latitude).put("lon", r.longitude).put("acc", r.accuracy.toDouble())
    }

    private fun calendarEvents(): JSONArray {
        val out = JSONArray()
        val now = System.currentTimeMillis()
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, now - 86_400_000L)
        ContentUris.appendId(b, now + 90 * 86_400_000L)
        ctx.contentResolver.query(
            b.build(),
            arrayOf(
                CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END,
                CalendarContract.Instances.EVENT_LOCATION, CalendarContract.Instances.ALL_DAY
            ),
            null, null, "begin ASC"
        )?.use { cur ->
            while (cur.moveToNext() && out.length() < 60) {
                out.put(
                    JSONObject().put("title", cur.getString(0) ?: "(sem título)").put("begin", cur.getLong(1))
                        .put("end", cur.getLong(2)).put("loc", cur.getString(3) ?: "").put("allDay", cur.getInt(4) == 1)
                )
            }
        }
        return out
    }

    // ------------------------------------------------------------ métodos
    @Suppress("DEPRECATION")
    private fun handle(id: String, method: String, a: JSONObject): Any? {
        when (method) {
            "init" -> {
                val p = Events.pending
                Events.pending = null
                return JSONObject()
                    .put("defaultSms", Sender.isDefault(ctx)).put("perms", permState()).put("sims", sims())
                    .put("defaultSub", SubscriptionManager.getDefaultSmsSubscriptionId())
                    .put("settings", Store.settings(ctx)).put("pending", p ?: JSONObject.NULL)
                    .put("sdk", Build.VERSION.SDK_INT).put("exact", Scheduler.canExact(ctx))
                    .put("version", try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0.0" } catch (e: Exception) { "1.0.0" })
                    .put("hasPhone", ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_TELEPHONY))
            }
            "requestDefault" -> {
                val intent: Intent
                if (Build.VERSION.SDK_INT >= 29) {
                    val rm = ctx.getSystemService(RoleManager::class.java)
                    if (!rm.isRoleAvailable(RoleManager.ROLE_SMS)) throw Exception("Este dispositivo não permite definir uma aplicação SMS.")
                    if (rm.isRoleHeld(RoleManager.ROLE_SMS)) return true
                    intent = rm.createRequestRoleIntent(RoleManager.ROLE_SMS)
                } else {
                    intent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                        .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, ctx.packageName)
                }
                act.startForResult(intent) { _ ->
                    reply(id, true, encode(Sender.isDefault(ctx)))
                    Events.emit("default")
                }
                return Deferred
            }
            "requestPerms" -> {
                val list = ArrayList<String>()
                val w = a.optJSONArray("which") ?: JSONArray()
                for (i in 0 until w.length()) {
                    when (w.getString(i)) {
                        "sms" -> list.addAll(
                            listOf(
                                Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS,
                                Manifest.permission.RECEIVE_MMS, Manifest.permission.RECEIVE_WAP_PUSH
                            )
                        )
                        "contacts" -> list.add(Manifest.permission.READ_CONTACTS)
                        "phone" -> list.add(Manifest.permission.READ_PHONE_STATE)
                        "notif" -> if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
                val missing = list.filter { !has(it) }
                if (missing.isEmpty()) return permState()
                act.askPerms(missing.toTypedArray()) { _ ->
                    Contacts.clearCache()
                    reply(id, true, permState().toString())
                    Events.emit("perms")
                }
                return Deferred
            }
            "setSettings" -> {
                val s = a.getString("json")
                if (s.length > 400_000) throw Exception("Definições demasiado grandes.")
                Store.saveSettings(ctx, s)
                return true
            }
            "setBars" -> {
                val col = try { Color.parseColor(a.optString("color", "#FFFFFF")) } catch (e: Exception) { Color.WHITE }
                act.setBars(a.optBoolean("dark"), col)
                return true
            }
            "threads" -> { val r = Messages.threads(ctx); Notifier.badge(ctx, Messages.lastUnread); return r }
            "photos" -> {
                val arr = a.optJSONArray("addrs") ?: JSONArray()
                val l = ArrayList<String>()
                for (i in 0 until minOf(arr.length(), 400)) l.add(arr.getString(i))
                return Contacts.photos(ctx, l)
            }
            "contacts" -> return Contacts.list(ctx)
            "messages" -> return Messages.messages(ctx, a.getLong("thread"), a.optInt("limit", 400).coerceIn(20, 3000))
            "thumb" -> {
                val mime = a.optString("mime", "image/jpeg")
                return Media.thumb(ctx, Uri.parse("content://mms/part/${a.getLong("part")}"), mime, a.optInt("max", 720).coerceIn(64, 1600))
            }
            "audioInfo" -> return Player.duration(ctx, a.getLong("part"), a.optString("mime", "audio/amr"))
            "audioToggle" -> { Player.toggle(ctx, a.getLong("part"), a.optString("mime", "audio/amr")); return true }
            "audioSeek" -> { Player.seek(a.getLong("part"), a.optInt("ms", 0)); return true }
            "audioSpeed" -> { Player.setSpeed(a.optDouble("speed", 1.0).toFloat()); return true }
            "audioStop" -> { Player.stop(); return true }
            "search" -> {
                val q = a.optString("q").trim()
                return if (q.length < 2) JSONArray() else Messages.search(ctx, q.take(80))
            }
            "markRead" -> {
                val t = a.getLong("thread")
                val ok = Messages.markRead(ctx, t, a.optBoolean("read", true))
                if (a.optBoolean("read", true)) Notifier.cancel(ctx, t)
                return ok
            }
            "deleteThreads" -> {
                requireDefault()
                val arr = a.getJSONArray("ids")
                val l = ArrayList<Long>()
                for (i in 0 until arr.length()) l.add(arr.getLong(i))
                return Messages.deleteThreads(ctx, l)
            }
            "deleteMessages" -> {
                requireDefault()
                val arr = a.getJSONArray("items")
                var n = 0
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    n += Messages.deleteMessage(ctx, o.getString("k"), o.getLong("id"))
                }
                return n
            }
            "threadId" -> return Messages.threadIdFor(ctx, addrs(a))
            "sendSms" -> {
                requireDefault()
                val body = a.getString("body")
                if (body.isEmpty() || body.length > 20_000) throw Exception("Mensagem vazia ou demasiado longa.")
                return Sender.sendSms(ctx, addrs(a), body, a.optInt("sub", -1), Store.bool(ctx, "deliveryReports", true))
            }
            "sendMms" -> {
                requireDefault()
                val ids = ArrayList<String>()
                val arr = a.optJSONArray("atts") ?: JSONArray()
                for (i in 0 until minOf(arr.length(), 10)) ids.add(arr.getString(i))
                val subject = a.optString("subject", "").take(120)
                return Sender.sendMms(ctx, addrs(a), subject.ifEmpty { null }, a.optString("body", ""), ids, a.optInt("sub", -1))
            }
            "retry" -> {
                requireDefault()
                val idn = a.getLong("id")
                if (a.getString("k") == "m") Sender.retryMms(ctx, idn)
                else Sender.retrySms(ctx, idn, Store.bool(ctx, "deliveryReports", true))
                return true
            }
            "downloadMms" -> {
                requireDefault()
                Sender.downloadMms(ctx, a.getLong("id"))
                return true
            }
            "pick" -> {
                val mime = a.optString("mime", "*/*")
                if (mime !in setOf("image/*", "video/*", "audio/*", "*/*")) throw Exception("Tipo inválido.")
                act.pick(mime) { uri ->
                    if (uri == null) {
                        reply(id, true, "null")
                    } else {
                        pool.execute {
                            try {
                                reply(id, true, Media.toJson(ctx, Media.register(ctx, uri)).toString())
                            } catch (e: Exception) {
                                reply(id, false, e.message ?: "Não foi possível abrir o ficheiro.")
                            }
                        }
                    }
                }
                return Deferred
            }
            "attachFromPart" -> {
                val att = Media.register(
                    ctx, Uri.parse("content://mms/part/${a.getLong("part")}"),
                    a.optString("mime", "application/octet-stream"), a.optString("name", "anexo")
                )
                return Media.toJson(ctx, att)
            }
            "dropAtt" -> {
                Media.atts.remove(a.optString("id"))
                return true
            }
            "pickContact" -> {
                val i = Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
                act.startForResult(i) { r ->
                    val u = r.data?.data
                    if (r.resultCode != Activity.RESULT_OK || u == null) {
                        reply(id, true, "null")
                    } else {
                        pool.execute {
                            try {
                                var res: JSONObject? = null
                                ctx.contentResolver.query(
                                    u,
                                    arrayOf(
                                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                                        ContactsContract.CommonDataKinds.Phone.NUMBER
                                    ), null, null, null
                                )?.use { c ->
                                    if (c.moveToFirst()) res = JSONObject().put("name", c.getString(0) ?: "").put("number", c.getString(1) ?: "")
                                }
                                reply(id, true, (res?.toString() ?: "null"))
                            } catch (e: Exception) {
                                reply(id, false, "Não foi possível ler o contacto.")
                            }
                        }
                    }
                }
                return Deferred
            }
            "pickRingtone" -> {
                val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                    .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
                    .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                    .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                    .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Som de notificação")
                act.startForResult(i) { r ->
                    if (r.resultCode != Activity.RESULT_OK) {
                        reply(id, true, "null")
                    } else {
                        val u = r.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                        val o = JSONObject()
                        if (u == null) {
                            o.put("uri", "none").put("title", "Silencioso")
                        } else {
                            val title = try { RingtoneManager.getRingtone(ctx, u)?.getTitle(ctx) ?: "Personalizado" } catch (e: Exception) { "Personalizado" }
                            o.put("uri", u.toString()).put("title", title)
                        }
                        reply(id, true, o.toString())
                    }
                }
                return Deferred
            }
            "pickWallpaper" -> {
                val k = a.optString("key", "global")
                act.pick("image/*") { uri ->
                    if (uri == null) {
                        reply(id, true, "null")
                    } else {
                        pool.execute {
                            try {
                                val bmp = Media.load(ctx, uri, 1440) ?: throw Exception("Imagem inválida.")
                                val f = wpFile(k)
                                f.writeBytes(Media.jpeg(bmp, 86))
                                reply(id, true, encode(dataUrl(f)))
                            } catch (e: Exception) {
                                reply(id, false, e.message ?: "Não foi possível usar a imagem.")
                            }
                        }
                    }
                }
                return Deferred
            }
            "wallpaper" -> return dataUrl(wpFile(a.optString("key", "global")))
            "removeWallpaper" -> {
                wpFile(a.optString("key", "global")).delete()
                return true
            }
            "location" -> {
                ensure(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) { ok ->
                    if (!ok) {
                        reply(id, false, "Permissão de localização recusada.")
                    } else {
                        pool.execute {
                            try { reply(id, true, getLocation().toString()) } catch (e: Exception) { reply(id, false, e.message ?: "Erro de localização.") }
                        }
                    }
                }
                return Deferred
            }
            "events" -> {
                ensure(arrayOf(Manifest.permission.READ_CALENDAR)) { ok ->
                    if (!ok) {
                        reply(id, false, "Permissão de calendário recusada.")
                    } else {
                        pool.execute {
                            try { reply(id, true, calendarEvents().toString()) } catch (e: Exception) { reply(id, false, "Não foi possível ler a agenda.") }
                        }
                    }
                }
                return Deferred
            }
            "recStart" -> {
                ensure(arrayOf(Manifest.permission.RECORD_AUDIO)) { ok ->
                    if (!ok) {
                        reply(id, false, "Permissão de microfone recusada.")
                    } else {
                        pool.execute {
                            try {
                                Media.recStart(ctx)
                                reply(id, true, "true")
                            } catch (e: Exception) {
                                reply(id, false, "Não foi possível iniciar a gravação.")
                            }
                        }
                    }
                }
                return Deferred
            }
            "recLevel" -> return Media.recLevel()
            "recStop" -> {
                val att = Media.recStop(ctx) ?: throw Exception("Gravação demasiado curta.")
                return Media.toJson(ctx, att)
            }
            "recCancel" -> {
                Media.recCancel()
                return true
            }
            "dial" -> {
                val n = a.getString("number")
                if (!Regex("^[+0-9*#() .-]{1,32}$").matches(n)) throw Exception("Número inválido.")
                launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n))))
                return true
            }
            "addContact" -> {
                val n = a.getString("number")
                if (!validAddr(n)) throw Exception("Número inválido.")
                launch(
                    Intent(ContactsContract.Intents.Insert.ACTION).setType(ContactsContract.RawContacts.CONTENT_TYPE)
                        .putExtra(ContactsContract.Intents.Insert.PHONE, n)
                )
                return true
            }
            "openUrl" -> {
                openExternal(a.getString("url"))
                return true
            }
            "share" -> {
                val t = a.getString("text").take(20_000)
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t)
                launch(Intent.createChooser(i, "Partilhar mensagem"))
                return true
            }
            "shareAtt" -> {
                val name = a.optString("name", "anexo").replace(Regex("[^A-Za-z0-9._-]"), "_").take(60).ifEmpty { "anexo" }
                val dir = File(ctx.cacheDir, "share")
                dir.mkdirs()
                val f = File(dir, name)
                ctx.contentResolver.openInputStream(Uri.parse("content://mms/part/${a.getLong("part")}"))?.use { ins ->
                    f.outputStream().use { ins.copyTo(it) }
                } ?: throw Exception("Não foi possível ler o anexo.")
                val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
                val i = Intent(Intent.ACTION_SEND).setType(a.optString("mime", "*/*")).putExtra(Intent.EXTRA_STREAM, uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                i.clipData = ClipData.newRawUri("", uri)
                launch(Intent.createChooser(i, "Partilhar anexo"))
                return true
            }
            "copy" -> {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Chats", a.getString("text").take(50_000)))
                return true
            }
            "block" -> {
                val n = a.getString("number")
                if (!validAddr(n)) throw Exception("Número inválido.")
                try {
                    val v = android.content.ContentValues()
                    v.put(android.provider.BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER, n)
                    ctx.contentResolver.insert(android.provider.BlockedNumberContract.BlockedNumbers.CONTENT_URI, v)
                } catch (e: Exception) {
                    throw Exception("O Android só permite bloquear números quando o Chats é a aplicação SMS predefinida.")
                }
                return true
            }
            "unblock" -> {
                try { android.provider.BlockedNumberContract.unblock(ctx, a.getString("number")) } catch (e: Exception) {
                    throw Exception("Não foi possível desbloquear este número.")
                }
                return true
            }
            "blocked" -> {
                val out = JSONArray()
                try {
                    ctx.contentResolver.query(
                        android.provider.BlockedNumberContract.BlockedNumbers.CONTENT_URI,
                        arrayOf(android.provider.BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER), null, null, null
                    )?.use { c -> while (c.moveToNext()) out.put(c.getString(0)) }
                } catch (_: Exception) {
                }
                return out
            }
            "schedList" -> return Scheduler.list(ctx)
            "schedSave" -> {
                val item = a.getJSONObject("item")
                val arr = item.optJSONArray("addrs") ?: JSONArray()
                for (i in 0 until arr.length()) if (!validAddr(arr.getString(i))) throw Exception("Destinatário inválido.")
                return Scheduler.save(ctx, item)
            }
            "schedDelete" -> {
                Scheduler.delete(ctx, a.getInt("id"))
                return true
            }
            "exactAlarmSettings" -> {
                if (Build.VERSION.SDK_INT >= 31) {
                    launch(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)))
                }
                return true
            }
            "storage" -> {
                fun size(f: File): Long = if (f.isDirectory) (f.listFiles() ?: emptyArray()).sumOf { size(it) } else f.length()
                val o = Messages.counts(ctx)
                o.put("cache", size(ctx.cacheDir)).put("wallpapers", size(File(ctx.filesDir, "wallpapers")))
                return o
            }
            "clearCache" -> {
                ctx.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
                return true
            }
            "deleteOld" -> {
                requireDefault()
                return Messages.deleteOlderThan(ctx, a.getInt("days").coerceIn(1, 3650))
            }
            "notifSettings" -> {
                launch(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName))
                return true
            }
            "appSettings" -> {
                launch(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
                return true
            }
            "cancelNotif" -> {
                Notifier.cancel(ctx, a.getLong("thread"))
                return true
            }
            "refreshContacts" -> {
                Contacts.clearCache()
                return true
            }
        }
        throw Exception("Método desconhecido: $method")
    }
}
