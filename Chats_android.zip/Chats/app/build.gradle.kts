plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.chats.sms"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.chats.sms"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // Chave de assinatura FIXA, guardada no projeto (app/chats-release.jks). Todas as versões ficam assinadas com
    // a mesma chave, por isso o Android aceita instalar cada atualização por cima da anterior.
    // Não apague nem troque o ficheiro chats-release.jks: senão as atualizações deixam de instalar.
    signingConfigs {
        create("chats") {
            storeFile = file("chats-release.jks")
            storePassword = "UeZyUZdHUWRc9PIvB7UwhynC"
            keyAlias = "chats"
            keyPassword = "UeZyUZdHUWRc9PIvB7UwhynC"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("chats")
        }
        debug {
            signingConfig = signingConfigs.getByName("chats")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.activity:activity-ktx:1.9.1")
}
